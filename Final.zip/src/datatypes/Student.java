package datatypes;

import java.util.*;

public class Student
{
	private int id;
	private String firstname;
	private String middlename;
	private String lastname;
	private String major;
	private String tuitionStatus;
	private TreeMap<Integer, String> sessionGradesEnrolled;
	//private int currentUnit;
	public Student(String firstname, String middlename, String lastname, String major)
	{
		//this.id = id;
		id = -1;
		this.firstname = firstname;
		this.middlename = middlename.substring(0, 1);
		this.lastname = lastname;
		this.major = major;
		this.tuitionStatus = "Unpaid";
		this.sessionGradesEnrolled = new TreeMap<>();
		//this.currentUnit = 0;
	}
	public Student(String firstname, String middlename, String lastname)
	{
		//this.id = id;
		id = -1;
		this.firstname = firstname;
		this.middlename = middlename.substring(0, 1);
		this.lastname = lastname;
		this.major = "Undeclared";
		this.tuitionStatus = "Unpaid";
		this.sessionGradesEnrolled = new TreeMap<>();
		//this.currentUnit = 0;
	}
	public void setID(int id) { this.id = id; }
	public void setFirstname(String firstname) { this.firstname = firstname; }
	public void setMiddlename(String middlename) { this.middlename = middlename; }
	public void setLastname(String lastname) { this.lastname = lastname; }
	public void setMajor(String major) { this.major = major; }
	public void setTuitionStatus(String tuitionStatus) { this.tuitionStatus = tuitionStatus; }
	public void setGrade(int sessionID, String grade) { sessionGradesEnrolled.replace(sessionID, grade); }
	//public void setCurrentUnit(int currentUnit) { this.currentUnit = currentUnit; }
	public int id() { return id; }
	public String firstname() { return firstname; }
	public String middlename() { return middlename; }
	public String lastname() { return lastname; }
	public String major() { return major; }
	public String tuitionStatus() { return tuitionStatus; }
	public TreeMap<Integer, String> sessionGradesEnrolled() { return sessionGradesEnrolled; }
	//public int currentUnit() { return currentUnit; }
	public void addSessionToStudentByID(int sID) { sessionGradesEnrolled.put(sID, "N/A"); }
	public void removeSessionByID(int sID) { sessionGradesEnrolled.remove(sID); }
	public void setPay() { tuitionStatus = "Paid"; }
	public void setUnpay() { tuitionStatus = "Unpaid"; }
}
