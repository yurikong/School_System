package datatypes;

import java.util.ArrayList;

public class Employee
{
	private int id;
	private String firstname;
	private String middlename;
	private String lastname;
	private String title;
	private double salary;
	private ArrayList<Integer> sessionsTeaching;
	public Employee(String firstname, String middlename, String lastname, double salary)
	{
		//this.id = id;
		this.firstname = firstname;
		this.middlename = middlename.substring(0, 1);
		this.lastname = lastname;
		this.title = "Professor";
		this.salary = salary;
		this.sessionsTeaching = new ArrayList<>();
	}
	public void setID(int id) { this.id = id; }
	public void setFirstname(String firstname) { this.firstname = firstname; }
	public void setMiddlename(String middlename) { this.middlename = middlename; }
	public void setLastname(String lastname) { this.lastname = lastname; }
	public void setTitle(String title) { this.title = title; }
	public void setSalary(double salary) { this.salary = salary; }
	public void setSessionsTeaching(ArrayList<Integer> sessionsTeaching) { this.sessionsTeaching = sessionsTeaching; }
	public int id() { return id; }
	public String firstname() { return firstname; }
	public String middlename() { return middlename; }
	public String lastname() { return lastname; }
	public String title() { return title; }
	public double salary() { return salary; }
	public ArrayList<Integer> sessionsTeaching() { return sessionsTeaching; }
	public void addSessionById(int sID) { sessionsTeaching.add(sID); }
	public void removeSessionByID(int sID) { sessionsTeaching.remove((Object) sID); }
}
