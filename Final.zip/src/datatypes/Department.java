package datatypes;

//import java.util.ArrayList;

public class Department
{
	private String name;
	private int chairID;
	private String college;
	//private ArrayList<String> majors;
	public Department(String name, String college, int chairID)
	{
		this.name = name;
		this.college = college;
		this.chairID = chairID;
		//this.majors = majors;
	}
	public void setName(String name) { this.name = name; }
	public void setCollege(String c) { college = c; }
	public void setChairID(int chairID) { this.chairID = chairID; }
	//public void setMajors(ArrayList<String> majors) { this.majors = majors; }
	public String getCollege() { return college; }
	public String name() { return name; }
	public int chairID() { return chairID; }
	//public ArrayList<String> majors() { return majors; }
}
