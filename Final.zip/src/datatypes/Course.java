package datatypes;

import java.util.ArrayList;

public class Course
{
	private int id;
	private String name;
	private int unit;
	private ArrayList<Integer> prereqs;
	private String major;
	private String dept;
	private String college;
	//private ArrayList<Integer> sessions;
	public Course(String name, String major, String dept, String col)
	{
		this.id = -1;
		this.name = name;
		this.unit = 4;
		prereqs = new ArrayList<>();
		this.major = major;
		this.dept = dept;
		college = col;
		//this.prereqs = prereqs;
		//this.sessions = sessions;
	}
	public void setID(int id) { this.id = id; }
	public void setName(String name) { this.name = name; }
	public void setUnit(int unit) { this.unit = unit; }
	public void setPrereqs(ArrayList<Integer> prereqs) { this.prereqs = prereqs; }
	public void setMajor(String maj) { major = maj; }
	public void setDept(String dept) { this.dept = dept; }
	public void setCollege(String col) { college = col; }
	//public void setSessions(ArrayList<Integer> sessions) { this.sessions = sessions; }
	public int id() { return id; }
	public String name() { return name; }
	public int unit() { return unit; }
	public String getMajor() { return major; }
	public String getDepartment() { return dept; }
	public String getCollege() { return college; }
	public ArrayList<Integer> prereqs() { return prereqs; }
	public void removePreqByID(int pID) { prereqs.remove((Object) pID); }
	public void addPreqByID(int pID) { prereqs.add(pID); }
	//public ArrayList<Integer> sessions() { return sessions; }
}
