package datatypes;

public class University
{
	private String name;
	public University() {}
	public void setName(String name) { this.name = name; }
	public String name() { return name; }
}
