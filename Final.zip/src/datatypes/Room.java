package datatypes;

public class Room
{
	private int id;
	private int roomNumber;
	private final int occupancyLimit;
	private String buildingName;
	public Room(int roomNumber, final int occupancyLimit, String buildingName)
	{
		this.id = -1;
		this.roomNumber = roomNumber;
		this.occupancyLimit = occupancyLimit;
		this.buildingName = buildingName;
	}
	public void setRoomID(int roomID) { id = roomID; }
	public void setRoomNumber(int roomNumber) { this.roomNumber = roomNumber; }
	public void setBuildingName(String buildingName) { this.buildingName = buildingName; }
	public int id() { return id; }
	public int roomNumber() { return roomNumber; }
	public final int occupancyLimit() { return occupancyLimit; }
	public String buildingName() { return buildingName; }
}
