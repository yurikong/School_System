package datatypes;

//import java.util.ArrayList;

public class Building
{
	private String name;
	private int bldLimit;
	//private ArrayList<Room> rooms;
	//private ArrayList<Integer> rooms;
	public Building(String name, int bldLimit)
	{
		this.name = name;
		this.bldLimit = bldLimit;
		//this.rooms = rooms;
	}
	public void setName(String name) { this.name = name; }
	//public void setRooms(ArrayList<Integer> rooms) { this.rooms = rooms; }
	public String name() { return name; }
	public int getBuildingsLimit() { return bldLimit; }
	//public ArrayList<Integer> rooms() { return rooms; }
}
