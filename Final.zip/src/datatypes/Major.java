package datatypes;

//import java.util.ArrayList;

public class Major
{
	private String name;
	private String department;
	private String college;
	//private ArrayList<Integer> courses;
	public Major(String name, String dept, String col)
	{
		this.name = name;
		department = dept;
		college = col;
	}
	public void setName(String name) { this.name = name; }
	public void setDepartment(String dept) { department = dept; }
	public void setCollege(String col) { college = col; }
	//public void setCourses(ArrayList<Integer> courses) { this.courses = courses; }
	public String name() { return name; }
	public String dept() { return department; }
	public String college() { return college; }
	//public ArrayList<Integer> courses() { return courses; }
}
