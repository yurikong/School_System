package util;

import javax.swing.JTable;

public class JTableHeaderValues {
	private JTable table;
	public JTableHeaderValues(JTable table) {
		this.table = table;
	}
	public String[] getTableHeaders(){
	    int cols = table.getColumnCount();
	    String[] headers = new String[cols];
	    for(int i = 0 ; i < cols ; i++){
	        headers[i] = (String) table.getColumnModel().getColumn(i).getHeaderValue();
	    }
	    return headers;
	}
}
