package util;

import javax.swing.JTable;

public class JTableEmpty {
	private JTable table;
	public JTableEmpty(JTable table) {
		this.table = table;
	}

}
