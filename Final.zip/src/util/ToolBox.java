package util;

import javax.swing.JTable;

import java.time.LocalDate;
import java.time.LocalTime;

public class ToolBox {
	public static boolean isEmptyJTable(JTable jTable) {
        if (jTable != null && jTable.getModel() != null) {
            return jTable.getModel().getRowCount()<=0?true:false;
        }
        return false;
    }
	
	public static boolean isNumeric(String strNum) {
	    try {
	        double d = Double.parseDouble(strNum);
	    } catch (NumberFormatException | NullPointerException nfe) {
	        return false;
	    }
	    return true;
	}
	public static boolean isTimeValid(LocalTime start, LocalTime end) {
		if(end.isAfter(start)) return true;
		return false;
	}
	
	public static boolean isTimeConflict(LocalTime[] A, LocalTime[] B){
		System.out.println("Table Time: " + A[0].toString() +  " - " + A[1].toString() );
		System.out.println("Input Time: " + B[0].toString() +  " - " + B[1].toString() + "\n");
		
		if(B[0].isAfter(A[1]) || A[0].isAfter(B[1])) return false;
		return true;
	}
	
	public static LocalTime[] timeRangeStringToLocalTime(String time)
	{
		String timeOnly = time.split(" ")[1];
		String start = timeOnly.split("-")[0];
		String end   = timeOnly.split("-")[1];
		LocalTime startParsed = LocalTime.parse(start);
		LocalTime endParsed = LocalTime.parse(end);
		return new LocalTime[] {startParsed,endParsed};
	}
	
	public boolean isFutureYear(int year){
		if(year >= LocalDate.now().getYear())
			return true;
		return false;
	}
//	public boolean isFutureSemester(String semester)
//	{
//		String curSemester = "";
//		LocalDate date = LocalDate.now();
//		int month = date.getMonthValue();
//		if(month >= 1 && month <= 6)
//			semester += "Spring";
//		if(month >= 7 && month <= 12)
//			semester += "Fall";
//		
//	}
//	public boolean isFutureTerm(String term)
//	{
//		String semester = term.split(" ")[0];
//		int year = Integer.parseInt(term.split(" ")[1]);
//		
//	}
}
