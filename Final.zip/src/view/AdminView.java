package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;

import controller.LoginController;
import controller.admin.admin.SuperAdminRemoveAdminController;
import controller.admin.admin.SuperAdminSetAdminController;
import controller.admin.building.AdminRemoveBuildingController;
import controller.admin.building.AdminAddBuildingController;
import controller.admin.college.AdminRemoveCollegeController;
import controller.admin.college.AdminSetCollegeController;
import controller.admin.course.AdminAddCoursePrereqControlller;
import controller.admin.course.AdminRemoveCourseController;
import controller.admin.course.AdminRemoveCoursePrereqController;
import controller.admin.course.AdminSelectPrereqCourseController;
import controller.admin.course.AdminAddCourseController;
import controller.admin.department.AdminRemoveDepartmentController;
import controller.admin.department.AdminSetDepartmentController;
import controller.admin.employee.AdminAddEmployeeSessionController;
import controller.admin.employee.AdminRemoveEmployeeController;
import controller.admin.employee.AdminRemoveEmployeeSessionController;
import controller.admin.employee.AdminSelectEmployeeController;
import controller.admin.employee.AdminSetEmployeeController;
import controller.admin.major.AdminRemoveMajorController;
import controller.admin.major.AdminAddMajorController;
import controller.admin.room.AdminRemoveRoomController;
import controller.admin.room.AdminSetRoomController;
import controller.admin.school.SuperAdminSetSchoolController;
import controller.admin.session.AdminRemoveSessionController;
import controller.admin.session.AdminSelectSessionController;
import controller.admin.session.AdminAddSessionController;
import controller.admin.student.AdminRemoveStudentController;
import controller.admin.student.AdminSelectStudentTableRowController;
import controller.admin.student.AdminSetStudentController;
import controller.admin.student.AdminSetStudentGradeController;
import controller.student.StudentAddClassController;
import util.JTextFieldLimit;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SpinnerDateModel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JSplitPane;
import javax.swing.JSpinner;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;

public class AdminView extends JFrame{
	
	private JPanel 		contentPane;
	public JTabbedPane tabbedPane;
	private JButton 	btnLogout;
	
	/*########### School Tab: ###########*/
	public JPanel schoolTab;
	public JButton schoolSaveButton;
	public JTextField schoolNameField;
	public JTextField schoolCurrentTermField;
	
/*########### Admin Tab: ###########*/
	public JTable adListTable;
	public JScrollPane scrollPane;
	public JPanel adminTab;
	public JPanel adminInfo;
	public JTextField adminFirstNameField;
	public JTextField adminMiddleNameField;
	public JTextField adminLastNamefield;
	public JTextField adminIDField;
	public JButton adminSaveButton;
	public JRadioButton adminAddRadioButton;
	public JRadioButton adminEditRadioButton;
	public ButtonGroup adminRBG;
		/****Remove****/
	public JPanel removeAdmin;
	public JTextField adminRemoveIDField;
	public JButton adminRemoveButton;
		/****AdminList****/
	public JPanel adminListPane;
	
/*########### Employee Tab: ###########*/
	public JPanel employeeContentPane;
	public JTabbedPane adminTabbedPane;
	public JTable empListTable;
	
	public JScrollPane empListPanel;

	/****Profile****/
	public JPanel adminProfile;	
		/****Employee****/
	public JTextField empProfilePWField;
	public JRadioButton empAddRadioButton;
	public JRadioButton empEditRadioButton;
	public JPanel employeInfo;
	public JLabel empNameLB;
	public JLabel empIDLB;
	public JTextField empProfileFirstNameField;
	public JTextField empProfileMiddleNameField;
	public JLabel empMiddleNameLB;
	public JTextField empProfielLastNameField;
	public JLabel emp;
	public JTextField empProfileIDField;
	public JButton empProfileSaveBtn;
	public JTable empAssignSessionTable;
	public JTable empUnassignSessionTable;

		/****Remove****/
	
	public JPanel removeEmployee;
	public JButton empRemoveButton;
	public JLabel empRIDLB;
	public JTextField empProfileRmIDField;
		/****EmployeeList****/
	public JPanel employeeList;

	/****Assign****/
	public JPanel adminAssign;
	public JButton empAssignButton;
	public JTextField empAssignNameField;
	public JLabel selectEmpName1;
		/****AssignList****/
	public JPanel sessionSchedulePane;
	
	/****Unassigns****/
	public JPanel adminUnAssign;
	public JButton empUnassignButton;
	public JTextField empUnassignNameField;
	public JLabel selectEmpName2;
		/****UnassignList****/
	public JPanel empSchedulePane;

/*########### Student Tab: ###########*/
	public JTable studentGradeTable;
	public JTextField studentProfilePWField;
	public JPanel studentContentPanel;
	public JTabbedPane studentTabbedPanel;
	/****Profile****/
	public JPanel studentProfile;
	public JTable studentProfileTable;
		/****Student****/
	public JComboBox studentProfileMajorComboBox;
	public JButton saveStudentGradeButton;
	public JPanel studentProfileInfo;
	public JLabel studentProfileMiddleLB;
	public JLabel studentLastLB;
	public JLabel studentProfileIDLB;
	public JLabel studentProfileFirstLB;
	public JLabel studentIDLB;
	public JTextField studentProfileLastNameField;
	public JTextField studentProfileMiddleNameField;
	public JTextField studentProfileFirstNameField;
	public JTextField studentProfileIDField;
	public JComboBox studentProfileTuitionComboBox;
	public JButton studentProfileSaveButton;
	public ButtonGroup stdRBG;
	public JRadioButton studentProfileAddRadioButton;
	public JRadioButton studentProfileEditRadioButton;
		/****Remove****/
	public JPanel studentProfileRemove;
	public JTextField studentProfileRemoveIDField;
	public JButton studentProfileRemoveButton;
		/****List****/
	public JPanel studentProfileList;
	/****Grade****/
	public JPanel studentGrade;
		/****Grade****/
	public JPanel studentGradeInfo;
	public JLabel lblStudentId;
	public JLabel lblGrade;
	public JTextField studentGradeIDField;
	public JComboBox studentGradeComboBox;
		/****Grade list****/
	public JPanel studentGradeList;
	
/*########### College Tab: ###########*/
	public JRadioButton collegeAddRadioButton;
	public JRadioButton collegeEditRadioButton;
	public JPanel collegeTab;
		/****College****/
	public JTable collegeTable;
	public JComboBox collegeDeanComboBox;
	public JPanel collegeInfo;
	public JLabel collegeNameLB;
	public JLabel collegeDeanLB;
	public JTextField collegeNameField;
	public JButton collegeAddButton;
	public ButtonGroup collegeRBG;
		/****Remove****/
	public JPanel collegeRemovePane;
	public JButton collegeRemoveButton;
	public JLabel collegeRMLB;
	public JTextField collegeRemoveField;
		/****College List****/
	public JPanel collegeList;
	
/*########### Department Tab: ###########*/
	public JRadioButton departmentAddRadioButton;
	public JRadioButton departmentEditRadioButton;
	public JPanel departmentTab;
	public JTable departmentTable;
	public JComboBox departmentChairComboBox;

		/****Department****/
	public JPanel dpInfo;
	public JLabel dpNameLB;
	public JLabel dpCharLB;
	public JTextField departmentNameField;
	public JComboBox departmentCollegeComboBox;
	public JButton departmentSaveButton;
	public ButtonGroup dpRBG;
		/****Remove****/
	public JPanel dpRemove;
	public JButton departmentRemoveButton;
	public JLabel dpRMLB;
	public JTextField departmentRemoveDepartmentField;
		/****Department List****/
	public JPanel dpList;
	public JLabel adName;
/*########### Major Tab: ###########*/
	public JTable majorTable;
	public JPanel majorTab;
		/****Major****/
	public JPanel majorInfo;
	public JTextField majorNameField;
	public JButton majorSaveButton;
	public ButtonGroup majorRBG;
	public JComboBox majorDpCB;
		/****Remove****/
	public JPanel majorRemove;
	public JButton majorRemoveButton;
	public JLabel majorRmDpLb;
	public JTextField majorRemoveField;
		/****Major List****/
	public JPanel majorList;

	/*########### Course Tab: ###########*/
	public JPanel courseContentPane;
	public JTabbedPane courseTabbedPane;
	/****Course****/
	public JPanel coursePanel;
		/****CourseInfo****/
	public JPanel courseInfo;
	public JLabel courseNameLB;
	public JTextField courseNameField;
	public JButton courseSaveButton;
	public ButtonGroup courseRBG;
	public JLabel courseMjLB;
	public JComboBox courseMajorComboBox;
		/****Remove****/
	public JPanel courseRemove;
	public JButton courseRemoveButton;
	public JLabel courseRmLB;
	public JTextField courseRemoveCourseField;
		/****CourseList****/
	public JPanel courseList;
	/****Pre-req****/
	public JPanel preqPanel;
		/****pre-req Info****/
	public JPanel prereqInfo;
	public JLabel prereqSCLB;
	public JTextField prereqSelectCourseField;
		/****Add****/
	public JPanel prereqAdd;
	public JLabel prereqAddCLB;
	public JButton prereqAddButton;
		/****Remove****/
	public JPanel prereqRemove;
	public JLabel prereqRmLB;
	public JTextField prereqRemoveCourseField;
	public JButton prereqRemoveButton;
		/****List****/
	public JPanel prereqList;

	
	/*########### Session Tab: ###########*/
	public JSpinner startTimeSpinner;
	public JPanel sessionTab;
	/****Session****/
	public JPanel sessionProfile;
	public JLabel lblCourse;
	public JLabel sessionStartTimeField;
	public JTextField sessionYearField;
	public JComboBox sessionComboBox;
	public JComboBox sessionSemesterComboBox;
	public JComboBox sessionDayComboBox;
	public JComboBox sessionLocationComboBox;
	public ButtonGroup sessionRBG;
	public JButton sessionSaveButton;
		/****Remove****/
	public JPanel sessionRemove;
	public JLabel label_2;
	public JButton sessionRemoveButton;
	public JTextField sessionRemoveField;
		/****List****/
	public JPanel sessionList;
	
	
	/*############### Room Tab: ###############*/
	public JPanel roomTab;
		/****Room****/
	public JTable roomTable;
	public JComboBox roomBuildingComboBox;
	public JPanel roomInfo;
	public JLabel lblLimit;
	public JLabel lblId_1;
	public JLabel lblBuidling;
	public JTextField roomLimitField;
	public JTextField roomNumberField;
	public JButton roomSaveButton;
	public ButtonGroup roomRBG;
		/****Remove****/
	public JPanel roomRemove;
	public JLabel label;
	public JTextField roomRemoveField;
	public JButton roomRemoveButton;
		/****List****/
	public JPanel roomList;
	
	/*############### Building Tab: ###############*/
	public JPanel buildingTab;
		/****Buidling****/
	public JTable buildingTable;
	public JPanel buildingInfo;
	public JLabel label_3;
	public JLabel lblOccu;
	public JTextField buidlingNameField;
	public JTextField buildingOccupationField;
	public JButton buildingSaveButton;
	public ButtonGroup buidlingRBG; 
		/****Remove****/
	public JPanel buidlingRemove;
	public JLabel lblBuilding;
	public JTextField buidlingRemoveField;
	public JButton buildingRemoveButton;
		/****List****/
	public JPanel buidlingList;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	public JTextField adminPWField;
	private JLabel lblPw;

	private JScrollPane scrollPane_2;
	private JScrollPane scrollPane_3;
	private JScrollPane scrollPane_4;
	private JScrollPane scrollPane_5;
	public JTable courseTable;
	private JScrollPane courseScrollPanel;
	public JTable prereqTable;
	public JScrollPane prereqScrollPanel;
	public JComboBox prereqdCourseCombox;
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	public JTextField empProfileSalaryField;
	private final ButtonGroup buttonGroup_2 = new ButtonGroup();
	public JTable sessionTable;
	public JTable rosterTable;
	private JScrollPane scrollPane_6;
	private JPanel panel_2;
	public JSpinner endTimeSpinner;
	public JLabel adRole;
	//private final ButtonGroup buttonGroup = new ButtonGroup();
	
	public AdminView() {
		//initDate();
		initComponents();
		createEvents();
		this.setVisible(true);
	}
	
	/*
	public void initData() {
		
	}*/
	
	/*########### CallController: ###########*/
		//School
	public void addSetSchoolInfoController		(SuperAdminSetSchoolController controller ) 		{ schoolSaveButton.addActionListener(controller); } ;
		//Admin
	public void addSetAdminController			(SuperAdminSetAdminController controller ) 			{ adminSaveButton.addActionListener(controller);}
	public void addRemoveAdminController 		(SuperAdminRemoveAdminController controller ) 		{ adminRemoveButton.addActionListener(controller);};
		//Employee
	public void addAddEmployeeSessionController	(AdminAddEmployeeSessionController controller ) 	{ empAssignButton.addActionListener(controller); };
	public void addRemoveEmployeeSessionController(AdminRemoveEmployeeSessionController controller)	{ empUnassignButton.addActionListener(controller); };
	public void addRemoveEmployeeController		(AdminRemoveEmployeeController controller) 			{ empRemoveButton.addActionListener(controller); }
	public void addSetEmployeeController		(AdminSetEmployeeController controller) 			{ empProfileSaveBtn.addActionListener(controller); };
	public void addSelectEmployeeController		(AdminSelectEmployeeController controller) 			{ empListTable.addMouseListener(controller);};
		//Student
	public void addAdminSelectStudentTableRow   (AdminSelectStudentTableRowController controller)   { studentProfileTable.addMouseListener(controller);}
	public void addRemoveStudentController		(AdminRemoveStudentController controller)			{ studentProfileRemoveButton.addActionListener(controller); };
	public void addSetStudentController			(AdminSetStudentController controller)				{ studentProfileSaveButton.addActionListener(controller); };
	public void addSetStudentGradeController 	(AdminSetStudentGradeController controller)			{ saveStudentGradeButton.addActionListener(controller);};
		//College
	public void addRemoveCollegeController		(AdminRemoveCollegeController controller) 			{ collegeRemoveButton.addActionListener(controller);};
	public void addSetCollegeController			(AdminSetCollegeController controller) 				{ collegeAddButton.addActionListener(controller);};
		//Department
	public void addRemoveDeparmentController	(AdminRemoveDepartmentController controller) 		{ departmentRemoveButton.addActionListener(controller);};
	public void addSetDepartmentController		(AdminSetDepartmentController controller) 			{ departmentSaveButton.addActionListener(controller);};
	//public void addSelectCollegeController		(AdminSelectCollegeController controller)			{ departmentCollegeComboBox.addActionListener(controller); };
		//Major
	public void addRemoveMajorController		(AdminRemoveMajorController controller)				{ majorRemoveButton.addActionListener(controller);};
	public void addAddMajorController			(AdminAddMajorController controller) 				{ majorSaveButton.addActionListener(controller);};
	//public void addSelectDepartmentController	(AdminSelectCollegeController controller)			{ };

		//Course
	public void addAddCoursePrereqController	(AdminAddCoursePrereqControlller controller)		{ prereqAddButton.addActionListener(controller);};
	public void addRemoveCourseController		(AdminRemoveCourseController controller) 			{ courseRemoveButton.addActionListener(controller);};
	public void addRemoveCoursePrereqController	(AdminRemoveCoursePrereqController controller) 		{ prereqRemoveButton.addActionListener(controller);};
	public void addAddCourseController			(AdminAddCourseController controller)				{ courseSaveButton.addActionListener(controller);};
	public void addSelectPrereqCourseController (AdminSelectPrereqCourseController controller)		{ courseTable.addMouseListener(controller);};
	//public void addSelectMajorController		(AdminSelectMajorController controller)				{ };

		//Session
	public void addRemoveSessionController		(AdminRemoveSessionController controller)			{ sessionRemoveButton.addActionListener(controller);};
	public void addAddSessionController 		(AdminAddSessionController controller)				{ sessionSaveButton.addActionListener(controller);};
	public void addSelectCourseController		(AdminSelectSessionController controller)			{ sessionTable.addMouseListener(controller);};

		//Room
	public void addRemoveRoomController			(AdminRemoveRoomController controller)				{ roomRemoveButton.addActionListener(controller);};
	public void addSetRoomController			(AdminSetRoomController controller) 				{ roomSaveButton.addActionListener(controller);};

		//Building
	public void addSetBuildingController		(AdminAddBuildingController controller)				{ buildingSaveButton.addActionListener(controller);};
	public void addRemoveBuildingController		(AdminRemoveBuildingController controller)			{ buildingRemoveButton.addActionListener(controller);};

	
	/*########### Call Handler: ###########*/
	public void createEvents() {
	//======= Logout=======//
		JFrame _this = this;
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				_this.dispose();
				LoginController login = new LoginController();
				login.init();
			}
		});
		
	//======= School =======//
	//======= Admin =======//
		adListTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				adminEditRadioButton.setSelected(true);
				
				TableModel tModel = adListTable.getModel();
				int i = adListTable.getSelectedRow();
				adminIDField.setText		(tModel.getValueAt(i, 0).toString());
				adminPWField.setText		(tModel.getValueAt(i, 1).toString());
				adminFirstNameField.setText	(tModel.getValueAt(i, 2).toString());
				adminMiddleNameField.setText(tModel.getValueAt(i, 3).toString());
				adminLastNamefield.setText	(tModel.getValueAt(i, 4).toString());
				adminRemoveIDField.setText	(tModel.getValueAt(i, 0).toString());
			}
		});
		// Add Option Selected
		adminAddRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adListTable.getSelectionModel().clearSelection();
				adminIDField.setText		("");
				adminFirstNameField.setText	("");
				adminPWField.setText		("");
				adminMiddleNameField.setText("");
				adminLastNamefield.setText	("");
			}
		});
		// Edit Option Selected
		adminEditRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
	//======= Employee =======//
		
		// <<< Profile Tab >>> //
			// Add-Option Selected
		empAddRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				empListTable.getSelectionModel().clearSelection();
				empProfileIDField.setText("");
				empProfileFirstNameField.setText("");
				empProfilePWField.setText("");
				empProfileMiddleNameField.setText("");
				empProfielLastNameField.setText("");
				empProfileSalaryField.setText("");

				
				// current emp name for assign & unassign tab:
				empAssignNameField.setText("");
				empUnassignNameField.setText("");
			}
		});
			// Edit-Option Selected
		empEditRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		// <<< Assign Tab >>> //
		empAssignSessionTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				TableModel tModel = empAssignSessionTable.getModel();
				int i = empAssignSessionTable.getSelectedRow();
				
				empProfileIDField.setText		(tModel.getValueAt(i, 0).toString());
				empProfileFirstNameField.setText(tModel.getValueAt(i, 1).toString());
				empProfileMiddleNameField.setText(tModel.getValueAt(i, 2).toString());
				empProfielLastNameField.setText	(tModel.getValueAt(i, 3).toString());
				empProfileRmIDField.setText		(tModel.getValueAt(i, 0).toString());

			}
		});
	//======= Student =======//
		studentProfileMajorComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TableModel tModel = studentProfileTable.getModel();
				int i = studentProfileTable.getSelectedRow();
				if( i != -1 ) {
					String selectedMajor = (String) studentProfileMajorComboBox.getSelectedItem();
					tModel.setValueAt(selectedMajor, i, 5);
				}
			}
		});
		
		studentProfileTuitionComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TableModel tModel = studentProfileTable.getModel();
				int i = studentProfileTable.getSelectedRow();
				if( i != -1) {
					String selectedTuitionStatus = (String) studentProfileTuitionComboBox.getSelectedItem(); 
					tModel.setValueAt(selectedTuitionStatus, i, 6);
				}
			}
		});
		
		// Add Option Selected
		studentProfileAddRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				studentProfileTable.getSelectionModel().clearSelection();
				studentProfileFirstNameField.setText	("");
				studentProfileMiddleNameField.setText	("");
				studentProfileLastNameField.setText		("");
				studentProfileIDField.setText			("");
				studentProfilePWField.setText			("");
				studentProfileMajorComboBox.setSelectedIndex(0);
				studentProfileTuitionComboBox.setSelectedIndex(0);
				studentGradeIDField.setText				("");
			}
		});
		// Edit Option Selected
		adminEditRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		// Grade Tab
		studentGradeComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TableModel tModel = studentGradeTable.getModel();
				int i = studentGradeTable.getSelectedRow();
				if( i != -1) {
					String selectedGrade = (String) studentGradeComboBox.getSelectedItem(); 
					tModel.setValueAt(selectedGrade, i, 3);
				}
			}
		});
	//======= College =======//
		collegeTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TableModel tModel = collegeTable.getModel();
				int i = collegeTable.getSelectedRow();
				collegeEditRadioButton.setSelected(true);

				collegeNameField.setText			(tModel.getValueAt(i, 0).toString());
//				collegeDeanComboBox.setSelectedItem	(tModel.getValueAt(i, 1));
				collegeNameField.setEditable(false);
				collegeRemoveField.setText			(tModel.getValueAt(i, 0).toString());
			}
		});
		collegeAddRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				collegeTable.getSelectionModel().clearSelection();
				collegeNameField.setEditable(true);;
				//collegeDeanComboBox.setSelectedIndex(-1);
				collegeNameField.setText("");
			}
		});
		collegeEditRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				collegeNameField.setEditable(false);
			}
		});
				
	//Department
		departmentTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TableModel tModel = departmentTable.getModel();
				int i = departmentTable.getSelectedRow();
				departmentEditRadioButton.setSelected(true);
				departmentNameField.setEditable(false);
				departmentNameField.setText(tModel.getValueAt(i, 0).toString());
				departmentRemoveDepartmentField.setText			(tModel.getValueAt(i, 0).toString());
				
				//collegeDeanComboBox.setSelectedItem	(tModel.getValueAt(i, 1));
				departmentCollegeComboBox.setEnabled(false);
			}
		});
		departmentAddRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departmentTable.getSelectionModel().clearSelection();
				departmentNameField.setEditable(true);
				//departmentChairComboBox.setSelectedIndex(-1);
				//departmentCollegeComboBox.setSelectedIndex(-1);
				departmentCollegeComboBox.setEnabled(true);
				departmentNameField.setText("");
			}	
		});
		departmentEditRadioButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				departmentNameField.setEditable(false);
				departmentCollegeComboBox.setEnabled(false);
			}
		});
		
	//Major
		majorTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TableModel tModel = majorTable.getModel();
				int i = majorTable.getSelectedRow();
				majorRemoveField.setText		(tModel.getValueAt(i, 0).toString());
			}
		});
	//Course
		courseTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TableModel tModel = courseTable.getModel();
				int i = courseTable.getSelectedRow();
				courseRemoveCourseField.setText	(tModel.getValueAt(i, 0).toString());
				prereqSelectCourseField.setText	(tModel.getValueAt(i, 1).toString());
				
			}
		});
		
		prereqTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TableModel tModel = prereqTable.getModel();
				int i = prereqTable.getSelectedRow();
				prereqRemoveCourseField.setText	(tModel.getValueAt(i, 0).toString());
			}
		});
		
		
	//Session
	//Room
		roomTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TableModel tModel = roomTable.getModel();
				int i = roomTable.getSelectedRow();
				roomRemoveField.setText	(tModel.getValueAt(i, 0).toString());
			}
		});
		
	//Building
		buildingTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TableModel tModel = buildingTable.getModel();
				int i = buildingTable.getSelectedRow();
				buidlingRemoveField.setText	(tModel.getValueAt(i, 0).toString());
			}
		});
	}
	
	public void initComponents(){
		//-Jframe Windows:
		jframeComponent();
		
		//-Menu Component:
		menuComponent();
		
		//-Tab Component:
		tabComponent();
		
		//+schoolTabPanel Component:
		schoolTabComponent();
		
		//+adminTabPanel Component:
		adminTabComponent();
		
		//+employeeTabPanel Component:
		employeeTabComponent();
		
		//+studentTabPanel Component:
		studentTabComponent();
		
		//+CollegeTabPanel Component:
		collegeTabComponent();
		
		//+departmentTabPanel Component:
		departmentTabComponent();
		
		//+majorTabPanel Component:
		majorTabComponent();
		
		//+courseTabPanel Component:
		courseTabComponent();
		
		//+roomTabPanel Component:
		roomTabComponent();
		
		//+buildTabPanel Component:
		buildingTabComponent();
		
		//+sessionTabPanel Component:
		sessionTabComponent();
		collegeNameField.setDocument(new JTextFieldLimit(60));

		
	}
	
	public void jframeComponent() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 910, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
	}
	
	public void menuComponent() {
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mnFile.add(mntmExit);
		
		JMenu mnAbout = new JMenu("About");
		menuBar.add(mnAbout);
		
		JMenuItem mntmInfo = new JMenuItem("Info");
		mnAbout.add(mntmInfo);
		
		JPanel panel = new JPanel();
		menuBar.add(panel);
		panel.setLayout(new BorderLayout(0, 0));
		
		btnLogout = new JButton("Logout");

		panel.add(btnLogout, BorderLayout.EAST);
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(null);
		
		adName = new JLabel("Name");
		adName.setBounds(19, 6, 145, 14);
		panel_1.add(adName);
		
		adRole = new JLabel("Role");
		adRole.setBounds(170, 5, 104, 16);
		panel_1.add(adRole);
		
		// Menu bar handler
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int opt = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?");
				if(opt == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});
	}
	
	public void tabComponent() {
		contentPane.setLayout(null);
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(5, 5, 900, 527);
		contentPane.add(tabbedPane);
	}
	/*########### College Tab: ###########*/
	public void collegeTabComponent() {
		collegeTab = new JPanel();
		tabbedPane.addTab("College", null, collegeTab, null);
		collegeTab.setLayout(null);
		
		
		/****************College*****************/
		collegeInfo = new JPanel();
		collegeInfo.setLayout(null);
		collegeInfo.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "College", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		collegeInfo.setBounds(10, 40, 210, 145);
		collegeTab.add(collegeInfo);
		
		collegeNameLB = new JLabel("Name :");
		collegeNameLB.setBounds(16, 30, 38, 14);
		collegeInfo.add(collegeNameLB);
		
		collegeDeanLB = new JLabel("Dean :");
		collegeDeanLB.setBounds(16, 68, 38, 14);
		collegeInfo.add(collegeDeanLB);
		
		collegeNameField = new JTextField();
		collegeNameField.setColumns(10);
		collegeNameField.setBounds(64, 27, 127, 20);
		collegeInfo.add(collegeNameField);
		
		collegeAddButton = new JButton("Set");
		collegeAddButton.setBounds(120, 104, 71, 23);
		collegeInfo.add(collegeAddButton);
		
		//Group Button method
		collegeRBG = new ButtonGroup();
		
		collegeDeanComboBox = new JComboBox();
		collegeDeanComboBox.setBounds(64, 64, 127, 22);
		collegeInfo.add(collegeDeanComboBox);
		
		collegeAddRadioButton = new JRadioButton("Add");
		collegeAddRadioButton.setSelected(true);
		buttonGroup_1.add(collegeAddRadioButton);
		collegeAddRadioButton.setBounds(6, 102, 57, 23);
		collegeInfo.add(collegeAddRadioButton);
		
		collegeEditRadioButton = new JRadioButton("Edit");
		buttonGroup_1.add(collegeEditRadioButton);
		collegeEditRadioButton.setBounds(64, 102, 57, 23);
		collegeInfo.add(collegeEditRadioButton);
		
		/****************Remove*****************/
		collegeRemovePane = new JPanel();
		collegeRemovePane.setLayout(null);
		collegeRemovePane.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Remove", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		collegeRemovePane.setBounds(10, 292, 210, 120);
		collegeTab.add(collegeRemovePane);
		
		collegeRemoveButton = new JButton("Remove");
		collegeRemoveButton.setBounds(115, 79, 71, 23);
		collegeRemovePane.add(collegeRemoveButton);
		
		collegeRMLB = new JLabel("College :");
		collegeRMLB.setBounds(16, 51, 44, 14);
		collegeRemovePane.add(collegeRMLB);
		
		collegeRemoveField = new JTextField();
		collegeRemoveField.setEditable(false);
		collegeRemoveField.setColumns(10);
		collegeRemoveField.setBounds(68, 48, 118, 20);
		collegeRemovePane.add(collegeRemoveField);
		
		/****************College List*****************/
		collegeList = new JPanel();
		collegeList.setLayout(null);
		collegeList.setBorder(new TitledBorder(null, "College List", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		collegeList.setBounds(230, 11, 519, 477);
		collegeTab.add(collegeList);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 25, 499, 441);
		collegeList.add(scrollPane_1);
		
		collegeTable = new JTable(){
		    public boolean isCellEditable(int row, int column) {
		        return false; 
		    }
		};
		scrollPane_1.setViewportView(collegeTable);
	}
	/*########### School Tab: ###########*/
	public void schoolTabComponent() {
	}
	
	/*########### Admin Tab: ###########*/
	public void adminTabComponent() {
		schoolTab = new JPanel();
		tabbedPane.addTab("School", null, schoolTab, null);
		JLabel lblSchoolName = new JLabel("School Name :");
		lblSchoolName.setBounds(199, 175, 90, 14);
		
		JLabel lblCurrentTerm = new JLabel("Current Term :");
		lblCurrentTerm.setBounds(199, 220, 108, 14);
		
		schoolNameField = new JTextField();
		schoolNameField.setBounds(316, 172, 167, 20);
		schoolNameField.setColumns(10);
		schoolNameField.setDocument(new JTextFieldLimit(60));
		
		schoolTab.setLayout(null);
		schoolTab.add(lblSchoolName);
		schoolTab.add(lblCurrentTerm);
		schoolTab.add(schoolNameField);
		
		schoolCurrentTermField = new JTextField();
		schoolCurrentTermField.setColumns(10);
		schoolCurrentTermField.setBounds(316, 217, 167, 20);
		schoolCurrentTermField.setEditable(false);
		schoolTab.add(schoolCurrentTermField);
		
		schoolSaveButton = new JButton("Save");
		
			schoolSaveButton.setBounds(366, 323, 117, 29);
			schoolTab.add(schoolSaveButton);
		adminTab = new JPanel();
		tabbedPane.addTab("Admin", null, adminTab, null);
		adminTab.setLayout(null);
		
		/****************Admin*****************/
		adminInfo = new JPanel();
		adminInfo.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Admin", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		adminInfo.setBounds(10, 40, 210, 230);
		adminTab.add(adminInfo);
		
		JLabel lblFirstname = new JLabel("FirstName:");
		lblFirstname.setBounds(16, 30, 32, 14);
		
		JLabel label_1 = new JLabel("ID:");
		label_1.setBounds(16, 115, 46, 14);
		
		adminFirstNameField = new JTextField();
		adminFirstNameField.setBounds(64, 27, 127, 20);
		adminFirstNameField.setColumns(10);
		
		adminIDField = new JTextField();
		adminIDField.setBounds(64, 112, 127, 20);
		adminIDField.setEditable(false);
		adminIDField.setColumns(10);
		
		adminInfo.setLayout(null);
		adminInfo.add(lblFirstname);
		adminInfo.add(label_1);
		adminInfo.add(adminFirstNameField);
		adminInfo.add(adminIDField);
		
		adminSaveButton = new JButton("Save");
		adminSaveButton.setBounds(133, 185, 71, 23);
		adminInfo.add(adminSaveButton);
		
		adminAddRadioButton = new JRadioButton("Add");
		adminAddRadioButton.setSelected(true);

		adminAddRadioButton.setBounds(6, 183, 57, 23);
		adminInfo.add(adminAddRadioButton);
		
		adminEditRadioButton = new JRadioButton("Edit");
		adminEditRadioButton.setSelected(true);

		adminEditRadioButton.setBounds(73, 183, 57, 23);
		adminInfo.add(adminEditRadioButton);
		
		//Group Button method
		adminRBG = new ButtonGroup();
		adminRBG.add(adminAddRadioButton);
		adminRBG.add(adminEditRadioButton);
		
		JLabel lblNewLabel = new JLabel("Middle :");
		lblNewLabel.setBounds(16, 56, 61, 16);
		adminInfo.add(lblNewLabel);
		
		JLabel lblLast = new JLabel("Last :");
		lblLast.setBounds(16, 84, 61, 16);
		adminInfo.add(lblLast);
		
		adminMiddleNameField = new JTextField();
		adminMiddleNameField.setColumns(10);
		adminMiddleNameField.setBounds(64, 59, 127, 20);
		adminMiddleNameField.setDocument(new JTextFieldLimit(1));

		adminInfo.add(adminMiddleNameField);
		
		adminLastNamefield = new JTextField();
		adminLastNamefield.setColumns(10);
		adminLastNamefield.setBounds(64, 84, 127, 20);
		adminInfo.add(adminLastNamefield);
		
		adminPWField = new JTextField();
		adminPWField.setColumns(10);
		adminPWField.setBounds(64, 140, 127, 20);
		adminInfo.add(adminPWField);
		
		lblPw = new JLabel("PW:");
		lblPw.setBounds(16, 143, 46, 14);
		adminInfo.add(lblPw);
		
		/****************Remove*****************/
		removeAdmin = new JPanel();
		removeAdmin.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Remove", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		removeAdmin.setBounds(10, 292, 210, 120);
		adminTab.add(removeAdmin);
		
		adminRemoveButton = new JButton("Remove");
		adminRemoveButton.setBounds(115, 79, 71, 23);
		
		JLabel lblId = new JLabel("ID:");
		lblId.setBounds(16, 51, 25, 14);
		
		adminRemoveIDField = new JTextField();
		adminRemoveIDField.setBounds(68, 48, 118, 20);
		adminRemoveIDField.setEditable(false);
		adminRemoveIDField.setColumns(10);
		
		removeAdmin.setLayout(null);
		removeAdmin.add(adminRemoveButton);
		removeAdmin.add(lblId);
		removeAdmin.add(adminRemoveIDField);
		
		/****************Admin List*****************/
		adminListPane = new JPanel();
		adminListPane.setBorder(new TitledBorder(null, "Admin List", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		adminListPane.setBounds(230, 11, 519, 477);
		adminTab.add(adminListPane);
		adminListPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(16, 26, 482, 430);
		adminListPane.add(scrollPane);
		
		adListTable = new JTable(){
			public boolean isCellEditable(int row, int column) {
				return false; 
			}
		};

		scrollPane.setViewportView(adListTable);
	}
	
	/*########### Employee Tab: ###########*/
	public void employeeTabComponent() {
		employeeContentPane = new JPanel();
		tabbedPane.addTab("Employee", null, employeeContentPane, null);
		employeeContentPane.setLayout(null);
		
		adminTabbedPane = new JTabbedPane(JTabbedPane.TOP);
		adminTabbedPane.setBounds(10, 11, 749, 478);
		employeeContentPane.add(adminTabbedPane);
		
		/****************Profile*****************/
		adminProfile = new JPanel();
		adminTabbedPane.addTab("Profiles", null, adminProfile, null);
		adminProfile.setLayout(null);
		
		employeInfo = new JPanel();
		employeInfo.setLayout(null);
		employeInfo.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Employee", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		employeInfo.setBounds(10, 11, 210, 253);
		adminProfile.add(employeInfo);
		
		empNameLB = new JLabel("First :");
		empNameLB.setBounds(16, 30, 32, 14);
		employeInfo.add(empNameLB);
		
		empIDLB = new JLabel("ID:");
		empIDLB.setBounds(16, 120, 36, 14);
		employeInfo.add(empIDLB);
		
		empProfileFirstNameField = new JTextField();
		empProfileFirstNameField.setColumns(10);
		empProfileFirstNameField.setBounds(64, 27, 127, 20);
		employeInfo.add(empProfileFirstNameField);
		
		empProfileIDField = new JTextField();
		empProfileIDField.setEditable(false);
		empProfileIDField.setColumns(10);
		empProfileIDField.setBounds(64, 117, 127, 20);
		employeInfo.add(empProfileIDField);
		
		empProfileSaveBtn = new JButton("Save");
		empProfileSaveBtn.setBounds(131, 216, 71, 23);
		employeInfo.add(empProfileSaveBtn);
		
		empProfileMiddleNameField = new JTextField();
		empProfileMiddleNameField.setColumns(10);
		empProfileMiddleNameField.setBounds(64, 56, 127, 20);
		empProfileMiddleNameField.setDocument(new JTextFieldLimit(1));

		employeInfo.add(empProfileMiddleNameField);
		
		empMiddleNameLB = new JLabel("Middle :");
		empMiddleNameLB.setBounds(16, 59, 47, 14);
		employeInfo.add(empMiddleNameLB);
		
		empProfielLastNameField = new JTextField();
		empProfielLastNameField.setColumns(10);
		empProfielLastNameField.setBounds(64, 85, 127, 20);
		employeInfo.add(empProfielLastNameField);
		
		emp = new JLabel("Last :");
		emp.setBounds(16, 88, 32, 14);
		employeInfo.add(emp);
		
		empAddRadioButton = new JRadioButton("Add");
		buttonGroup.add(empAddRadioButton);
		empAddRadioButton.setSelected(true);
		empAddRadioButton.setBounds(4, 214, 57, 23);
		employeInfo.add(empAddRadioButton);
		
		empEditRadioButton = new JRadioButton("Edit");
		buttonGroup.add(empEditRadioButton);
		empEditRadioButton.setBounds(71, 214, 57, 23);
		employeInfo.add(empEditRadioButton);
		
		JLabel empPWLB = new JLabel("PW:");
		empPWLB.setBounds(17, 150, 32, 14);
		employeInfo.add(empPWLB);
		
		empProfilePWField = new JTextField();
		empProfilePWField.setColumns(10);
		empProfilePWField.setBounds(65, 146, 127, 20);
		employeInfo.add(empProfilePWField);
		
		empProfileSalaryField = new JTextField();
		empProfileSalaryField.setBounds(67, 176, 126, 26);
		employeInfo.add(empProfileSalaryField);
		empProfileSalaryField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Salary:");
		lblNewLabel_1.setBounds(16, 183, 50, 16);
		employeInfo.add(lblNewLabel_1);
		
		removeEmployee = new JPanel();
		removeEmployee.setLayout(null);
		removeEmployee.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Remove", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		removeEmployee.setBounds(10, 291, 210, 102);
		adminProfile.add(removeEmployee);
		
		empRemoveButton = new JButton("Remove");
		empRemoveButton.setBounds(113, 60, 71, 23);
		removeEmployee.add(empRemoveButton);
		
		empRIDLB = new JLabel("ID:");
		empRIDLB.setBounds(14, 32, 25, 14);
		removeEmployee.add(empRIDLB);
		
		empProfileRmIDField = new JTextField();
		empProfileRmIDField.setEditable(false);
		empProfileRmIDField.setColumns(10);
		empProfileRmIDField.setBounds(66, 29, 118, 20);
		removeEmployee.add(empProfileRmIDField);
		
		employeeList = new JPanel();
		employeeList.setLayout(null);
		employeeList.setBorder(new TitledBorder(null, "Employee List", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		employeeList.setBounds(225, 0, 519, 450);
		adminProfile.add(employeeList);
		
		empListPanel = new JScrollPane();
		empListPanel.setBounds(10, 25, 489, 402);
		employeeList.add(empListPanel);
		
		empListTable = new JTable(){
		    public boolean isCellEditable(int row, int column) {
		        return false; 
		    }
		};
		empListPanel.setViewportView(empListTable);
		
		/****************Assign*****************/
		adminAssign = new JPanel();
		adminTabbedPane.addTab("Assign", null, adminAssign, null);
		adminAssign.setLayout(null);
		
		sessionSchedulePane = new JPanel();
		sessionSchedulePane.setLayout(null);
		sessionSchedulePane.setBorder(new TitledBorder(null, "Session Schedule", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		sessionSchedulePane.setBounds(204, 11, 530, 428);
		adminAssign.add(sessionSchedulePane);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 26, 510, 391);
		sessionSchedulePane.add(scrollPane_1);
		
		empAssignSessionTable = new JTable(){
		    public boolean isCellEditable(int row, int column) {
		        return false; 
		    }
		};
		scrollPane_1.setViewportView(empAssignSessionTable);
		
		empAssignButton = new JButton("Assign");
		empAssignButton.setBounds(101, 401, 71, 23);
		adminAssign.add(empAssignButton);
		
		empAssignNameField = new JTextField();
		empAssignNameField.setEditable(false);
		empAssignNameField.setColumns(10);
		empAssignNameField.setBounds(20, 124, 127, 20);
		adminAssign.add(empAssignNameField);
		
		selectEmpName1 = new JLabel("Employee Name:");
		selectEmpName1.setBounds(10, 99, 127, 14);
		adminAssign.add(selectEmpName1);
		
		/****************Unassign*****************/
		adminUnAssign = new JPanel();
		adminTabbedPane.addTab("Unassign", null, adminUnAssign, null);
		adminUnAssign.setLayout(null);
		
		empSchedulePane = new JPanel();
		empSchedulePane.setLayout(null);
		empSchedulePane.setBorder(new TitledBorder(null, "Session Schedule", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		empSchedulePane.setBounds(204, 11, 530, 428);
		adminUnAssign.add(empSchedulePane);
		
		scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(10, 29, 510, 388);
		empSchedulePane.add(scrollPane_2);
		
		empUnassignSessionTable = new JTable(){
		    public boolean isCellEditable(int row, int column) {
		        return false; 
		    }
		};
		scrollPane_2.setViewportView(empUnassignSessionTable);
		
		empUnassignNameField = new JTextField();
		empUnassignNameField.setEditable(false);
		empUnassignNameField.setColumns(10);
		empUnassignNameField.setBounds(33, 122, 127, 20);
		adminUnAssign.add(empUnassignNameField);
		
		selectEmpName2 = new JLabel("Employee Name:");
		selectEmpName2.setBounds(10, 97, 150, 14);
		adminUnAssign.add(selectEmpName2);
		
		empUnassignButton = new JButton("Unassign");
		empUnassignButton.setBounds(86, 399, 99, 23);
		adminUnAssign.add(empUnassignButton);
	}
	
	/*########### Student Tab: ###########*/
	public void studentTabComponent() {
		studentContentPanel = new JPanel();
		tabbedPane.addTab("Student", null, studentContentPanel, null);
		studentContentPanel.setLayout(null);
		
		/****************Student*****************/
		studentTabbedPanel = new JTabbedPane(JTabbedPane.TOP);
		studentTabbedPanel.setBounds(10, 11, 749, 478);
		studentContentPanel.add(studentTabbedPanel);
			/****************Profile*****************/			
		studentProfile = new JPanel();
		studentTabbedPanel.addTab("Profile", null, studentProfile, null);
		studentProfile.setLayout(null);
		
		studentProfileRemove = new JPanel();
		studentProfileRemove.setLayout(null);
		studentProfileRemove.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Remove", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		studentProfileRemove.setBounds(10, 291, 210, 120);
		studentProfile.add(studentProfileRemove);
		
		studentProfileRemoveButton = new JButton("Remove");
		studentProfileRemoveButton.setBounds(115, 79, 71, 23);
		studentProfileRemove.add(studentProfileRemoveButton);
		
		studentProfileIDLB = new JLabel("ID:");
		studentProfileIDLB.setBounds(16, 51, 25, 14);
		studentProfileRemove.add(studentProfileIDLB);
		
		studentProfileRemoveIDField = new JTextField();
		studentProfileRemoveIDField.setColumns(10);
		studentProfileRemoveIDField.setEditable(false);
		studentProfileRemoveIDField.setBounds(68, 48, 118, 20);
		studentProfileRemove.add(studentProfileRemoveIDField);
		
		studentProfileInfo = new JPanel();
		studentProfileInfo.setLayout(null);
		studentProfileInfo.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Student", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		studentProfileInfo.setBounds(10, 11, 210, 269);
		studentProfile.add(studentProfileInfo);
		
		studentProfileFirstLB = new JLabel("First :");
		studentProfileFirstLB.setBounds(16, 30, 32, 14);
		studentProfileInfo.add(studentProfileFirstLB);
		
		studentIDLB = new JLabel("ID:");
		studentIDLB.setBounds(16, 113, 38, 14);
		studentProfileInfo.add(studentIDLB);
		
		studentProfileIDField = new JTextField();
		studentProfileIDField.setEditable(false);
		studentProfileIDField.setColumns(10);
		studentProfileIDField.setBounds(64, 110, 127, 20);
		studentProfileInfo.add(studentProfileIDField);
		
		studentProfileSaveButton = new JButton("Save");
		studentProfileSaveButton.setBounds(133, 235, 71, 23);
		studentProfileInfo.add(studentProfileSaveButton);
		
		studentProfileMiddleLB = new JLabel("Middle :");
		studentProfileMiddleLB.setBounds(16, 59, 32, 14);
		studentProfileInfo.add(studentProfileMiddleLB);
		
		studentLastLB = new JLabel("Last :");
		studentLastLB.setBounds(16, 88, 32, 14);
		studentProfileInfo.add(studentLastLB);
		
		studentProfileAddRadioButton = new JRadioButton("Add");
		studentProfileAddRadioButton.setSelected(true);
		studentProfileAddRadioButton.setBounds(6, 233, 57, 23);
		studentProfileInfo.add(studentProfileAddRadioButton);
		
		studentProfileEditRadioButton = new JRadioButton("Edit");
		studentProfileEditRadioButton.setBounds(73, 233, 57, 23);
		studentProfileInfo.add(studentProfileEditRadioButton);
		
		//Group Button method
		stdRBG = new ButtonGroup();
		studentProfileAddRadioButton.setSelected(true);
		stdRBG.add(studentProfileAddRadioButton);
		stdRBG.add(studentProfileEditRadioButton);
		
		JLabel studentProfileTuitionLB = new JLabel("Tuition :");
		studentProfileTuitionLB.setBounds(16, 206, 48, 14);
		studentProfileInfo.add(studentProfileTuitionLB);
		
		studentProfileLastNameField = new JTextField();
		studentProfileLastNameField.setColumns(10);
		studentProfileLastNameField.setBounds(64, 85, 127, 20);
		studentProfileInfo.add(studentProfileLastNameField);
		
		studentProfileMiddleNameField = new JTextField();
		studentProfileMiddleNameField.setDocument(new JTextFieldLimit(1));
		studentProfileMiddleNameField.setColumns(10);
		studentProfileMiddleNameField.setBounds(64, 56, 127, 20);
		studentProfileInfo.add(studentProfileMiddleNameField);
		
		studentProfileFirstNameField = new JTextField();
		studentProfileFirstNameField.setColumns(10);
		studentProfileFirstNameField.setBounds(64, 27, 127, 20);
		studentProfileInfo.add(studentProfileFirstNameField);
		
		studentProfileTuitionComboBox = new JComboBox();
		studentProfileTuitionComboBox.setBounds(64, 202, 127, 22);
		studentProfileInfo.add(studentProfileTuitionComboBox);
		
		JLabel lblMajor = new JLabel("Major:");
		lblMajor.setBounds(16, 179, 48, 16);
		studentProfileInfo.add(lblMajor);
		
		studentProfileMajorComboBox = new JComboBox();

		studentProfileMajorComboBox.setBounds(64, 174, 127, 21);
		studentProfileInfo.add(studentProfileMajorComboBox);
		
		JLabel lblPw_1 = new JLabel("PW:");
		lblPw_1.setBounds(16, 142, 48, 14);
		studentProfileInfo.add(lblPw_1);
		
		studentProfilePWField = new JTextField();
		studentProfilePWField.setBounds(64, 141, 127, 20);
		studentProfileInfo.add(studentProfilePWField);
		studentProfilePWField.setColumns(10);
		
		studentProfileList = new JPanel();
		studentProfileList.setLayout(null);
		studentProfileList.setBorder(new TitledBorder(null, "Student List", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		studentProfileList.setBounds(225, 0, 519, 450);
		studentProfile.add(studentProfileList);
		
		scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(10, 23, 499, 416);
		studentProfileList.add(scrollPane_3);
		
		studentProfileTable = new JTable(){
		    public boolean isCellEditable(int row, int column) {
		        return false; 
		    }
		};
		scrollPane_3.setViewportView(studentProfileTable);
		
		studentGrade = new JPanel();
		studentTabbedPanel.addTab("Grades", null, studentGrade, null);
		studentGrade.setLayout(null);
		
		/****************Grade*****************/
		studentGradeInfo = new JPanel();
		studentGradeInfo.setLayout(null);
		studentGradeInfo.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Grade", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		studentGradeInfo.setBounds(10, 0, 210, 188);
		studentGrade.add(studentGradeInfo);
		
		lblStudentId = new JLabel("Student:");
		lblStudentId.setBounds(10, 54, 77, 14);
		studentGradeInfo.add(lblStudentId);
		
		lblGrade = new JLabel("Grade :");
		lblGrade.setBounds(10, 99, 38, 14);
		studentGradeInfo.add(lblGrade);
		
		studentGradeIDField = new JTextField();
		studentGradeIDField.setEditable(false);
		studentGradeIDField.setColumns(10);
		studentGradeIDField.setBounds(73, 51, 127, 20);
		studentGradeInfo.add(studentGradeIDField);
		
		studentGradeComboBox = new JComboBox();

		studentGradeComboBox.setBounds(73, 95, 127, 22);
		studentGradeInfo.add(studentGradeComboBox);
		
		saveStudentGradeButton = new JButton("Save");
		saveStudentGradeButton.setBounds(111, 142, 89, 23);
		studentGradeInfo.add(saveStudentGradeButton);;
		
		studentGradeList = new JPanel();
		studentGradeList.setLayout(null);
		studentGradeList.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), "SessionList", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		studentGradeList.setBounds(225, 0, 519, 450);
		studentGrade.add(studentGradeList);
		
		JScrollPane studentGradeScrollPanel = new JScrollPane();
		studentGradeScrollPanel.setBounds(10, 23, 499, 416);
		studentGradeList.add(studentGradeScrollPanel);
		
		studentGradeTable = new JTable();
		studentGradeScrollPanel.setViewportView(studentGradeTable);

	}
	
	/*########### Department Tab: ###########*/
	public void departmentTabComponent() {
		departmentTab = new JPanel();
		tabbedPane.addTab("Department", null, departmentTab, null);
		departmentTab.setLayout(null);
		
		/****************Department*****************/
		dpInfo = new JPanel();
		dpInfo.setLayout(null);
		dpInfo.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "College", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		dpInfo.setBounds(10, 40, 210, 178);
		departmentTab.add(dpInfo);
		
		dpNameLB = new JLabel("Name :");
		dpNameLB.setBounds(16, 30, 57, 14);
		dpInfo.add(dpNameLB);
		
		dpCharLB = new JLabel("Chair :");
		dpCharLB.setBounds(16, 68, 54, 14);
		dpInfo.add(dpCharLB);
		
		departmentNameField = new JTextField();
		departmentNameField.setDocument(new JTextFieldLimit(60));
		
		departmentNameField.setColumns(10);
		departmentNameField.setBounds(64, 27, 127, 20);
		dpInfo.add(departmentNameField);
		
		departmentSaveButton = new JButton("Set ");
		departmentSaveButton.setBounds(127, 138, 71, 23);
		dpInfo.add(departmentSaveButton);
		
		//Group Button method
		dpRBG = new ButtonGroup();
		
		JLabel dpCollegeLB = new JLabel("College : ");
		dpCollegeLB.setBounds(16, 106, 63, 14);
		dpInfo.add(dpCollegeLB);
		
		departmentCollegeComboBox = new JComboBox();
		departmentCollegeComboBox.setBounds(77, 102, 114, 22);
		dpInfo.add(departmentCollegeComboBox);
		
		departmentChairComboBox = new JComboBox();
		departmentChairComboBox.setBounds(77, 64, 114, 22);
		dpInfo.add(departmentChairComboBox);
		
		departmentAddRadioButton = new JRadioButton("Add");
		departmentAddRadioButton.setSelected(true);
		buttonGroup_2.add(departmentAddRadioButton);
		departmentAddRadioButton.setBounds(10, 137, 63, 23);
		dpInfo.add(departmentAddRadioButton);
		
		departmentEditRadioButton = new JRadioButton("Edit");
		buttonGroup_2.add(departmentEditRadioButton);
		departmentEditRadioButton.setBounds(65, 137, 66, 23);
		dpInfo.add(departmentEditRadioButton);
		
		/****************Remove*****************/
		dpRemove = new JPanel();
		dpRemove.setLayout(null);
		dpRemove.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Remove", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		dpRemove.setBounds(10, 292, 210, 138);
		departmentTab.add(dpRemove);
		
		departmentRemoveButton = new JButton("Remove");
		departmentRemoveButton.setBounds(115, 95, 71, 23);
		dpRemove.add(departmentRemoveButton);
		
		dpRMLB = new JLabel("Department :");
		dpRMLB.setBounds(24, 39, 127, 14);
		dpRemove.add(dpRMLB);
		
		departmentRemoveDepartmentField = new JTextField();
		departmentRemoveDepartmentField.setEditable(false);
		departmentRemoveDepartmentField.setColumns(10);
		departmentRemoveDepartmentField.setBounds(68, 64, 118, 20);
		dpRemove.add(departmentRemoveDepartmentField);
		
		/****************Department List*****************/
		dpList = new JPanel();
		dpList.setLayout(null);
		dpList.setBorder(new TitledBorder(null, "Department List", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		dpList.setBounds(230, 11, 519, 477);
		departmentTab.add(dpList);
		
		JScrollPane departmentScrollPanel = new JScrollPane();
		departmentScrollPanel.setBounds(10, 23, 499, 443);
		dpList.add(departmentScrollPanel);
		
		departmentTable = new JTable(){
		    public boolean isCellEditable(int row, int column) {
		        return false; 
		    }
		};
		departmentScrollPanel.setViewportView(departmentTable);;
	}
	
	/*########### Major Tab: ###########*/
	public void majorTabComponent() {
		majorTab = new JPanel();
		tabbedPane.addTab("Major", null, majorTab, null);
		majorTab.setLayout(null);
		
		/****************Major*****************/
		majorInfo = new JPanel();
		majorInfo.setLayout(null);
		majorInfo.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Major", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		majorInfo.setBounds(10, 40, 210, 207);
		majorTab.add(majorInfo);
		
		JLabel majorNameLB = new JLabel("Name :");
		majorNameLB.setBounds(16, 30, 76, 14);
		majorInfo.add(majorNameLB);
		
		JLabel majorDpLB = new JLabel("Department :");
		majorDpLB.setBounds(16, 88, 127, 14);
		majorInfo.add(majorDpLB);
		
		majorNameField = new JTextField();
		majorNameField.setDocument(new JTextFieldLimit(60));
		majorNameField.setColumns(10);
		majorNameField.setBounds(64, 54, 127, 20);
		majorInfo.add(majorNameField);
		
		majorSaveButton = new JButton("Add");
		majorSaveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		majorSaveButton.setBounds(126, 152, 71, 23);
		majorInfo.add(majorSaveButton);
		
		//Group Button method
		majorRBG = new ButtonGroup();
		
		majorDpCB = new JComboBox();
		majorDpCB.setBounds(64, 113, 127, 22);
		majorInfo.add(majorDpCB);
		
		/****************Remove*****************/
		majorRemove = new JPanel();
		majorRemove.setLayout(null);
		majorRemove.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Remove", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		majorRemove.setBounds(10, 313, 210, 138);
		majorTab.add(majorRemove);
		
		majorRemoveButton = new JButton("Remove");
		majorRemoveButton.setBounds(115, 95, 71, 23);
		majorRemove.add(majorRemoveButton);
		
		majorRmDpLb = new JLabel("Major:");
		majorRmDpLb.setBounds(24, 39, 93, 14);
		majorRemove.add(majorRmDpLb);
		
		majorRemoveField = new JTextField();
		majorRemoveField.setEditable(false);
		majorRemoveField.setColumns(10);
		majorRemoveField.setBounds(68, 64, 118, 20);
		majorRemove.add(majorRemoveField);
		
		/****************Major List*****************/
		majorList = new JPanel();
		majorList.setLayout(null);
		majorList.setBorder(new TitledBorder(null, "Major List", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		majorList.setBounds(230, 11, 519, 477);
		majorTab.add(majorList);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(14, 33, 491, 408);
		majorList.add(scrollPane_1);
		
		majorTable = new JTable(){
			public boolean isCellEditable(int row, int column) {
				return false; 
			}
		};
		scrollPane_1.setViewportView(majorTable);;
	}
	
	/*########### Course Tab: ###########*/
	public void courseTabComponent() {
		courseContentPane = new JPanel();
		
		tabbedPane.addTab("Course", null, courseContentPane, null);
		courseContentPane.setLayout(null);
		
		courseTabbedPane = new JTabbedPane(JTabbedPane.TOP);
		courseTabbedPane.setBounds(10, 11, 749, 478);
		courseContentPane.add(courseTabbedPane);
		
	/****************Course Tab*****************/
		coursePanel = new JPanel();
		courseTabbedPane.addTab("Course", null, coursePanel, null);
		coursePanel.setLayout(null);
		
		/****************Course Info*****************/
		courseInfo = new JPanel();
		courseInfo.setLayout(null);
		courseInfo.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Course", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		courseInfo.setBounds(10, 31, 210, 182);
		coursePanel.add(courseInfo);
		
		courseNameLB = new JLabel("Name :");
		courseNameLB.setBounds(16, 39, 38, 14);
		courseInfo.add(courseNameLB);
		
		courseNameField = new JTextField();
		courseNameField.setDocument(new JTextFieldLimit(60));
		courseNameField.setColumns(10);
		courseNameField.setBounds(64, 36, 127, 20);
		courseInfo.add(courseNameField);
		
		courseSaveButton = new JButton("Add");
		courseSaveButton.setBounds(120, 128, 71, 23);
		courseInfo.add(courseSaveButton);

		//Group Button method
		courseRBG = new ButtonGroup();
		
		courseMjLB = new JLabel("Major : ");
		courseMjLB.setBounds(16, 87, 51, 14);
		courseInfo.add(courseMjLB);
		
		courseMajorComboBox = new JComboBox();
		courseMajorComboBox.setBounds(64, 84, 127, 22);
		courseInfo.add(courseMajorComboBox);
		
		/****************Remove*****************/
		courseRemove = new JPanel();
		courseRemove.setLayout(null);
		courseRemove.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Remove", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		courseRemove.setBounds(10, 260, 210, 138);
		coursePanel.add(courseRemove);
		
		courseRemoveButton = new JButton("Remove");
		courseRemoveButton.setBounds(115, 95, 89, 23);
		courseRemove.add(courseRemoveButton);
		
		courseRmLB = new JLabel("Course :");
		courseRmLB.setBounds(24, 39, 79, 14);
		courseRemove.add(courseRmLB);
		
		courseRemoveCourseField = new JTextField();
		courseRemoveCourseField.setEditable(false);
		courseRemoveCourseField.setColumns(10);
		courseRemoveCourseField.setBounds(68, 64, 118, 20);
		courseRemove.add(courseRemoveCourseField);
		
		/****************Course List*****************/
		courseList = new JPanel();
		courseList.setLayout(null);
		courseList.setBorder(new TitledBorder(null, "Course List", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		courseList.setBounds(225, 0, 519, 450);
		coursePanel.add(courseList);
		
		courseScrollPanel = new JScrollPane();
		courseScrollPanel.setBounds(13, 24, 475, 397);
		courseList.add(courseScrollPanel);
		
		courseTable = new JTable(){
		    public boolean isCellEditable(int row, int column) {
		        return false; 
		    }
		};
		courseScrollPanel.setViewportView(courseTable);
		
	/****************Pre-req Tab*****************/
		preqPanel = new JPanel();
		courseTabbedPane.addTab("Pre-req", null, preqPanel, null);
		preqPanel.setLayout(null);
		
		/****************Pre-req Info*****************/
		prereqInfo = new JPanel();
		prereqInfo.setLayout(null);
		prereqInfo.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Info", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		prereqInfo.setBounds(10, 31, 210, 94);
		preqPanel.add(prereqInfo);
		
		prereqSCLB = new JLabel("Selected Course :");
		prereqSCLB.setBounds(16, 30, 129, 14);
		prereqInfo.add(prereqSCLB);
		
		prereqSelectCourseField = new JTextField();
		prereqSelectCourseField.setEditable(false);
		prereqSelectCourseField.setColumns(10);
		prereqSelectCourseField.setBounds(64, 55, 127, 20);
		prereqInfo.add(prereqSelectCourseField);
		
		/****************Pre-req Add*****************/
		prereqAdd = new JPanel();
		prereqAdd.setLayout(null);
		prereqAdd.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Add", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		prereqAdd.setBounds(9, 150, 210, 120);
		preqPanel.add(prereqAdd);
		
		prereqAddCLB = new JLabel("Course :");
		prereqAddCLB.setBounds(15, 32, 66, 14);
		prereqAdd.add(prereqAddCLB);
		
		prereqAddButton = new JButton("Add");
		prereqAddButton.setBounds(68, 80, 117, 29);
		prereqAdd.add(prereqAddButton);
		
		prereqdCourseCombox = new JComboBox();
		prereqdCourseCombox.setBounds(71, 46, 112, 27);
		prereqAdd.add(prereqdCourseCombox);
		
		/****************Pre-req Remove*****************/
		prereqRemove = new JPanel();
		prereqRemove.setLayout(null);
		prereqRemove.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Remove", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		prereqRemove.setBounds(8, 290, 210, 120);
		preqPanel.add(prereqRemove);
		
		prereqRmLB = new JLabel("Course :");
		prereqRmLB.setBounds(16, 51, 44, 14);
		prereqRemove.add(prereqRmLB);
		
		prereqRemoveCourseField = new JTextField();
		prereqRemoveCourseField.setEditable(false);
		prereqRemoveCourseField.setColumns(10);
		prereqRemoveCourseField.setBounds(68, 48, 118, 20);
		prereqRemove.add(prereqRemoveCourseField);
		
		prereqRemoveButton = new JButton("Remove");
		prereqRemoveButton.setBounds(68, 80, 117, 29);
		prereqRemove.add(prereqRemoveButton);
		
		/****************Pre-req Course List*****************/
		prereqList = new JPanel();
		prereqList.setLayout(null);
		prereqList.setBorder(new TitledBorder(null, "P.Course List", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		prereqList.setBounds(225, 0, 519, 450);
		preqPanel.add(prereqList);
		
		prereqScrollPanel = new JScrollPane();
		prereqScrollPanel.setBounds(16, 26, 470, 392);
		prereqList.add(prereqScrollPanel);
		
		prereqTable = new JTable(){
		    public boolean isCellEditable(int row, int column) {
		        return false; 
		    }
		};
		prereqScrollPanel.setViewportView(prereqTable);;
	}
	
	/*########### Session Tab: ###########*/
	public void sessionTabComponent() {
		sessionTab = new JPanel();
		tabbedPane.addTab("Session", null, sessionTab, null);
		sessionTab.setLayout(null);
		
		/****************Session*****************/
		
		//Group Button method
		sessionRBG = new ButtonGroup();
		
		
		
		
		/****************Remove*****************/
		
		/****************List*****************/
		
		JTabbedPane sessionTabbedPanel = new JTabbedPane(JTabbedPane.TOP);
		sessionTabbedPanel.setBounds(10, 11, 811, 478);
		sessionTab.add(sessionTabbedPanel);
		sessionProfile = new JPanel();
		sessionTabbedPanel.addTab("Session", null, sessionProfile, null);
		sessionProfile.setLayout(null);
		sessionProfile.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		sessionRemove = new JPanel();
		sessionRemove.setBounds(16, 345, 215, 68);
		sessionProfile.add(sessionRemove);
		sessionRemove.setLayout(null);
		sessionRemove.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Remove", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
		sessionRemoveButton = new JButton("Remove");
		sessionRemoveButton.setBounds(114, 40, 89, 23);
		sessionRemove.add(sessionRemoveButton);
		
		label_2 = new JLabel("Course :");
		label_2.setBounds(25, 22, 79, 14);
		sessionRemove.add(label_2);
		
		sessionRemoveField = new JTextField();
		sessionRemoveField.setEditable(false);
		sessionRemoveField.setColumns(10);
		sessionRemoveField.setBounds(91, 17, 118, 20);
		sessionRemove.add(sessionRemoveField);
		sessionList = new JPanel();
		sessionList.setBounds(253, 13, 541, 422);
		sessionProfile.add(sessionList);
		sessionList.setLayout(null);
		sessionList.setBorder(new TitledBorder(null, "Session List", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JScrollPane sessionScrollPanel = new JScrollPane();
		sessionScrollPanel.setBounds(11, 22, 535, 391);
		sessionList.add(sessionScrollPanel);
		
		sessionTable = new JTable(){
		    public boolean isCellEditable(int row, int column) {
		        return false; 
		    }
		};
		sessionScrollPanel.setViewportView(sessionTable);
		
		panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(null, "Session", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_2.setBounds(16, 13, 215, 331);
		sessionProfile.add(panel_2);
		panel_2.setLayout(null);
		
		lblCourse = new JLabel("Course :");
		lblCourse.setBounds(18, 59, 83, 14);
		panel_2.add(lblCourse);
		
		sessionStartTimeField = new JLabel("Start time :");
		sessionStartTimeField.setBounds(18, 90, 84, 14);
		panel_2.add(sessionStartTimeField);
		
		JLabel lblNewLabel_2 = new JLabel("End time :");
		lblNewLabel_2.setBounds(18, 125, 83, 14);
		panel_2.add(lblNewLabel_2);
		
		sessionYearField = new JTextField();
		sessionYearField.setBounds(91, 153, 112, 20);
		panel_2.add(sessionYearField);
		sessionYearField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Year :");
		lblNewLabel_3.setBounds(18, 156, 48, 14);
		panel_2.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Semester :");
		lblNewLabel_4.setBounds(18, 187, 71, 14);
		panel_2.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Day :");
		lblNewLabel_5.setBounds(18, 218, 48, 14);
		panel_2.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Location :");
		lblNewLabel_6.setBounds(18, 249, 71, 14);
		panel_2.add(lblNewLabel_6);
		
		sessionComboBox = new JComboBox();
		sessionComboBox.setBounds(92, 56, 111, 22);
		panel_2.add(sessionComboBox);
		
		sessionSemesterComboBox = new JComboBox();
		sessionSemesterComboBox.setBounds(91, 182, 112, 22);
		panel_2.add(sessionSemesterComboBox);
		
		sessionDayComboBox = new JComboBox();
		sessionDayComboBox.setBounds(91, 212, 112, 22);
		panel_2.add(sessionDayComboBox);
		
		sessionLocationComboBox = new JComboBox();
		sessionLocationComboBox.setBounds(92, 245, 111, 22);
		panel_2.add(sessionLocationComboBox);
		
		///
		Date date = new Date();
		SpinnerDateModel sm = new SpinnerDateModel(date, null, null, Calendar.HOUR_OF_DAY);
		
		startTimeSpinner = new JSpinner(sm);
		startTimeSpinner.setBounds(99, 84, 94, 26);
		panel_2.add(startTimeSpinner);
		JSpinner.DateEditor de_startTimeSpinner = new JSpinner.DateEditor(startTimeSpinner, "HH:mm");
		startTimeSpinner.setEditor(de_startTimeSpinner);
		
		SpinnerDateModel sm2 = new SpinnerDateModel(date, null, null, Calendar.HOUR_OF_DAY);
		endTimeSpinner = new JSpinner(sm2);
		endTimeSpinner.setBounds(99, 119, 94, 26);
		panel_2.add(endTimeSpinner);
		JSpinner.DateEditor de_endTimeSpinner = new JSpinner.DateEditor(endTimeSpinner, "HH:mm");
		endTimeSpinner.setEditor(de_endTimeSpinner);
		///
		sessionSaveButton = new JButton("Create");
		sessionSaveButton.setBounds(132, 301, 71, 23);
		panel_2.add(sessionSaveButton);
		
		JPanel sessionStudentPanel = new JPanel();
		sessionTabbedPanel.addTab("Roster", null, sessionStudentPanel, null);
		sessionStudentPanel.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), "Student List", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel.setBounds(11, 10, 762, 409);
		sessionStudentPanel.add(panel);
		panel.setLayout(null);
		
		scrollPane_6 = new JScrollPane();
		scrollPane_6.setBounds(26, 26, 708, 364);
		panel.add(scrollPane_6);
		
		rosterTable = new JTable();
		scrollPane_6.setViewportView(rosterTable);
	}
	
	/*########### Room Tab: ###########*/
	public void roomTabComponent() {
		roomTab = new JPanel();
		tabbedPane.addTab("Room", null, roomTab, null);
		roomTab.setLayout(null);
		
		/****************Room*****************/
		roomInfo = new JPanel();
		roomInfo.setLayout(null);
		roomInfo.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Room", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		roomInfo.setBounds(10, 40, 210, 185);
		roomTab.add(roomInfo);
		
		lblLimit = new JLabel("Limit :");
		lblLimit.setBounds(16, 69, 38, 14);
		roomInfo.add(lblLimit);
		
		lblId_1 = new JLabel("Room#:");
		lblId_1.setBounds(16, 39, 46, 14);
		roomInfo.add(lblId_1);
		
		roomLimitField = new JTextField();
		roomLimitField.setColumns(10);
		roomLimitField.setBounds(83, 66, 108, 20);
		roomInfo.add(roomLimitField);
		
		roomNumberField = new JTextField();
		roomNumberField.setColumns(10);
		roomNumberField.setBounds(83, 36, 108, 20);
		roomInfo.add(roomNumberField);
		
		roomSaveButton = new JButton("Add");
		roomSaveButton.setBounds(133, 143, 71, 23);
		roomInfo.add(roomSaveButton);
		
		//Group Button method
		roomRBG = new ButtonGroup();
		
		lblBuidling = new JLabel("Buidling :");
		lblBuidling.setBounds(16, 99, 61, 16);
		roomInfo.add(lblBuidling);
		
		roomBuildingComboBox = new JComboBox();
		roomBuildingComboBox.setBounds(81, 92, 104, 27);
		roomInfo.add(roomBuildingComboBox);
		
		/****************Remove*****************/
		roomRemove = new JPanel();
		roomRemove.setLayout(null);
		roomRemove.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Remove", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		roomRemove.setBounds(10, 292, 210, 138);
		roomTab.add(roomRemove);
		
		roomRemoveButton = new JButton("Remove");
		roomRemoveButton.setBounds(115, 95, 71, 23);
		roomRemove.add(roomRemoveButton);
		
		label = new JLabel("Course :");
		label.setBounds(24, 39, 79, 14);
		roomRemove.add(label);
		
		roomRemoveField = new JTextField();
		roomRemoveField.setEditable(false);
		roomRemoveField.setColumns(10);
		roomRemoveField.setBounds(68, 64, 118, 20);
		roomRemove.add(roomRemoveField);
		
		/****************Room List*****************/
		roomList = new JPanel();
		roomList.setLayout(null);
		roomList.setBorder(new TitledBorder(null, "Room List", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		roomList.setBounds(230, 11, 519, 477);
		roomTab.add(roomList);
		
		scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(13, 21, 494, 433);
		roomList.add(scrollPane_5);
		
		roomTable = new JTable(){
		    public boolean isCellEditable(int row, int column) {
		        return false; 
		    }
		};
		scrollPane_5.setViewportView(roomTable);
	}
	
	/*########### Building Tab: ###########*/
	public void buildingTabComponent() {		
		buildingTab = new JPanel();
		tabbedPane.addTab("Building", null, buildingTab, null);
		buildingTab.setLayout(null);
		
		/****************Buidling*****************/
		buildingInfo = new JPanel();
		buildingInfo.setLayout(null);
		buildingInfo.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Buidling", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		buildingInfo.setBounds(10, 40, 228, 145);
		buildingTab.add(buildingInfo);
		
		label_3 = new JLabel("Name :");
		label_3.setBounds(16, 30, 38, 14);
		buildingInfo.add(label_3);
		
		lblOccu = new JLabel("Occupation :");
		lblOccu.setBounds(16, 68, 71, 14);
		buildingInfo.add(lblOccu);
		
		buidlingNameField = new JTextField();
		buidlingNameField.setColumns(10);
		buidlingNameField.setBounds(85, 27, 127, 20);
		buildingInfo.add(buidlingNameField);
		
		buildingOccupationField = new JTextField();
	
		buildingOccupationField.setColumns(10);
		buildingOccupationField.setBounds(85, 65, 127, 20);
		buildingInfo.add(buildingOccupationField);
		
		buildingSaveButton = new JButton("Add");
		buildingSaveButton.setBounds(127, 104, 71, 23);
		buildingInfo.add(buildingSaveButton);
		
		//Group Button method
		buidlingRBG = new ButtonGroup();
		
		/****************Remove*****************/
		buidlingRemove = new JPanel();
		buidlingRemove.setLayout(null);
		buidlingRemove.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Remove", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		buidlingRemove.setBounds(10, 280, 228, 138);
		buildingTab.add(buidlingRemove);
		
		buildingRemoveButton = new JButton("Remove");
		buildingRemoveButton.setBounds(139, 83, 71, 23);
		buidlingRemove.add(buildingRemoveButton);
		
		lblBuilding = new JLabel("Building:");
		lblBuilding.setBounds(17, 39, 79, 14);
		buidlingRemove.add(lblBuilding);
		
		buidlingRemoveField = new JTextField();
		buidlingRemoveField.setColumns(10);
		buidlingRemoveField.setBounds(92, 36, 118, 20);
		buidlingRemove.add(buidlingRemoveField);
		
		/****************List*****************/
		buidlingList = new JPanel();
		buidlingList.setLayout(null);
		buidlingList.setBorder(new TitledBorder(null, "Buidling List", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		buidlingList.setBounds(241, 11, 519, 477);
		buildingTab.add(buidlingList);
		
		scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(14, 24, 493, 426);
		buidlingList.add(scrollPane_4);
		
		buildingTable = new JTable(){
		    public boolean isCellEditable(int row, int column) {
		        return false; 
		    }
		};
		scrollPane_4.setViewportView(buildingTable);
	}
}
