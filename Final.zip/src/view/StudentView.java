package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JTabbedPane;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import controller.LoginController;
import controller.student.StudentAddClassController;
import controller.student.StudentDropClassController;
import controller.student.StudentTermController;
import controller.student.StudentViewController;
import datatypes.User;

import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.TreeMap;

public class StudentView extends JFrame {

	private JPanel 		contentPane;
	private JTabbedPane tabbedPane;		
	private GroupLayout gl_contentPane;	
	private JButton 	btnLogout;
	
	/*########### Student Tab: ###########*/
	public JTextField 	fullnameField;		// <Fields>
	public JTextField 	idField;			//
	public JTextField 	tuitionField;		//
	public JTextField 	dropField;			//
	public JButton 	btnDrop;			//
	public JTable 		stdScheduleTable; 	// <Tables>:
	public JScrollPane studentWeeklyScrollPanel;
	public String[] 	stdScheduleTableHeader;//
	public JComboBox 	stdTermDropdown;	// <Dropdown>:	
	public TreeMap<String, Object[][]> 	stdScheduleByTerm;	// Table Data
	
	/*########### Schedule Tab: ###########*/
	public JButton studentScheduleAddButton;
	public JPanel studentScheduleInfo;
	public JTable 		schlScheduleTable;	// <Tables>:
	public JScrollPane studentScheduleScrollPanel;
	public String[]		schlScheduleTableHeader;
	public TreeMap<String, Object[][]> 	schlScheduleByTerm;	// Table Data
	public JTextField studentScheduleCRNField;
	public JTextField majorField;
	public JTextField unitField;
	

	public StudentView() {
		initData();
		initComponents();
		createEvents();
		this.setVisible(true);
	}
	public void initData() {
		stdScheduleByTerm 	= new TreeMap<String, Object[][]>();	// Table Data
	}
	
	// Student Controllers:
	public void addAddClassController(StudentAddClassController addClassController) 	{studentScheduleAddButton .addActionListener(addClassController);}
	public void addDropClassController(StudentDropClassController dropClassController) 	{btnDrop.addActionListener(dropClassController);}
	public void addStudentTermController(StudentTermController studentTermController) 	{stdTermDropdown.addActionListener(studentTermController);}
	// Schedule Controllers:
	//public void addSchoolTermController(SchoolTermController schoolTermController) 		{schlTermDropdown.addActionListener(schoolTermController);}
	
	
	public void createEvents() {
	// Logout
		JFrame _this = this;
		btnLogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				_this.dispose();
				LoginController login = new LoginController();
				login.init();
			}
		});	
	// StudentTab:
		// print current CourseID to the field
		stdScheduleTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TableModel tModel = stdScheduleTable.getModel();
				int i = stdScheduleTable.getSelectedRow();
				dropField.setText( tModel.getValueAt(i, 0).toString());

			}
		});
	// ScheduleTab:
		schlScheduleTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TableModel tModel = schlScheduleTable.getModel();
				int i = schlScheduleTable.getSelectedRow();
				studentScheduleCRNField.setText( tModel.getValueAt(i, 0).toString());
			}
		});
	}

	public void initComponents(){
		//-Jframe Windows:
		jframeComponent();
		
		//-Menu Component:
		menuComponent();
		
		//-Tab Component:
		tabComponent();
		
		//+StudentTabPanel Component:
		studentTabComponent();
		
		//+ScheduleTabPanel Component:
		scheduleTabComponent();
	}
	
	public void menuComponent() {
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mnFile.add(mntmExit);
		
		JMenu mnAbout = new JMenu("About");
		menuBar.add(mnAbout);
		
		JMenuItem mntmInfo = new JMenuItem("Info");
		mnAbout.add(mntmInfo);
		
		JPanel panel = new JPanel();
		menuBar.add(panel);
		panel.setLayout(new BorderLayout(0, 0));
		
		btnLogout = new JButton("Logout");
		
		panel.add(btnLogout, BorderLayout.EAST);
		
		// Menu bar handler
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int opt = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?");
				if(opt == JOptionPane.YES_OPTION) {
					System.exit(0);
				}
			}
		});
	}
	
	public void jframeComponent() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
	}

	public void tabComponent() {
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(tabbedPane, GroupLayout.PREFERRED_SIZE, 775, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(tabbedPane, GroupLayout.PREFERRED_SIZE, 527, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}
	
	public void studentTabComponent() {
		JPanel studentTab = new JPanel();
		tabbedPane.addTab("Student", null, studentTab, null);
	
		JPanel schedulePanel = new JPanel();
		schedulePanel.setBorder(new TitledBorder(null, "Weekly Schedule", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel dropClassPanel = new JPanel();
		dropClassPanel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Drop Class", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
		JPanel studentInfoPanel = new JPanel();
		studentInfoPanel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Student Info", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		GroupLayout gl_studentTab = new GroupLayout(studentTab);
		gl_studentTab.setHorizontalGroup(
			gl_studentTab.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_studentTab.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_studentTab.createParallelGroup(Alignment.LEADING)
						.addComponent(dropClassPanel, GroupLayout.PREFERRED_SIZE, 210, GroupLayout.PREFERRED_SIZE)
						.addComponent(studentInfoPanel, GroupLayout.PREFERRED_SIZE, 210, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(schedulePanel, GroupLayout.PREFERRED_SIZE, 530, GroupLayout.PREFERRED_SIZE)
					.addContainerGap())
		);
		gl_studentTab.setVerticalGroup(
			gl_studentTab.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_studentTab.createSequentialGroup()
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGroup(gl_studentTab.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_studentTab.createSequentialGroup()
							.addComponent(studentInfoPanel, GroupLayout.PREFERRED_SIZE, 209, GroupLayout.PREFERRED_SIZE)
							.addGap(82)
							.addComponent(dropClassPanel, GroupLayout.PREFERRED_SIZE, 122, GroupLayout.PREFERRED_SIZE))
						.addComponent(schedulePanel, GroupLayout.PREFERRED_SIZE, 478, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		
		JLabel lblTerms = new JLabel("Term: ");
		lblTerms.setBounds(16, 30, 53, 14);
		
		// ######################### ComboBox ######################### 
		stdTermDropdown = new JComboBox();
		
		stdTermDropdown.setBounds(81, 27, 92, 20);
		//stdTermDropdown.setModel(new DefaultComboBoxModel(new String[] {"Fall 2019", "Spring 2020"}));	// static

		schedulePanel.setLayout(null);
		
		studentWeeklyScrollPanel = new JScrollPane();
	
		studentWeeklyScrollPanel.setBounds(12, 57, 498, 396);
		schedulePanel.add(studentWeeklyScrollPanel);
		
		
		// ######################### JTable #########################		
		//Init table
		stdScheduleTable = new JTable( new DefaultTableModel() ){
			public boolean isCellEditable(int row, int column) {
				return false; 
			}
		};

		studentWeeklyScrollPanel.setViewportView(stdScheduleTable);
		
		// ######################### Drop Panel #########################
		schedulePanel.add(lblTerms);
		schedulePanel.add(stdTermDropdown);
		JLabel label = new JLabel("CRN:");
		
		dropField = new JTextField();
		dropField.setColumns(10);
		dropField.setEditable(false);
		
		// Drop Item in Table########################:
		btnDrop = new JButton("Drop");
		
		GroupLayout gl_dropClassPanel = new GroupLayout(dropClassPanel);
		gl_dropClassPanel.setHorizontalGroup(
			gl_dropClassPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_dropClassPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_dropClassPanel.createParallelGroup(Alignment.TRAILING)
						.addComponent(btnDrop)
						.addGroup(gl_dropClassPanel.createSequentialGroup()
							.addComponent(label, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
							.addComponent(dropField, GroupLayout.PREFERRED_SIZE, 119, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(18, Short.MAX_VALUE))
		);
		gl_dropClassPanel.setVerticalGroup(
			gl_dropClassPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_dropClassPanel.createSequentialGroup()
					.addGap(28)
					.addGroup(gl_dropClassPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(dropField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnDrop)
					.addContainerGap(18, Short.MAX_VALUE))
		);
		dropClassPanel.setLayout(gl_dropClassPanel);
		
		JLabel lblName = new JLabel("Name:");
		
		JLabel lblId = new JLabel("ID:");
		
		JLabel lblTuition = new JLabel("Tuition:  ");
		
		fullnameField = new JTextField();
		fullnameField.setColumns(10);
		fullnameField.setEditable(false);
		
		idField = new JTextField();
		idField.setColumns(10);
		idField.setEditable(false);

		
		tuitionField = new JTextField();
		tuitionField.setColumns(10);
		tuitionField.setEditable(false);
		
		majorField = new JTextField();
		majorField.setEditable(false);
		majorField.setColumns(10);
		
		JLabel lblMajor = new JLabel("Major:");
		
		JLabel lblUnit = new JLabel(" Unit:");
		
		unitField = new JTextField();
		unitField.setColumns(10);
		unitField.setEditable(false);


		GroupLayout gl_studentInfoPanel = new GroupLayout(studentInfoPanel);
		gl_studentInfoPanel.setHorizontalGroup(
			gl_studentInfoPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_studentInfoPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_studentInfoPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_studentInfoPanel.createSequentialGroup()
							.addGroup(gl_studentInfoPanel.createParallelGroup(Alignment.LEADING)
								.addComponent(lblName)
								.addComponent(lblId)
								.addComponent(lblTuition)
								.addComponent(lblMajor))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_studentInfoPanel.createParallelGroup(Alignment.LEADING)
								.addComponent(tuitionField, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)
								.addComponent(fullnameField, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)
								.addComponent(idField, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)
								.addGroup(gl_studentInfoPanel.createSequentialGroup()
									.addGap(6)
									.addGroup(gl_studentInfoPanel.createParallelGroup(Alignment.LEADING)
										.addGroup(Alignment.TRAILING, gl_studentInfoPanel.createSequentialGroup()
											.addComponent(unitField, GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
											.addPreferredGap(ComponentPlacement.RELATED))
										.addComponent(majorField, GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE))))
							.addGap(2))
						.addComponent(lblUnit)))
		);
		gl_studentInfoPanel.setVerticalGroup(
			gl_studentInfoPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_studentInfoPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_studentInfoPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblName)
						.addComponent(fullnameField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_studentInfoPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(idField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblId))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_studentInfoPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(majorField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblMajor))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_studentInfoPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblUnit)
						.addComponent(unitField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
					.addGroup(gl_studentInfoPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(tuitionField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblTuition))
					.addContainerGap())
		);
		studentInfoPanel.setLayout(gl_studentInfoPanel);
		studentTab.setLayout(gl_studentTab);
	}
	
	public void scheduleTabComponent() {
		JPanel scheduleTab = new JPanel();
		tabbedPane.addTab("Schedule", null, scheduleTab, null);
		
		JPanel schlScheldulePanel = new JPanel();
		
		studentScheduleInfo = new JPanel();
		studentScheduleInfo.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Add Class", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
		studentScheduleAddButton = new JButton("Add");
		
		JLabel label = new JLabel("CRN:");
		
		studentScheduleCRNField = new JTextField();
		studentScheduleCRNField.setEditable(false);
		studentScheduleCRNField.setColumns(10);
		GroupLayout gl_studentScheduleInfo = new GroupLayout(studentScheduleInfo);
		gl_studentScheduleInfo.setHorizontalGroup(
			gl_studentScheduleInfo.createParallelGroup(Alignment.TRAILING)
				.addGap(0, 210, Short.MAX_VALUE)
				.addGroup(gl_studentScheduleInfo.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_studentScheduleInfo.createParallelGroup(Alignment.LEADING)
						.addComponent(studentScheduleAddButton)
						.addGroup(gl_studentScheduleInfo.createSequentialGroup()
							.addComponent(label)
							.addPreferredGap(ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
							.addComponent(studentScheduleCRNField, GroupLayout.PREFERRED_SIZE, 118, GroupLayout.PREFERRED_SIZE)))
					.addGap(18))
		);
		gl_studentScheduleInfo.setVerticalGroup(
			gl_studentScheduleInfo.createParallelGroup(Alignment.LEADING)
				.addGap(0, 120, Short.MAX_VALUE)
				.addGroup(gl_studentScheduleInfo.createSequentialGroup()
					.addGap(32)
					.addGroup(gl_studentScheduleInfo.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(studentScheduleCRNField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(studentScheduleAddButton)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		studentScheduleInfo.setLayout(gl_studentScheduleInfo);
		GroupLayout gl_scheduleTab = new GroupLayout(scheduleTab);
		gl_scheduleTab.setHorizontalGroup(
			gl_scheduleTab.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_scheduleTab.createSequentialGroup()
					.addContainerGap()
					.addComponent(studentScheduleInfo, GroupLayout.PREFERRED_SIZE, 210, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(schlScheldulePanel, GroupLayout.PREFERRED_SIZE, 528, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_scheduleTab.setVerticalGroup(
			gl_scheduleTab.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_scheduleTab.createSequentialGroup()
					.addContainerGap(8, Short.MAX_VALUE)
					.addGroup(gl_scheduleTab.createParallelGroup(Alignment.LEADING)
						.addComponent(studentScheduleInfo, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_scheduleTab.createSequentialGroup()
							.addGap(34)
							.addComponent(schlScheldulePanel, GroupLayout.PREFERRED_SIZE, 433, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		schlScheldulePanel.setLayout(null);
		
		studentScheduleScrollPanel = new JScrollPane();
		studentScheduleScrollPanel.setBounds(12, 11, 504, 411);
		schlScheldulePanel.add(studentScheduleScrollPanel);
		
		
		// ######################### JTable #########################		
		//Init table
		schlScheduleTable 			= new JTable(){
			public boolean isCellEditable(int row, int column) {
				return false; 
			}
		};
		
		
		
		studentScheduleScrollPanel.setViewportView(schlScheduleTable);
		scheduleTab.setLayout(gl_scheduleTab);
	}
}
