package driver;
// add roomsTable
import database.*;
import datatypes.*;
import java.time.LocalTime;
import java.util.ArrayList;

public class Preload
{
	public Preload() {}
	public void load()
	{
// University
		UniversityInformationTable.getInstance().getData().setName("CSULB");
// Building
		String buildingName = "VEC";
		BuildingsTable.getInstance().getData().put(buildingName, new Building(buildingName, 50));
// Building
		buildingName = "ECS";
		BuildingsTable.getInstance().getData().put(buildingName, new Building(buildingName, 45));
// Room, rID: 0
		int rID = RoomsTable.getInstance().getID();
		Room room = new Room(100, 35, "VEC");
		room.setRoomID(rID);
		RoomsTable.getInstance().getData().put(rID, room);
// Room, rID: 1
		rID = RoomsTable.getInstance().getID();
		room = new Room(101, 45, "VEC");
		room.setRoomID(rID);
		RoomsTable.getInstance().getData().put(rID, room);
// Room, rID: 2
		rID = RoomsTable.getInstance().getID();
		room = new Room(102, 55, "VEC");
		room.setRoomID(rID);
		RoomsTable.getInstance().getData().put(rID, room);
// Room, rID: 3
		rID = RoomsTable.getInstance().getID();
		room = new Room(100, 25, "ECS");
		room.setRoomID(rID);
		RoomsTable.getInstance().getData().put(rID, room);
// Room, rID: 4
		rID = RoomsTable.getInstance().getID();
		room = new Room(101, 30, "ECS");
		room.setRoomID(rID);
		RoomsTable.getInstance().getData().put(rID, room);
// Room, rID: 5
		rID = RoomsTable.getInstance().getID();
		room = new Room(102, 45, "ECS");
		room.setRoomID(rID);
		RoomsTable.getInstance().getData().put(rID, room);
// Super Admin, uID: 0
		int uID = UsersTable.getInstance().getID();
		User user = new User("0", "Admin");
		user.setID(uID);
		UsersTable.getInstance().getData().put(uID, user);
		Admin admin = new Admin("Trung", "Ba", "Ngyuen");
		admin.setID(uID);
		AdminsTable.getInstance().getData().put(uID, admin);
// Admin, uID: 1
		uID = UsersTable.getInstance().getID();
		user = new User("1", "Admin");
		user.setID(uID);
		UsersTable.getInstance().getData().put(uID, user);
		admin = new Admin("Ping", "Pingping", "Pingpingping");
		admin.setID(uID);
		AdminsTable.getInstance().getData().put(uID, admin);
// Employee, uID: 2 (Dean)
		uID = UsersTable.getInstance().getID();
		user = new User("2", "Employee");
		user.setID(uID);
		UsersTable.getInstance().getData().put(uID, user);
		Employee employee = new Employee("Mo", "Momo", "Momomo", 1000.1);
		employee.setID(uID);
		EmployeesTable.getInstance().getData().put(uID, employee);
		EmployeesTable.getInstance().getData().get(uID).setTitle("Dean");
// Employee, uID: 3 (Dean)
		uID = UsersTable.getInstance().getID();
		user = new User("3", "Employee");
		user.setID(uID);
		UsersTable.getInstance().getData().put(uID, user);
		employee = new Employee("Talor", "T", "Bui", 202030);
		employee.setID(uID);
		EmployeesTable.getInstance().getData().put(uID, employee);
		EmployeesTable.getInstance().getData().get(uID).setTitle("Dean");
// Employee, uID: 4 (Chair)
		uID = UsersTable.getInstance().getID();
		user = new User("4", "Employee");
		user.setID(uID);
		UsersTable.getInstance().getData().put(uID, user);
		employee = new Employee("Jack", "Q", "Du", 202030);
		employee.setID(uID);
		EmployeesTable.getInstance().getData().put(uID, employee);
		EmployeesTable.getInstance().getData().get(uID).setTitle("Chair");
// Student, uID: 5
		uID = UsersTable.getInstance().getID();
		user = new User("5", "Student");
		user.setID(uID);
		UsersTable.getInstance().getData().put(uID, user);
		Student student = new Student("John", "Wayne", "Doe");
		student.setMajor("Computer Science");
		student.setPay();
		student.setID(uID);
		StudentsTable.getInstance().getData().put(uID, student);
// Student, uID: 6
		uID = UsersTable.getInstance().getID();
		user = new User("6", "Student");
		user.setID(uID);
		UsersTable.getInstance().getData().put(uID, user);
		student = new Student("Jane", "Brown", "Dow");
		student.setID(uID);
		StudentsTable.getInstance().getData().put(uID, student);
// Student, uID: 7
		uID = UsersTable.getInstance().getID();
		user = new User("7", "Student");
		user.setID(uID);
		UsersTable.getInstance().getData().put(uID, user);
		student = new Student("Peter", "Benjamin", "Parker");
		student.setID(uID);
		StudentsTable.getInstance().getData().put(uID, student);
// College of Engineering
		College college = new College("College of Engineering", 2);
		CollegesTable.getInstance().getData().put(college.name(), college);
// College of Liberal Arts
		college = new College("College of Liberal Arts", 3);
		CollegesTable.getInstance().getData().put(college.name(), college);
// Department of CECS
		Department department = new Department("CECS", "College of Engineering", 4);
		DepartmentsTable.getInstance().getData().put(department.name(), department);
// Department of Communication
		department = new Department("Communication", "College of Liberal Arts", -1);
		DepartmentsTable.getInstance().getData().put(department.name(), department);
// Major of Computer Science
		Major major = new Major("Computer Science", "CECS", "College of Engineering");
		MajorsTable.getInstance().getData().put(major.name(), major);
// Major of English
		major = new Major("English", "Communication", "College of Liberal Arts");
		MajorsTable.getInstance().getData().put(major.name(), major);
// Course of Discrete Math, cID: 0
		int cID = CoursesTable.getInstance().getID();
		Course course = new Course("Discrete Math", "Computer Science", "CECS", "College of Engineering");
		course.setID(cID);
		CoursesTable.getInstance().getData().put(cID, course);
// Course of Oral Communication, cID: 1
		cID = CoursesTable.getInstance().getID();
		course = new Course("Oral Communication", "English", "Communication", "College of Liberal Arts");
		course.setID(cID);
		CoursesTable.getInstance().getData().put(cID, course);
// Session of Discrete Math, sID: 0
		int sID = SessionsTable.getInstance().getID();
		Session session = new Session(0, LocalTime.of(9, 30), LocalTime.of(12, 00), "Fall", 2019, "MW", "VEC", 0, 100, "College of Engineering", "CECS", "Computer Science");
		session.setID(sID);
		SessionsTable.getInstance().getData().put(sID, session);
		SessionsTable.getInstance().getData().get(sID).addToRosterByID(5);
		StudentsTable.getInstance().getData().get(5).addSessionToStudentByID(sID);
// Session of Oral Communication, sID: 1
		sID = SessionsTable.getInstance().getID();
		session = new Session(1, LocalTime.of(9, 30), LocalTime.of(12, 00), "Fall", 2019, "TTh", "ECS", 3, 100, "College of Liberal Arts", "Communication", "English");
		session.setID(sID);
		SessionsTable.getInstance().getData().put(sID, session);
// Session of Discrete Math, sID: 2
		sID = SessionsTable.getInstance().getID();
		session = new Session(0, LocalTime.of(12, 30), LocalTime.of(2, 30), "Spring", 2020, "MW", "VEC", 0, 100, "College of Engineering", "CECS", "Computer Science");
		session.setID(sID);
		SessionsTable.getInstance().getData().put(sID, session);
		SessionsTable.getInstance().getData().get(sID).addToRosterByID(7);
		StudentsTable.getInstance().getData().get(7).addSessionToStudentByID(sID);
	}
	public static void main(String[] args)
	{
		/*TreeMap<Integer, ArrayList<String>> a = new TreeMap<>();
		ArrayList<String> S = new ArrayList<>();
		S.add("zero");
		a.put(0, S);
		ArrayList<String> S1 = new ArrayList<>();
		S1.add("one");
		a.put(1, S1);
		S1.add("two");
		a.put(1, S1);
		// S = [ <0,S>, <1,S1> ]
		for(int i : a.navigableKeySet())
			System.out.println(i + " " + a.get(i));
		LocalTime t = LocalTime.of(17, 00);
		LocalTime v = LocalTime.of(18, 00);
		System.out.println(t.isBefore(v));*/
		ArrayList<String> A = new ArrayList<>();
		A.add("A");
		A.add("B");
		A.add("C");
		System.out.println(A.toString());
	}
}
