package model;

import datatypes.*;
import database.*;
import java.util.TreeMap;
import java.util.ArrayList;
import java.util.Map.Entry;

public class AdminModel
{
	public AdminModel() {}
	public int generateUserID() { return UsersTable.getInstance().getID(); }
	public int generateCourseID() { return CoursesTable.getInstance().getID(); }
	public int generateSessionID() { return SessionsTable.getInstance().getID(); }
	public int generateRoomID() { return RoomsTable.getInstance().getID(); }
	/*public void addUserAccount(User user)
	{
		UsersTable.getInstance().getData().put(user.id(), user);
	}
	public void removeUserAccount(int id)
	{
		UsersTable.getInstance().getData().remove(id);
	}*/
	/*public void updateUserAccount(User user)
	{
		UsersTable.getInstance().getData().replace(user.id(), user);
	}*/
	// *********************************
		// *********************************
		// *********************************
		// *********************************
		//			Employee Tab in Admin View
	public int addEmployeeAccount(Employee employee, String password)	// create employee acc
	{
		int id = generateUserID();
		User user = new User(password, "Employee");
		user.setID(id);
		employee.setID(id);
		//employee.setTitle("Professor");
		UsersTable.getInstance().getData().put(id, user);
		EmployeesTable.getInstance().getData().put(id, employee);
		return id;
	}
	public int addStudentAccount(Student student, String password)
	{
		int id = generateUserID();
		User user = new User(password, "Student");
		user.setID(id);
		student.setID(id);
		UsersTable.getInstance().getData().put(id, user);
		StudentsTable.getInstance().getData().put(id, student);
		return id;
	}
	/*public void removeBuilding(String name)
	{
		BuildingsTable.getInstance().getData().remove(name);
	}*/
	/*public void updateBuilding(String name, Building building)
	{
		BuildingsTable.getInstance().getData().replace(name, building);
	}*/
	/*
	public void removeRoom(int id)
	{
		RoomsTable.getInstance().getData().remove(id);
	}*/
	/*public void updateRoom(Room room)
	{
		RoomsTable.getInstance().getData().replace(room.id(), room);
	}*/
	public void addCollege(College college) { CollegesTable.getInstance().getData().put(college.name(), college); }
	/*
	public void removeCollege(String name)
	{
		CollegesTable.getInstance().getData().remove(name);
	}
	public void updateCollege(String name, College college)
	{
		CollegesTable.getInstance().getData().replace(name, college);
	}*/
	public void addDepartment(String name, Department dept) { DepartmentsTable.getInstance().getData().put(name, dept); }
	/*
	public void removeDepartment(String name)
	{
		DepartmentsTable.getInstance().getData().remove(name);
	}*/
	/*public void updateDepartment(String name, Department dept)
	{
		DepartmentsTable.getInstance().getData().replace(name, dept);
	}*/
	public void addMajor(Major major) { MajorsTable.getInstance().getData().put(major.name(), major); }
	public int addCourse(Course course)
	{
		int cID = generateCourseID();
		course.setID(cID);
		CoursesTable.getInstance().getData().put(cID, course);
		return cID;
	}
	public void addPrereqToCourse(int prereqID, int courseID) // add a prereq to a course
	{
		CoursesTable.getInstance().getData().get(courseID).prereqs().add(prereqID);
	}
	public int addSession(Session session)
	{
		int id = generateSessionID();
		session.setID(id);
		int roomID = session.roomID();
		session.setEnrollmentLimit(RoomsTable.getInstance().getData().get(roomID).occupancyLimit());
		SessionsTable.getInstance().getData().put(id, session);
		return id;
	}
	public void addBuilding(Building building)		// add building
	{
		BuildingsTable.getInstance().getData().put(building.name(), building);
	}
	public int addRoom(Room room)	// add room
	{
		int rID = generateRoomID();
		room.setRoomID(rID);
		RoomsTable.getInstance().getData().put(rID, room);
		return rID;
	}
	public void updateUniversityName(String name) { UniversityInformationTable.getInstance().getData().setName(name); }
	public void updateEmployeeAccount(int id, Employee employee, String password)	// update employee basic info
	{
		employee.setID(id);
		EmployeesTable.getInstance().getData().replace(id, employee);
		UsersTable.getInstance().getData().get(id).setPassword(password);
	}
	public void updateStudentAccount(Student student, String password)
	{
		int id = student.id();
		StudentsTable.getInstance().getData().replace(id, student);
		UsersTable.getInstance().getData().get(id).setPassword(password);
	}
	public void setCollegeDean(String collegeName, int employeeID)
	{
		int oldDean = CollegesTable.getInstance().getData().get(collegeName).deanID();
		CollegesTable.getInstance().getData().get(collegeName).setDeanID(employeeID);
		EmployeesTable.getInstance().getData().get(employeeID).setTitle("Dean");
		if(oldDean != -1)
			EmployeesTable.getInstance().getData().get(oldDean).setTitle("Professor");
	}
	public void setDepartmentChair(String departmentName, int employeeID)
	{
		int oldChair = DepartmentsTable.getInstance().getData().get(departmentName).chairID();
		DepartmentsTable.getInstance().getData().get(departmentName).setChairID(employeeID);
		EmployeesTable.getInstance().getData().get(employeeID).setTitle("Chair");
		if(oldChair != -1)
			EmployeesTable.getInstance().getData().get(oldChair).setTitle("Professor");
	}
	/*public void removeMajor(String name)
	{
		MajorsTable.getInstance().getData().remove(name);
	}*/
	public void updateMajor(String name, Major major) { MajorsTable.getInstance().getData().replace(name, major); }
	/*public void removeCourse(int id)
	{
		CoursesTable.getInstance().getData().remove(id);
	}*/
	public void updateCourse(Course course) { CoursesTable.getInstance().getData().replace(course.id(), course); }
	/*public void removeSession(int id)
	{
		SessionsTable.getInstance().getData().remove(id);
	}*/
	public void updateSession(Session session) { SessionsTable.getInstance().getData().replace(session.id(), session); }
	public void removeStudentAccount(int id)
	{
		StudentsTable.getInstance().getData().remove(id);
	}
	public void removeEmployeeAccount(int id)		// remove an employee, update college if its dean, update department if its chair
	{
		Employee employee = EmployeesTable.getInstance().getData().get(id);
		EmployeesTable.getInstance().getData().remove(id);
		if(employee.title().equals("Dean"))		// update college dean
		{
			TreeMap<String, College> colleges = CollegesTable.getInstance().getData();
			for(Entry<String, College> entry : colleges.entrySet())
			{
				College college = entry.getValue();
				if(college.deanID() == id)
					college.setDeanID(-1);
			}	
		}
		if(employee.title().equals("Chair"))		// update department chair
		{
			TreeMap<String, Department> departments = DepartmentsTable.getInstance().getData();
			for(Entry<String, Department> entry : departments.entrySet())
			{
				Department department = entry.getValue();
				if(department.chairID() == id)
					department.setChairID(-1);
			}
		}
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();	// update session that its teaaching
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			Session session = entry.getValue();
			if(session.instructorID() == id)
				session.setInstructorID(-1);
		}
	}
	public void removeCollege(String collegeName, int deanID)
	{
		EmployeesTable.getInstance().getData().get(deanID).setTitle("Employee");	// demote the dean
		CollegesTable.getInstance().getData().remove(collegeName);		// remove the college
		TreeMap<String, Department> departments = DepartmentsTable.getInstance().getData();
		for(Entry<String, Department> entry : departments.entrySet())	// remove department under college
		{
			String deptName = entry.getKey();
			Department dept = entry.getValue();
			if(dept.getCollege().equals(collegeName))
				departments.remove(deptName);
		}
		TreeMap<String, Major> majors = MajorsTable.getInstance().getData();	// remove majors under college
		for(Entry<String, Major> entry : majors.entrySet())
		{
			String majorName = entry.getKey();
			Major major = entry.getValue();
			if(major.college().equals(collegeName))
				majors.remove(majorName);
		}
		TreeMap<Integer, Course> courses = CoursesTable.getInstance().getData();	// reomve courses under college
		for(Entry<Integer, Course> entry : courses.entrySet())
		{
			int cID = entry.getKey();
			Course course = entry.getValue();
			if(course.getCollege().equals(collegeName))
				courses.remove(cID);
		}
		ArrayList<Integer> sessionsRemoved = new ArrayList<>();
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();		// remove sessions under college
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			int sID = entry.getKey();
			Session session = entry.getValue();
			if(session.college().equals(collegeName))
			{
				sessions.remove(sID);
				sessionsRemoved.add(sID);
			}
		}
		TreeMap<Integer, Student> students = StudentsTable.getInstance().getData();	// remove sessions from students, update unit
		for(Entry<Integer, Student> entry : students.entrySet())
		{
			Student stud = entry.getValue();
			for(int sID : sessionsRemoved)
				if(stud.sessionGradesEnrolled().keySet().contains(sID))
				{
					stud.sessionGradesEnrolled().remove(sID);
				//	stud.setCurrentUnit(stud.currentUnit() - 4);
				}
		}
		TreeMap<Integer, Employee> employees = EmployeesTable.getInstance().getData();	// remove sessions from employees
		for(Entry<Integer, Employee> entry : employees.entrySet())
		{
			Employee emp = entry.getValue();
			for(int session : sessionsRemoved)
				if(emp.sessionsTeaching().contains(session))
					emp.sessionsTeaching().remove((Object) session);
		}
	}
	public void removeDepartmentByName(String deptName) // remove department, update major, course, session, student, employee
	{
		TreeMap<String, Department> dept = DepartmentsTable.getInstance().getData();
		int eID = dept.get(deptName).chairID();
		dept.remove(deptName);
		TreeMap<String, Major> majors = MajorsTable.getInstance().getData();	// update major
		for(Entry<String, Major> entry : majors.entrySet())
		{
			String mName = entry.getKey();
			Major major = entry.getValue();
			if(major.dept().equals(deptName))
				majors.remove(mName);
		}
		TreeMap<Integer, Course> courses = CoursesTable.getInstance().getData();	// update courses
		for(Entry<Integer, Course> entry : courses.entrySet())
		{
			int cID = entry.getKey();
			Course course = entry.getValue();
			if(course.getDepartment().equals(deptName))
				courses.remove(cID);
		}
		ArrayList<Integer> sessionsRemoved = new ArrayList<>();
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();	// update sessions
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			int sID = entry.getKey();
			Session session = entry.getValue();
			if(session.department().equals(deptName))
			{
				sessions.remove(sID);
				sessionsRemoved.add(sID);
			}
		}
		TreeMap<Integer, Student> students = StudentsTable.getInstance().getData();	// update students
		for(Entry<Integer, Student> entry : students.entrySet())
		{
			Student stud = entry.getValue();
			for(int sID : sessionsRemoved)
				if(stud.sessionGradesEnrolled().keySet().contains(sID))
				{
					stud.sessionGradesEnrolled().remove(sID);
				//	stud.setCurrentUnit(stud.currentUnit() - 4);
				}
		}
		TreeMap<Integer, Employee> employees = EmployeesTable.getInstance().getData();	// update employee
		for(Entry<Integer, Employee> entry : employees.entrySet())
		{
			Employee emp = entry.getValue();
			int empID = entry.getKey();
			if(empID == eID)
				emp.setTitle("Professor");
			for(int sID : sessionsRemoved)
				if(emp.sessionsTeaching().contains(sID))
				{
					emp.sessionsTeaching().remove((Object) sID);
				}
		}
		
	}
	public void removeMajorByName(String majorName)		// remove major, update course, session, student, employee
	{
		TreeMap<String, Major> majors = MajorsTable.getInstance().getData();
		majors.remove(majorName);
		TreeMap<Integer, Course> courses = CoursesTable.getInstance().getData();	// update courses
		for(Entry<Integer, Course> entry : courses.entrySet())
		{
			int cID = entry.getKey();
			Course course = entry.getValue();
			if(course.getMajor().equals(majorName))
				courses.remove(cID);
		}
		ArrayList<Integer> sessionsRemoved = new ArrayList<>();
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();	// update sessions
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			int sID = entry.getKey();
			Session session = entry.getValue();
			if(session.major().equals(majorName))
			{
				sessions.remove(sID);
				sessionsRemoved.add(sID);
			}
		}
		TreeMap<Integer, Student> students = StudentsTable.getInstance().getData();	// update students
		for(Entry<Integer, Student> entry : students.entrySet())
		{
			Student stud = entry.getValue();
			for(int sID : sessionsRemoved)
				if(stud.sessionGradesEnrolled().keySet().contains(sID))
				{
					stud.sessionGradesEnrolled().remove((Object) sID);
					//stud.setCurrentUnit(stud.currentUnit() - 4);
				}
		}
		TreeMap<Integer, Employee> employees = EmployeesTable.getInstance().getData();	// update employee
		for(Entry<Integer, Employee> entry : employees.entrySet())
		{
			Employee emp = entry.getValue();
			for(int sID : sessionsRemoved)
				if(emp.sessionsTeaching().contains(sID))
					emp.sessionsTeaching().remove((Object) sID);
		}
	}
	public void removeCourseByID(int courseID)			// remove course, update session, student, employee
	{
		TreeMap<Integer, Course> courses = CoursesTable.getInstance().getData();	// remove course
		courses.remove(courseID);
		ArrayList<Integer> sessionsRemoved = new ArrayList<>();
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();	// update sessions
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			int sID = entry.getKey();
			Session session = entry.getValue();
			if(session.courseID() == courseID)
			{
				sessions.remove(sID);
				sessionsRemoved.add(sID);
			}
		}
		TreeMap<Integer, Student> students = StudentsTable.getInstance().getData();	// update students
		for(Entry<Integer, Student> entry : students.entrySet())
		{
			Student stud = entry.getValue();
			for(int sID : sessionsRemoved)
				if(stud.sessionGradesEnrolled().keySet().contains(sID))
				{
					stud.sessionGradesEnrolled().remove(sID);
					//stud.setCurrentUnit(stud.currentUnit() - 4);
				}
		}
		TreeMap<Integer, Employee> employees = EmployeesTable.getInstance().getData();	// update employee
		for(Entry<Integer, Employee> entry : employees.entrySet())
		{
			Employee emp = entry.getValue();
			for(int sID : sessionsRemoved)
				if(emp.sessionsTeaching().contains(sID))
					emp.sessionsTeaching().remove((Object) sID);
		}
	}
	public void removePrereqFromCourse(int prereqID, int courseID)	// remove a prereq from a course
	{
		CoursesTable.getInstance().getData().get(courseID).prereqs().remove((Object) prereqID);
	}
	public void removeSessionByID(int id)		// remove session by ID, update students and employee
	{
		SessionsTable.getInstance().getData().remove(id);
		TreeMap<Integer, Student> students = StudentsTable.getInstance().getData();	// update students
		for(Entry<Integer, Student> entry : students.entrySet())
		{
			Student stud = entry.getValue();
			if(stud.sessionGradesEnrolled().keySet().contains(id))
			{
				stud.sessionGradesEnrolled().remove(id);
			//	stud.setCurrentUnit(stud.currentUnit() - 4);
			}
		}
		TreeMap<Integer, Employee> employees = EmployeesTable.getInstance().getData();	// update employee
		for(Entry<Integer, Employee> entry : employees.entrySet())
		{
			Employee emp = entry.getValue();
			if(emp.sessionsTeaching().contains(id))
				emp.sessionsTeaching().remove((Object) id);
		}
	}
	public void removeBuildingByName(String name)	// remove building, remove rooms in buildings, remove sessions that use this room, update student, employee
	{
		ArrayList<Integer> roomsRemoved = new ArrayList<>();
		BuildingsTable.getInstance().getData().remove(name);
		TreeMap<Integer, Room> rooms = RoomsTable.getInstance().getData();	// remove the rooms, keep track of what is removed
		for(Entry<Integer, Room> entry : rooms.entrySet())
		{
			int rID = entry.getKey();
			Room room = entry.getValue();
			if(room.buildingName().equals(name))
				roomsRemoved.add(rID);
		}
		for(int rID : roomsRemoved)
			rooms.remove(rID);
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();	// remove sessions that have this room
		ArrayList<Integer> sessionsRemoved = new ArrayList<>();
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			int sID = entry.getKey();
			Session session = entry.getValue();
			if(roomsRemoved.contains(session.roomID()))
				sessionsRemoved.add(sID);
		}
		for(int sID : sessionsRemoved)
			sessions.remove(sID);
		TreeMap<Integer, Student> students = StudentsTable.getInstance().getData();	// update student session list and unit
		for(Entry<Integer, Student> entry : students.entrySet())
		{
			Student student = entry.getValue();
			TreeMap<Integer, String> sessionGradesEnrolled = student.sessionGradesEnrolled();
			for(int sID : sessionsRemoved)
				if(sessionGradesEnrolled.keySet().contains(sID))
				{
					sessionGradesEnrolled.remove(sID);
					//student.setCurrentUnit(student.currentUnit() - 4);
				}
		}
		TreeMap<Integer, Employee> employees = EmployeesTable.getInstance().getData();	// update employee session list
		for(Entry<Integer, Employee> entry : employees.entrySet())
		{
			Employee employee = entry.getValue();
			ArrayList<Integer> sessionsTeaching = employee.sessionsTeaching();
			for(int sID : sessionsRemoved)
				if(sessionsTeaching.contains(sID))
					sessionsTeaching.remove((Object) sID);
		}
	}
	public void removeRoomByID(int id)	// remove a room, remove sessions that have this room, update employee and student session list and unit
	{
		RoomsTable.getInstance().getData().remove(id);		// remove the room
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();	// remove sessions that have this room
		ArrayList<Integer> sessionsRemoved = new ArrayList<>();
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			int sID = entry.getKey();
			Session session = entry.getValue();
			if(session.roomID() == id)
			{
				sessions.remove(sID);
				sessionsRemoved.add(sID);
			}
		}
		TreeMap<Integer, Student> students = StudentsTable.getInstance().getData();	// update student session list and unit
		for(Entry<Integer, Student> entry : students.entrySet())
		{
			Student student = entry.getValue();
			TreeMap<Integer, String> sessionGradesEnrolled = student.sessionGradesEnrolled();
			for(int sID : sessionsRemoved)
				if(sessionGradesEnrolled.keySet().contains(sID))
					sessionGradesEnrolled.remove(sID);
		}
		TreeMap<Integer, Employee> employees = EmployeesTable.getInstance().getData();	// update employee session list
		for(Entry<Integer, Employee> entry : employees.entrySet())
		{
			Employee employee = entry.getValue();
			ArrayList<Integer> sessionsTeaching = employee.sessionsTeaching();
			for(int sID : sessionsRemoved)
				if(sessionsTeaching.contains(sID))
					sessionsTeaching.remove((Object) sID);
		}
	}
	public Object[][] getSessionGradesByID(int studentID)    // sessionID, course name, term , grade, get sessions by student id
    {
        Student student = StudentsTable.getInstance().getData().get(studentID);
        TreeMap<Integer, String> sessionGradesEnrolled = student.sessionGradesEnrolled();
        //TreeMap<int[], String> allSessionsGrades = GradesTable.getInstance().getData();
        int row = sessionGradesEnrolled.size();
        Object[][] dataTable = new Object[row][4];
        int i = 0;
        for(Entry<Integer, String> entry : sessionGradesEnrolled.entrySet())
        {
        	int sID = entry.getKey();
            String grade = entry.getValue();
            dataTable[i][0] = sID;
            int cID = SessionsTable.getInstance().getData().get(sID).courseID();
            dataTable[i][1] = CoursesTable.getInstance().getData().get(cID).name();
            Session session = SessionsTable.getInstance().getData().get(sID);
            dataTable[i][2] = session.semester() + " " + Integer.toString(session.year());
            dataTable[i][3] = grade;
            i++;
        }
        return dataTable;
    }
	public String getUniversityName() { return UniversityInformationTable.getInstance().getData().name(); }
	public TreeMap<Integer, User> getUserAccounts()
	{
		return UsersTable.getInstance().getData();
	}
	public TreeMap<Integer, Employee> getEmployeeAccounts()
	{
		return EmployeesTable.getInstance().getData();
	}
	public Object[][] getAllEmployeesConverted()		// list of all employees
	{
		TreeMap<Integer, Employee> employees = EmployeesTable.getInstance().getData();
		Object[][] tableData = new Object[employees.size()][7];
		int i = 0;
		for(Entry<Integer, Employee> entry : employees.entrySet())
		{
			int id = entry.getKey();
			Employee employee = entry.getValue();
			tableData[i][0] = employee.id();
			tableData[i][1] = UsersTable.getInstance().getData().get(id).password();
			tableData[i][2] = employee.firstname();
			tableData[i][3] = employee.middlename();
			tableData[i][4] = employee.lastname();
			tableData[i][5] = employee.title();
			tableData[i][6] = employee.salary();
			i++;
		}
		return tableData;
	}
	// ********* Unassign tab in admin view ************
		// *********************************
		// *********************************
		// *********************************
		// *********************************
	public Object[][] getSessionByInstructorID(int employeeID)		// get list of sessions that instructor is teaching
	{
		/*ArrayList<Integer> sList = EmployeesTable.getInstance().getData().get(employeeID).sessionsTeaching();
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();
		Object[][] tableData = new Object[sessions.size()][6];
		int i = 0;
		for(int sID : sessions.keySet())	// scan all sessions
		{
			if(sList.contains(sID))		// check if each session in professor's session list
			{
				tableData[i][0] = sessions.get(i).id();
				tableData[i][1] = CoursesTable.getInstance().getData().get(sessions.get(i).courseID()).name();
				tableData[i][2] = sessions.get(i).day() + " " + sessions.get(i).startTime().toString() + "-" + sessions.get(i).endTime().toString();
				tableData[i][3] = sessions.get(i).buildingName() + " " + Integer.toString(sessions.get(i).roomNumber());
				int instructorID = sessions.get(i).instructorID();
				tableData[i][4] = instructorID;
				if(instructorID == -1)
					tableData[i][4] = "N/A";
				else
					tableData[i][4] = EmployeesTable.getInstance().getData().get(instructorID).firstname() + " " +
										EmployeesTable.getInstance().getData().get(instructorID).middlename() + " " +
										EmployeesTable.getInstance().getData().get(instructorID).lastname();
				tableData[i][5] = sessions.get(i).semester() + " " + Integer.toString(sessions.get(i).year());
				i++;
			}
		}
		return tableData;*/
		ArrayList<Integer> sList = EmployeesTable.getInstance().getData().get(employeeID).sessionsTeaching();
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();
		int row = sList.size();
		Object[][] dataTable = new Object[row][6];
		int i = 0;
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			int sID = entry.getKey();
			Session session = entry.getValue();
			if(sList.contains(sID))
			{
				dataTable[i][0] = sID;
				dataTable[i][1] = CoursesTable.getInstance().getData().get(session.courseID()).name();
				dataTable[i][2] = session.day() + " " + session.startTime().toString() + "-" + session.endTime().toString();
				dataTable[i][3] = session.buildingName() + " " + Integer.toString(session.roomNumber());
				dataTable[i][4] = session.instructorID();
				dataTable[i][5] = session.semester() + " " + Integer.toString(session.year());
				i++;
			}
		}
		return dataTable;
	}
	public TreeMap<Integer, Student> getStudentAccounts()
	{
		return StudentsTable.getInstance().getData();
	}
	/*public String addSessionCheck(Session session)
	{
		ArrayList<Session> termSessions = new ArrayList<>();
		TreeMap<Integer, Session> st = SessionsTable.getInstance().getData();
		for(int i = 0; i < st.size(); i++)		// all sessions in that term
		{
			Session s = st.get(i);
			String term = s.semester() + " " + Integer.toString(s.year());
			if(term.equals(session.semester() + " " + Integer.toString(session.year())))
					termSessions.add(s);
		}
		for(Session s : termSessions)	// check session info conflict against sessions in the same term
		{
			if(session.day().equals(s.day()))	// same day, check time, room, instructor conflict
			{
				if(session.startTime().isBefore(s.endTime()) || session.endTime().isAfter(s.startTime())) // time conflict
					return "Time conflict";
				else	// no time conflict, check room
				{
					
				}
			}
		}
	}*/
	public Object[][] getAllStudentsConverted()
	{
		TreeMap<Integer, Student> students = StudentsTable.getInstance().getData();
		Object[][] tableData = new Object[students.size()][7];
		int i = 0;
		for(Entry<Integer, Student> entry : students.entrySet())
		{
			// id, pw, fn, mn, ln, major, tuition
			int id = entry.getKey();
			Student stud = entry.getValue();
			tableData[i][0] = id;
			tableData[i][1] = UsersTable.getInstance().getData().get(id).password();
			tableData[i][2] = stud.firstname();
			tableData[i][3] = stud.middlename();
			tableData[i][4] = stud.lastname();
			tableData[i][5] = stud.major();
			tableData[i][6] = stud.tuitionStatus();
			i++;
		}
		return tableData;
	}
	public ArrayList<String> getCollegeNames()
	{
		ArrayList<String> collegeNames = new ArrayList<>();
		for(String name : CollegesTable.getInstance().getData().keySet())
			collegeNames.add(name);
		return collegeNames;
	}
	public Object[][] getAllCollegeTable()
	{
		TreeMap<String, College> college = CollegesTable.getInstance().getData();
		int row = college.size();
		Object[][] dataTable = new Object[row][2];
		// col name, dean ID
		int i = 0;
		for(Entry<String, College> entry : college.entrySet())
		{
			String name = entry.getKey();
			College c = entry.getValue();
			dataTable[i][0] = name;
			dataTable[i][1] = c.deanID();
			i++;
		}
		return dataTable;
	}
	public Object[][] getDepartmentsTable()
	{
		TreeMap<String, Department> departments = DepartmentsTable.getInstance().getData();
		int row = departments.size();
		Object[][] dataTable = new Object[row][3];
		int i = 0;
		for(Entry<String, Department> entry : departments.entrySet())
		{
			String name = entry.getKey();
			Department dept = entry.getValue();
			dataTable[i][0] = name;
			dataTable[i][1] = dept.getCollege();
			dataTable[i][2] = dept.chairID();
			i++;
		}
		return dataTable;
	}
	// ********* Major tab in admin view ************
	// *********************************
	// *********************************
	// *********************************
	// *********************************
	public Object[] getAllDepartmentNamesComboBox()		// get all department names for combo box
	{
		TreeMap<String, Department> depts = DepartmentsTable.getInstance().getData();
		int row = depts.size();
		Object[] data = new Object[row];
		int i = 0;
		for(String name : depts.keySet())
			data[i++] = name;
		return data;
	}
	// ********* assign tab in admin view ************
	// *********************************
	// *********************************
	// *********************************
	// *********************************
	public Object[][] getAllSessionsConverted()		// list of all sessions
	{
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();
		Object[][] tableData = new Object[sessions.size()][6];
		int i = 0;
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			int sID = entry.getKey();
			Session session = entry.getValue();
			int cID = session.courseID();
			tableData[i][0] = sID;
			tableData[i][1] = CoursesTable.getInstance().getData().get(cID).name();
			tableData[i][2] = session.day() + " " + session.startTime().toString() + "-" + session.endTime().toString();
			tableData[i][3] = session.buildingName() + " " + Integer.toString(session.roomNumber());
			int instructorID = session.instructorID();
			tableData[i][4] = instructorID;
			tableData[i][5] = session.semester() + " " + Integer.toString(session.year());
			i++;
		}
		return tableData;
	}
	public Object[][] getEmployeeSessionsByID(int instructorID)
	{
		ArrayList<Integer> sessionsTeaching = EmployeesTable.getInstance().getData().get(instructorID).sessionsTeaching();
		Object[][] tableData = new Object[sessionsTeaching.size()][4];
		for(int i = 0; i < sessionsTeaching.size(); i++)
		{
			Session session = SessionsTable.getInstance().getData().get(sessionsTeaching.get(i));
			tableData[i][0] = sessionsTeaching.get(i);
			tableData[i][1] = CoursesTable.getInstance().getData().get(session.courseID()).name();
			tableData[i][2] = session.day() + " " + session.startTime().toString() + "-" + session.endTime().toString();
			tableData[i][3] = session.buildingName() + " " + session.roomNumber();
		}
		return tableData;
	}
	// ********* College tab in admin view ************
			// *********************************
			// *********************************
			// *********************************
			// *********************************
	public Object[] getAllEmployeeIDNameComboBox()
	{
		TreeMap<Integer, Employee> employees = EmployeesTable.getInstance().getData();
		int row = employees.size();
		Object[] data = new Object[row];
		int i = 0;
		for(Entry<Integer, Employee> entry : employees.entrySet())
		{
			int id = entry.getKey();
			Employee e = entry.getValue();
			data[i++] = Integer.toString(id) + ", " + e.title() + ", " + e.firstname() + " " + e.middlename() + " " + e.lastname();
		}
		return data;
	}
	// ********* Course tab (prereq sub tab) in admin view ************
	// *********************************
	// *********************************
	// *********************************
	// *********************************
	public Object[] getAllCoursesIDComboBox()	// get a list of all courses id
	{
		TreeMap<Integer, Course> courses = CoursesTable.getInstance().getData();
		int row = courses.size();
		Object[] data = new Object[row];
		int i = 0;
		for(int cID : courses.keySet())
			data[i++] = cID;
		return data;
	}
	public Object[] getAllCollegeNameComboBox()		// get all college names for combo box
	{
		TreeMap<String, College> colleges = CollegesTable.getInstance().getData();
		int row = colleges.size();
		Object[] data = new Object[row];
		int i = 0;
		for(String name : colleges.keySet())
				data[i++] = name;
		return data;
	}
	public Object[][] getAllMajors()		// get list of all majors
	{
		TreeMap<String, Major> majors = MajorsTable.getInstance().getData();
		int row = majors.size();
		int i = 0;
		Object[][] dataTable = new Object[row][3];
		for(Entry<String, Major> entry : majors.entrySet())
		{
			String name = entry.getKey();
			Major major = entry.getValue();
			dataTable[i][0] = name;
			dataTable[i][1] = major.dept();
			dataTable[i][2] = major.college();
			i++;
		}
		return dataTable;
	}
	// ********* Session tab  in admin view ************
			// *********************************
			// *********************************
			// *********************************
			// *********************************
	public Object[][] getAllSessions()		// get a table of all sessions
	{
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();
		int row = sessions.size();
		Object[][] dataTable = new Object[row][10];
		// sID, cID, cName, unit, instructor, time, location, limit
		int i = 0;
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			int sID = entry.getKey();
			Session session = entry.getValue();
			int cID = session.courseID();
			int rID = session.roomID();
			dataTable[i][0] = sID;
			dataTable[i][1] = cID;
			dataTable[i][2] = rID;
			dataTable[i][3] = CoursesTable.getInstance().getData().get(cID).name();
			dataTable[i][4] = CoursesTable.getInstance().getData().get(cID).unit();
			dataTable[i][5] = session.instructorID();
			dataTable[i][6] = session.day() + " " + session.startTime().toString() + "-" + session.endTime().toString();
			dataTable[i][7] = session.semester() + " " + Integer.toString(session.year());
			dataTable[i][8] = session.buildingName() + " " + Integer.toString(session.roomNumber());
			dataTable[i][9] = RoomsTable.getInstance().getData().get(rID).occupancyLimit();
			i++;
		}
		return dataTable;
	}
	// ********* Room tab  in admin view ************
			// *********************************
			// *********************************
			// *********************************
			// *********************************
	public Object[][] getAllRoomsTable()		// get table of all rooms
	{
		TreeMap<Integer, Room> rooms = RoomsTable.getInstance().getData();
		int row = rooms.size();
		int i = 0;
		Object[][] dataTable = new Object[row][4];
		for(Entry<Integer, Room> entry : rooms.entrySet())
		{
			int id = entry.getKey();
			Room room = entry.getValue();
			dataTable[i][0] = id;
			dataTable[i][1] = room.roomNumber();
			dataTable[i][2] = room.occupancyLimit();
			dataTable[i][3] = room.buildingName();
			i++;
		}
		return dataTable;
	}
	public Object[] getAllBuildingsComboBox()	// get a list of all bulidings
	{
		TreeMap<String, Building> buildings = BuildingsTable.getInstance().getData();
		int row = buildings.size();
		Object[] data = new Object[row];
		int i = 0;
		for(String name : buildings.keySet())
			data[i++] = name;
		return data;
	}
	public Object[][] getPrereqsOfSelectedCourse(int courseID)	// get prereqs of a selected course
	{
		Course course = CoursesTable.getInstance().getData().get(courseID);
		ArrayList<Integer> prereqs = course.prereqs();
		int row = prereqs.size();
		int i = 0;
		Object[][] dataTable = new Object[row][2];
		for(int cID : prereqs)
		{
			Course p = CoursesTable.getInstance().getData().get(cID);
			String name = p.name();
			dataTable[i][0] = cID;
			dataTable[i][1] = name;
			i++;
		}
		return dataTable;
	}
	public int getCollegeDeanID(String collegeName)
	{
		return CollegesTable.getInstance().getData().get(collegeName).deanID();
	}
	public Object[] getAllCourseIDNameComboBox()	// get a list of course ID, Name 
	{
		TreeMap<Integer, Course> courses = CoursesTable.getInstance().getData();
		int row = courses.size();
		Object[] data = new Object[row];
		int i = 0;
		for(Entry<Integer, Course> entry : courses.entrySet())
		{
			int id = entry.getKey();
			String name = entry.getValue().name();
			String idName = Integer.toString(id) + ", " + name;
			data[i++] = idName;
		}
		return data;
	}
	public Object[] getAllLocationsComboBox()	// get a list of all location buildingName, roomNumber
	{
		TreeMap<Integer, Room> rooms = RoomsTable.getInstance().getData();
		int row = rooms.size();
		Object[] data = new Object[row];
		int i = 0;
		for(Entry<Integer, Room> entry : rooms.entrySet())
		{
			int rID = entry.getKey();
			Room room = entry.getValue();
			String bName = room.buildingName();
			int roomNumber = room.roomNumber();
			String name = bName + " " + Integer.toString(roomNumber) + ", " + Integer.toString(rID) + ", " + Integer.toString(room.occupancyLimit());
			data[i++] = name;
		}
		return data;
	}
	// ********* Building tab  in admin view ************
	// *********************************
	// *********************************
	// *********************************
	// *********************************
	public Object[][] getAllBuildingsTable()			// get all buildings table
	{
		TreeMap<String, Building> buildings = BuildingsTable.getInstance().getData();
		int row = buildings.size();
		Object[][] dataTable = new Object[row][2];
		int i = 0;
		for(Entry<String, Building> entry : buildings.entrySet())
		{
			String name = entry.getKey();
			Building b = entry.getValue();
			dataTable[i][0] = name;
			dataTable[i][1] = b.getBuildingsLimit();
			i++;
		}
		return dataTable;
	}
	// ********* course tab in admin view ************
		// *********************************
		// *********************************
		// *********************************
		// *********************************
	public Object[][] getAllCourses()		// get all college list
	{
		TreeMap<Integer, Course> courses = CoursesTable.getInstance().getData();
		int row = courses.size();
		int i = 0;
		Object[][] dataTable = new Object[row][6];
		for(Entry<Integer, Course> entry : courses.entrySet())
		{
			int cID = entry.getKey();
			Course course = entry.getValue();
			dataTable[i][0] = cID;
			dataTable[i][1] = course.name();
			dataTable[i][2] = course.unit();
			dataTable[i][3] = course.getMajor();
			dataTable[i][4] = course.getDepartment();
			dataTable[i][5] = course.getCollege();
			i++;
		}
		return dataTable;
	}
	public Object[] getMajorsComboBox()		// get a list of major names
	{
		TreeMap<String, Major> majors = MajorsTable.getInstance().getData();
		int row = majors.size() + 1;
		Object[] data = new Object[row];
		int i = 0;
		for(String name : majors.keySet())
			data[i++] = name;
		data[i] = "Undeclared";
		return data;
	}
	// ********* Department tab in admin view ************
				// *********************************
				// *********************************
				// *********************************
				// *********************************
	public Object[] getAllEmployeeForDepartmentTabComboBox()	// get all employee name, title, id for department tab combo box
	{
		return getAllEmployeeIDNameComboBox();
	}
	public Object[][] getRosterOfSelectedSession(int sessionID)		// get roster (student information) for a selected session
	{
		Session session = SessionsTable.getInstance().getData().get(sessionID);
		ArrayList<Integer> roster = session.roster();
		int i = 0;
		int row = roster.size();
		Object[][] dataTable = new Object[row][7];
		TreeMap<Integer, Student> students = StudentsTable.getInstance().getData();
		for(int studentID : roster)
		{
			Student student = students.get(studentID);
			dataTable[i][0] = studentID;
			dataTable[i][1] = UsersTable.getInstance().getData().get(studentID).password();
			dataTable[i][2] = student.firstname();
			dataTable[i][3] = student.middlename();
			dataTable[i][4] = student.lastname();
			dataTable[i][5] = student.major();
			dataTable[i][6] = student.tuitionStatus();
			i++;	
		}
		return dataTable;
	}
	public void assignEmployeeToTeachSession(int employeeID, int sessionID)		// assign employee to a session
	{
		EmployeesTable.getInstance().getData().get(employeeID).addSessionById(sessionID);	// update employee's session list
		SessionsTable.getInstance().getData().get(sessionID).setInstructorID(employeeID);	// update session instructor
	}
	public void unassignEmployeeFromSessionByID(int employeeID, int sessionID)	// un assign employee from its sessions
	{
		EmployeesTable.getInstance().getData().get(employeeID).removeSessionByID(sessionID);
		SessionsTable.getInstance().getData().get(sessionID).setInstructorID(-1);
	}
	public void assignStudentGrade(int studentID, int sessionID, String grade)
	{
		StudentsTable.getInstance().getData().get(studentID).setGrade(sessionID, grade);
		/*
		 * int[] key = {studentID, courseID}; TreeMap<int[], String> grades =
		 * GradesTable.getInstance().getData(); if(!grades.containsKey(key))
		 * grades.put(key, grade); else grades.replace(key, grade);
		 */
	}
	/*public void resetStudentSemesterUnits()
	{
		TreeMap<Integer, Student> allStudents = StudentsTable.getInstance().getData();
		for(int i = 0; i < allStudents.size(); i++)
			allStudents.get(i).setCurrentUnit(0);
	}*/
}