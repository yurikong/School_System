package model;

import datatypes.Employee;
import datatypes.Session;
import database.CoursesTable;
import database.EmployeesTable;
import database.SessionsTable;
import database.StudentsTable;

import java.util.ArrayList;
import java.util.TreeMap;
import java.util.Map.Entry;

public class EmployeeModel
{
	public EmployeeModel() {}
	public Employee getEmployeeInformation(int id)
	{
		return EmployeesTable.getInstance().getData().get(id);
	}
	/*public TreeMap<String, ArrayList<Session>> getEmployeeScheduleByTerm(int id)
	{
		TreeMap<String, ArrayList<Session>> scheduleByTerm = new TreeMap<>();
		ArrayList<String> terms = new ArrayList<>();					// all terms
		for(int i = 0; i < SessionsTable.getInstance().getData().size(); i++)	// find all terms
		{
			Session session = SessionsTable.getInstance().getData().get(i);
			String term = session.semester() + ' ' + Integer.toString(session.year());
			if(!terms.contains(term))
				terms.add(term);
		}
		ArrayList<Integer> sessionIDs = EmployeesTable.getInstance().getData().get(id).sessionsTeaching();	// all sessions of an employee
		for(String term : terms)						// get sessions by terms
		{
			ArrayList<Session> sessionsByTerm = new ArrayList<>();
			for(int sID : sessionIDs)	// check if a session is in a term
			{
				Session session = SessionsTable.getInstance().getData().get(sID);
				String sTerm = session.semester() + ' ' + Integer.toString(session.year());
				if(term.equals(sTerm))
					sessionsByTerm.add(session);
			}
			scheduleByTerm.put(term, sessionsByTerm);
		}
		return scheduleByTerm;
	}
	public TreeMap<String, Object[][]> getEmployeeScheduleByTermConverted(int id)
	{
		TreeMap<String, ArrayList<Session>> scheduleByTerm = getEmployeeScheduleByTerm(id);
		TreeMap<String, Object[][]> scheduleByTermConverted = new TreeMap<>();
		for(String term : scheduleByTerm.keySet())
		{
			ArrayList<Session> sessions = scheduleByTerm.get(term);
			Object[][] tableData = new Object[sessions.size()][4];
			for(int i = 0; i < sessions.size(); i++)
			{
				tableData[i][0] = sessions.get(i).courseID(); // courseID
				tableData[i][1] = CoursesTable.getInstance().getData().get(tableData[i][0]).name();
				tableData[i][2] = sessions.get(i).buildingName() + " " + Integer.toString(sessions.get(i).roomNumber());
				tableData[i][3] = sessions.get(i).day() + " " + sessions.get(i).startTime().toString() + "-" + sessions.get(i).endTime().toString();
			}
			scheduleByTermConverted.put(term, tableData);
		}
		return scheduleByTermConverted;
	}*/
	public Object[] employeeTermsComboBox(int employeeID)	// get all employee terms combo box
	{
		ArrayList<String> terms = new ArrayList<>();
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			Session session = entry.getValue();
			String term = session.semester() + " " + Integer.toString(session.year());
			if(!terms.contains(term))
				terms.add(term);
		}
		int row = terms.size();
		Object[] data = new Object[row];
		int i = 0;
		for(String term : terms)
			data[i++] = term;
		return data;
	}
	public Object[][] getEmployeeScheduleByTerm(int employeeID, String term)
	{
		int row = 0;
		ArrayList<Integer> sessionsTeaching = EmployeesTable.getInstance().getData().get(employeeID).sessionsTeaching();
		for(int sessionID : sessionsTeaching)
		{
			Session session = SessionsTable.getInstance().getData().get(sessionID);
			String sTerm = session.semester() + " " + Integer.toString(session.year());
			if(sTerm.equals(term))
				row++;
		}
		int i = 0;
		Object[][] dataTable = new Object[row][4];
		for(int sessionID : sessionsTeaching)
		{
			Session session = SessionsTable.getInstance().getData().get(sessionID);
			String sTerm = session.semester() + " " + Integer.toString(session.year());
			if(sTerm.equals(term))
			{
				int cID = session.courseID();
				dataTable[i][0] = sessionID;
				dataTable[i][1] = CoursesTable.getInstance().getData().get(cID).name();
				dataTable[i][2] = session.buildingName() + " " + Integer.toString(session.roomNumber());
				dataTable[i][3] = session.day() + " " + session.startTime().toString() + " " + session.endTime().toString();
				i++;
			}
		}
		return dataTable;
	}
	// sessionID, courseName, location, time, term, instructor, prereqs
	public Object[][] getAllSessions()		// all session schedules
	{
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();
		int row = sessions.size();
		Object[][] dataTable = new Object[row][7];
		int i = 0;
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			int sID = entry.getKey();
			Session session = entry.getValue();
			int cID = session.courseID();
			dataTable[i][0] = sID;
			dataTable[i][1] = CoursesTable.getInstance().getData().get(cID).name();
			dataTable[i][2] = session.buildingName() + " " + Integer.toString(session.roomNumber());
			dataTable[i][3] = session.day() + " " + session.startTime().toString() + " " + session.endTime().toString();
			dataTable[i][4] = session.semester() + " " + Integer.toString(session.year());
			dataTable[i][5] = session.instructorID();
			dataTable[i][6] = CoursesTable.getInstance().getData().get(cID).prereqs().toString();
			i++;
		}
		return dataTable;
	}
}
