package model;

import datatypes.*;
import database.*;

import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.TreeMap;

public class SuperAdminModel extends AdminModel
{
	public SuperAdminModel()
	{
		super();
	}
	// *********************************
		// *********************************
		// *********************************
		// *********************************
		//			Admin Tab in Admin View
	public int addAdminAccount(Admin admin, String password)
	{
		int id = generateUserID();
		User user = new User(password, "Admin");
		user.setID(id);
		admin.setID(id);
		UsersTable.getInstance().getData().put(id, user);
		AdminsTable.getInstance().getData().put(id, admin);
		return id;
	}
	public void removeAdminAccount(int id)
	{
		AdminsTable.getInstance().getData().remove(id);
		UsersTable.getInstance().getData().remove(id);
	}
	public void updateAdminAccount(int id, Admin admin, String password)
	{
		admin.setID(id);;
		AdminsTable.getInstance().getData().replace(id, admin);
		UsersTable.getInstance().getData().get(id).setPassword(password);
	}
	Object[][] getAdminTable()
	{
		int row = AdminsTable.getInstance().getData().size();
		Object[][] table = new Object[row][5];
		// id, pw, fn, mn, ln
		int i = 0;
		TreeMap<Integer, Admin> admins = AdminsTable.getInstance().getData();
		for(Entry<Integer, Admin> entry : admins.entrySet())
		{
			int id = entry.getKey();
			Admin admin = entry.getValue();
			table[i][0] = id;
			table[i][1] = UsersTable.getInstance().getData().get(id).password();
			table[i][2] = admin.firstname();
			table[i][3] = admin.middlename();
			table[i][4] = admin.lastname();
			i++;
		}
		return table;
	}
	public TreeMap<Integer, Admin> getAllAdmins()
	{
		return AdminsTable.getInstance().getData();
	}
	public Object[][] getAllAdminsConverted()
	{
		TreeMap<Integer, Admin> admins = getAllAdmins();
		int row = admins.size();
		//System.out.println(admins.size());
		Object[][] tableData = new Object[row-1][5];
		//System.out.println(tableData.length);
		int i = 0;
		for (Entry<Integer, Admin> entry : admins.entrySet()) {
			Integer id = entry.getKey();
			Admin 	ad = entry.getValue();
			if(id != 0) { // Exclude superadmin!
				tableData[i][0] = ad.id();
				tableData[i][1] = UsersTable.getInstance().getData().get(id).password();
				tableData[i][2] = ad.firstname();
				tableData[i][3] = ad.middlename().substring(0, 1);
				tableData[i][4] = ad.lastname();
			    i++;
			}
		    //stem.out.printf("%s : %s : %s : %s : %s\n", id, ad.id(), ad.firstname() ,ad.middlename(), ad.firstname() );
		}

//		int i = 0;
//		for (Entry<Integer, Admin> entry : admins.entrySet()) {
//			Integer id = entry.getKey();
//			Admin 	ad = entry.getValue();
//			tableData[i][0] = ad.id();
//			tableData[i][1] = ad.firstname();
//			tableData[i][2] = ad.middlename().substring(0, 1);
//			tableData[i][3] = ad.lastname();
//			i++;
//		}
//		
		
//		for(int i = 0; i < admins.size(); i++)
//		{
//			System.out.println(admins.get(i));
////			tableData[i][0] = admins.get(i).id();
////			tableData[i][1] = admins.get(i).firstname();
////			tableData[i][2] = admins.get(i).middlename().substring(0, 1);
////			tableData[i][3] = admins.get(i).lastname();
////			
//			System.out.println(admins.get(i).id());
//		}
		
		return tableData;
	}
}
