package model;

import datatypes.Student;
import datatypes.Employee;
import datatypes.Session;
import database.StudentsTable;
import database.UniversityInformationTable;
import database.CoursesTable;
import database.EmployeesTable;
import database.SessionsTable;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.TreeMap;

public class StudentModel
{
	public StudentModel() {}
	public Student getStudentInformation(int id)
	{
		return StudentsTable.getInstance().getData().get(id);
	}
	public void enrollSession(int studentID, int sessionID)
	{
		StudentsTable.getInstance().getData().get(studentID).addSessionToStudentByID(sessionID);
		//StudentsTable.getInstance().getData().get(studentID).sessionGradesEnrolled();
		SessionsTable.getInstance().getData().get(sessionID).addToRosterByID(studentID);
	}
	public void dropSession(int studentID, int sessionID)
	{
		//int index = StudentsTable.getInstance().getData().get(studentID).sessionsEnrolled().indexOf(sessionID);
		//StudentsTable.getInstance().getData().get(studentID).sessionsEnrolled().remove(index);
		StudentsTable.getInstance().getData().get(studentID).removeSessionByID(sessionID);
		SessionsTable.getInstance().getData().get(sessionID).removeRosterByID(studentID);
	}
	public Object[] studentTermsComboBox()		// get all terms combo box
	{
		ArrayList<String> terms = new ArrayList<>();
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			Session session = entry.getValue();
			String term = session.semester() + " " + Integer.toString(session.year());
			if(!terms.contains(term))
				terms.add(term);
		}
		int row = terms.size();
		Object[] data = new Object[row];
		int i = 0;
		for(String term : terms)
			data[i++] = term;
		return data;
	}
	public Object[][] getStudentScheduleByTerm(int studentID, String term)		// get all sessions by term
	{
		int row = 0;
		TreeMap<Integer, String> sessionGradesEnrolled = StudentsTable.getInstance().getData().get(studentID).sessionGradesEnrolled();
		for(Entry<Integer, String> sgEntry : sessionGradesEnrolled.entrySet())
		{
			int sessionID = sgEntry.getKey();
			Session session = SessionsTable.getInstance().getData().get(sessionID);
			String sTerm = session.semester() + " " + Integer.toString(session.year());
			if(sTerm.equals(term))
				row++;
		}
		int i = 0;
		Object[][] dataTable = new Object[row][6];
		for(Entry<Integer, String> sgEntry : sessionGradesEnrolled.entrySet())
		{
			int sessionID = sgEntry.getKey();
			String grade = sgEntry.getValue();
			Session session = SessionsTable.getInstance().getData().get(sessionID);
			String sTerm = session.semester() + " " + Integer.toString(session.year());
			if(sTerm.equals(term))
			{
				int cID = session.courseID();
				dataTable[i][0] = sessionID;
				dataTable[i][1] = CoursesTable.getInstance().getData().get(cID).name();
				dataTable[i][2] = session.buildingName() + " " + Integer.toString(session.roomNumber());
				dataTable[i][3] = session.day() + " " + session.startTime().toString() + " " + session.endTime().toString();
				dataTable[i][4] = session.instructorID();
				//dataTable[i][5] = CoursesTable.getInstance().getData().get(cID).prereqs().toString();
				dataTable[i][5] = grade;
				i++;
			}
		}
		return dataTable;
	}
	// sessionID, course name, room, time, semester, instructor, prereq
	public Object[][] getAllSessions()
	{
		TreeMap<Integer, Session> sessions = SessionsTable.getInstance().getData();
		int row = sessions.size();
		Object[][] dataTable = new Object[row][7];
		int i = 0;
		for(Entry<Integer, Session> entry : sessions.entrySet())
		{
			int sID = entry.getKey();
			Session session = entry.getValue();
			int cID = session.courseID();
			dataTable[i][0] = sID;
			dataTable[i][1] = CoursesTable.getInstance().getData().get(cID).name();
			dataTable[i][2] = session.buildingName() + " " + Integer.toString(session.roomNumber());
			dataTable[i][3] = session.day() + " " + session.startTime().toString() + " " + session.endTime().toString();
			dataTable[i][4] = session.semester() + " " + Integer.toString(session.year());
			dataTable[i][5] = session.instructorID();
			dataTable[i][6] = CoursesTable.getInstance().getData().get(cID).prereqs().toString();
			i++;
		}
		return dataTable;
	}
	// studentID, sessionID
	public boolean isPrereqFulfilled(int studentID, int sessionID)	// check if a student has taken all prereqs of the sesion he wants to add
	{
		TreeMap<Integer, String> sessionGradesEnrolled = StudentsTable.getInstance().getData().get(studentID).sessionGradesEnrolled();
		ArrayList<Integer> coursesTaken = new ArrayList<>();
		for(int sID : sessionGradesEnrolled.keySet())
			coursesTaken.add(SessionsTable.getInstance().getData().get(sID).courseID());
		int courseID = SessionsTable.getInstance().getData().get(sessionID).courseID();
		ArrayList<Integer> prereqs = CoursesTable.getInstance().getData().get(courseID).prereqs();
		for(int cID : prereqs)
			if(!coursesTaken.contains(cID))
				return false;
		return true;
	}
}