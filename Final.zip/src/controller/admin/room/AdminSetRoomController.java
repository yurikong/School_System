package controller.admin.room;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import datatypes.Room;
import model.AdminModel;
import util.ToolBox;
import view.AdminView;

public class AdminSetRoomController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminSetRoomController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adViewController = adViewController;
		this.adModel = adModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(view.roomBuildingComboBox.getSelectedIndex() == -1 ) {return;}

		String  roomNumber	= view.roomNumberField.getText();
		String 	roomLimit 	= view.roomLimitField.getText();
		String 	building    = view.roomBuildingComboBox.getSelectedItem().toString();
		
		//Get table model:
		DefaultTableModel 	tModel 	= (DefaultTableModel) view.roomTable.getModel();
		int 				i 		= view.roomTable.getSelectedRow();
		
		
		if(roomNumber.isEmpty() || roomLimit.isEmpty()){
			JOptionPane.showMessageDialog(null, "Fields should not be empty!");
			return;
		}
		if( !ToolBox.isNumeric(roomNumber) && !ToolBox.isNumeric(roomLimit)){
			JOptionPane.showMessageDialog(null, "Fields should be numeric!");
			return;
		};
		

		//***** VALIDATE DEPARTMENT NAME TAKEN 
		boolean isNameTaken = false;
		for (int row = 0; row < view.roomTable.getRowCount(); row++){
			if( tModel.getValueAt(row, 3).toString().equals(building) ) {
				if( tModel.getValueAt(row, 1).toString().equals(roomNumber)) {	// compare dep
					isNameTaken = true;
					break;
				}
			}
		}
		
		if( isNameTaken == false  ) {
			int roomNumberInt = Integer.parseInt(roomNumber);
			int roomLimitInt = Integer.parseInt(roomLimit);
			// << updateDB >>	
				//int rID = adModel.addRoom(new Room(roomNumberInt,roomLimitInt,building));
			int rID = 99;
			// << update UI >>
			tModel.addRow(new Object[]{rID, roomNumber, roomLimit, building });
			adViewController.updateSessionTab();
			// << alert UI >>
			JOptionPane.showMessageDialog(null, "Added!");

		} else {
			JOptionPane.showMessageDialog(null, "Department Name is taken please take another name!");
		}
	}
	
}
