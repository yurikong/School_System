package controller.admin.room;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import model.AdminModel;
import view.AdminView;

public class AdminRemoveRoomController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminRemoveRoomController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adViewController = adViewController;
		this.adModel = adModel;
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		DefaultTableModel tModel = (DefaultTableModel) view.roomTable.getModel();
		int i = view.roomTable.getSelectedRow();
		
		if( i != -1) {
			int     roomID  	= Integer.parseInt( view.roomTable.getValueAt(i, 0).toString() );
			int     roomNumber  = Integer.parseInt( view.roomTable.getValueAt(i, 1).toString() );
			int 	roomLimit 	= Integer.parseInt( view.roomTable.getValueAt(i, 2).toString() );
			String 	building    = view.roomBuildingComboBox.getSelectedItem().toString();
			
			// << Update DB >>	
			adModel.removeRoomByID(roomID);
			
			// << Update UI >>
			tModel.removeRow(i);
			view.roomTable.getSelectionModel().clearSelection();
			view.roomRemoveField.setText("");

			// << Alert UI >>

		}
		else {
			JOptionPane.showMessageDialog (null, "Please select a row!", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
