package controller.admin.course;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import model.AdminModel;
import view.AdminView;

public class AdminAddCoursePrereqControlller implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	public AdminAddCoursePrereqControlller(AdminView view, AdminModel adModel) {
		this.view = view;
		this.adModel = adModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(view.prereqdCourseCombox.getSelectedIndex() == -1 ) {return;}
		if(view.courseTable.getSelectionModel().isSelectionEmpty()) {return;}

		String selectedCourse = view.prereqdCourseCombox.getSelectedItem().toString();
		String splitted[] = selectedCourse.split(", ");
		String prereCourseID = splitted[0];
		String prerecourseName = splitted[1];
		//Get table model:
		DefaultTableModel 	tModel 	= (DefaultTableModel) view.prereqTable.getModel();
		int 				i 		= view.prereqTable.getSelectedRow();
		
		
		DefaultTableModel 	sModel 	= (DefaultTableModel) view.courseTable.getModel();
		int 				sI 		= view.courseTable.getSelectedRow();
		
		if(prereCourseID.equals(sModel.getValueAt(sI, 0).toString())) {
			JOptionPane.showMessageDialog(null, "Can't Add the yourself.");
			return;
		}

		for (int row = 0; row < view.prereqTable.getRowCount(); row++){ 
			if( tModel.getValueAt(row, 0).toString().equals(prereCourseID)) {
				JOptionPane.showMessageDialog(null, "Prereq course is already added!");
				return;
			}
		}
		int selectedCourseID = Integer.parseInt(sModel.getValueAt(sI, 0).toString());
		int prereCourseIDInt = Integer.parseInt(prereCourseID);
		// << updateDB >>	
		adModel.addPrereqToCourse(prereCourseIDInt, selectedCourseID);
		// << update UI >>

		tModel.addRow(new Object[]{ prereCourseID, prerecourseName });

		// << alert UI >>
	}
}
