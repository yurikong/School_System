package controller.admin.course;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import model.AdminModel;
import view.AdminView;

public class AdminRemoveCourseController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminRemoveCourseController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adViewController = adViewController;
		this.adModel = adModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		DefaultTableModel tModel = (DefaultTableModel) view.courseTable.getModel();
		int i = view.courseTable.getSelectedRow();
		if( i != -1) {
			int cID = Integer.parseInt( view.courseTable.getValueAt(i, 0).toString() );
			// << Update DB >>	
			adModel.removeCourseByID(cID);
			// << Update UI >>
			tModel.removeRow(i);
			view.courseTable.getSelectionModel().clearSelection();
			view.courseRemoveCourseField.setText("");	
			adViewController.updateSessionTab();
			// << Alert UI >>

		}
		else {
			JOptionPane.showMessageDialog (null, "Please select a row!", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
