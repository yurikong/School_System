package controller.admin.course;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import datatypes.Course;
import model.AdminModel;
import view.AdminView;

public class AdminAddCourseController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminAddCourseController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adViewController = adViewController;
		this.adModel = adModel;
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if( view.courseTable.getRowCount() >= 100){JOptionPane.showMessageDialog(null, "Maximum Reach!"); return;} ;
		if(view.courseMajorComboBox.getSelectedIndex() == -1 ) {return;}

	
		String courseName 		= view.courseNameField.getText().toString();
		String majorName		= view.courseMajorComboBox.getSelectedItem().toString();
		String departmentName 	= "";
		String collegeName  	= "";
		
		// get Department
		for (int row = 0; row < view.majorTable.getRowCount(); row++){ 
			if( view.majorTable.getModel().getValueAt(row, 0) == majorName) {
				departmentName = view.majorTable.getModel().getValueAt(row, 1).toString();
				collegeName = view.majorTable.getModel().getValueAt(row, 2).toString();
			}
		}
		
		if( departmentName.isEmpty() ) JOptionPane.showMessageDialog(null, "Major Not Found!");
		if( collegeName.isEmpty() ) JOptionPane.showMessageDialog(null, "collegeName Not Found!");

		
		//Get table model:
		DefaultTableModel 	tModel 	= (DefaultTableModel) view.courseTable.getModel();
		int 				i 		= view.courseTable.getSelectedRow();
		
		//***** VALIDATE MAJOR NAME TAKEN 
		boolean isNameTaken = false;
		for (int row = 0; row < view.courseTable.getRowCount(); row++){ 
			if(tModel.getValueAt(row, 1).toString().equals(courseName)) {
				isNameTaken = true;
				break;
			}
		}
		
		if( isNameTaken == false  ) {
			if(!courseName.isEmpty()) {
				// << updateDB >>	
				int cID = adModel.addCourse(new Course( courseName, majorName, departmentName, collegeName));
				// << update UI >>
				tModel.addRow(new Object[]{ cID, courseName, 4, majorName, departmentName, collegeName });
				adViewController.updateSessionTab();
				// << alert UI >>
				JOptionPane.showMessageDialog(null, "Added!");
			} else {
				JOptionPane.showMessageDialog(null, "Course Name Can't be empty");
			}
		} else {
			JOptionPane.showMessageDialog(null, "Course Name is taken please take another name!");
		}
	}
}
