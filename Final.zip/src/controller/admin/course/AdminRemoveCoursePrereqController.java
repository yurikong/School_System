package controller.admin.course;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import model.AdminModel;
import view.AdminView;

public class AdminRemoveCoursePrereqController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	public AdminRemoveCoursePrereqController(AdminView view, AdminModel adModel) {
		this.view = view;
		this.adModel = adModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(view.courseTable.getSelectionModel().isSelectionEmpty()) {return;}
		if(view.prereqTable.getSelectionModel().isSelectionEmpty()) {return;}

		DefaultTableModel tModel = (DefaultTableModel) view.prereqTable.getModel();
		int i = view.prereqTable.getSelectedRow();
		
		DefaultTableModel stModel = (DefaultTableModel) view.courseTable.getModel();
		int sI = view.courseTable.getSelectedRow();
		if( i != -1) {
			int prereqID = Integer.parseInt(tModel.getValueAt(i, 0).toString());
			int selectedID = Integer.parseInt(stModel.getValueAt(sI, 0).toString());

			// << Update DB >>	
			adModel.removePrereqFromCourse(prereqID, selectedID);
			
			// << Update UI >>
			tModel.removeRow(i);
			view.prereqTable.getSelectionModel().clearSelection();
			view.prereqRemoveCourseField.setText("");

			// << Alert UI >>
		}
		else {
			JOptionPane.showMessageDialog (null, "Please select a row!", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
