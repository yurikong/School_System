package controller.admin.course;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;

import model.AdminModel;
import view.AdminView;

public class AdminSelectPrereqCourseController implements MouseListener  {
	private AdminView view;
	private AdminModel adModel;
	public AdminSelectPrereqCourseController(AdminView view, AdminModel adModel) {
		this.view = view;
		this.adModel = adModel;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		TableModel tModel = view.courseTable.getModel();
		int i = view.courseTable.getSelectedRow();
		int cID = Integer.parseInt( view.courseTable.getValueAt(i, 0).toString());

	// Init Prereq Tab
		Object [] comboBox = adModel.getAllCourseIDNameComboBox();
		view.prereqdCourseCombox.setModel(new DefaultComboBoxModel(comboBox));
		String[] header  = new String[] { "Course ID", "Course Name" };	 // init
		Object[][] data = adModel.getPrereqsOfSelectedCourse(cID);
//		view.prereqdCourseCombox.setModel(new DefaultComboBoxModel(adModel.getAllCourseIDNameComboBox()));
		view.prereqTable.setModel(new DefaultTableModel(data, header));
	// End Init Prereq Tab
	
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
