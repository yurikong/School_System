package controller.admin.department;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import datatypes.Department;
import view.AdminView;
import model.AdminModel;

public class AdminSetDepartmentController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminSetDepartmentController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adViewController = adViewController;
		this.adModel = adModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		//*****  VALIDATE EMPTY FILEDS
		if(view.departmentChairComboBox.getSelectedIndex() == -1 ) {JOptionPane.showMessageDialog(null,"Please pick an employee");return;}
		if(view.departmentCollegeComboBox.getSelectedIndex() == -1) {JOptionPane.showMessageDialog(null,"Please pick an college");return;}
		
		String departmentName 	= view.departmentNameField.getText();
		String collegeName 		= view.departmentCollegeComboBox.getSelectedItem().toString();

		String candidate	= view.departmentChairComboBox.getSelectedItem().toString();
		String [] candidateInfo = candidate.split(", "); 
		int    candidateID 	  = Integer.parseInt( candidateInfo[0] );
		String candidateTitle = candidateInfo[1];
		String candidateName  = candidateInfo[2].toString();
		
		//Get table model:
		DefaultTableModel 	tModel 	= (DefaultTableModel) view.departmentTable.getModel();
		int 				i 		= view.departmentTable.getSelectedRow();
		//***** VALIDATE CANDIDATE IF CANDIDATE IS A "PROFESSOR"
		if(!candidateTitle.equals("Professor")) { JOptionPane.showMessageDialog(null, "Please the selected employee MUST be a professor!");return;}
				
		
		if( view.departmentAddRadioButton.isSelected() ) {
			if( view.departmentTable.getRowCount() >= 30){JOptionPane.showMessageDialog(null, "Maximum Reach!"); return;} ;

			//***** VALIDATE DEPARTMENT NAME TAKEN 
			boolean isNameTaken = false;
			for (int row = 0; row < view.departmentTable.getRowCount(); row++){ 
				if( tModel.getValueAt(row, 0).toString().equals(departmentName)) {	// compare dep
					if( tModel.getValueAt(row, 1).toString().equals(collegeName)) { // compare col
						isNameTaken = true;
						break;
					}
				}
			}
			//***** VALIDATE DEPARTMENT NAME TAKEN 
			if( isNameTaken == true  ) {JOptionPane.showMessageDialog(null, "Department Name is taken please take another name!");return;}
			//***** VALIDATE FIELS
			if( departmentName.isEmpty()) {JOptionPane.showMessageDialog(null, "Department Name Can't be empty"); return;}
			if(view.departmentChairComboBox.getSelectedIndex() == -1) { JOptionPane.showMessageDialog(null,"Please pick an employee."); return;}
			if(view.departmentCollegeComboBox.getSelectedIndex() == -1) { JOptionPane.showMessageDialog(null,"Please pick an college."); return;}

	
			// << updateDB >>	
			adModel.addDepartment(departmentName, new Department(departmentName, collegeName, candidateID));
			
			// << update UI >>
			tModel.addRow(new Object[]{ departmentName, collegeName, candidateID });
			adViewController.updateDepartmentTab();
			adViewController.updateMajorTab();
			adViewController.updateCourseTab();
			adViewController.updateSessionTab();
			// << alert UI >>
			JOptionPane.showMessageDialog(null, "Added!");
		}
		if( view.departmentEditRadioButton.isSelected()) {
			//***** VALIDATE IF SELECTING A ROW IN THE TABLE
			if( view.departmentTable.getSelectedRow() == -1 ) {JOptionPane.showMessageDialog(null,"Please Select A Row in the Table!"); return;}

			// << update DB >>
			adModel.setDepartmentChair(departmentName, candidateID);
			
			// << update UI >>
			//tModel.setValueAt(collegeName, i, 1);
			tModel.setValueAt(candidateID, i, 2);
			adViewController.updateEmployeeTab();
			adViewController.updateDepartmentTab();
			adViewController.updateMajorTab();
			adViewController.updateCourseTab();
			adViewController.updateSessionTab();
			// << alert UI >>
			JOptionPane.showMessageDialog(null, "Saved!");
		}
	}
}
