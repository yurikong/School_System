package controller.admin.department;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import model.AdminModel;
import view.AdminView;

public class AdminRemoveDepartmentController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminRemoveDepartmentController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adViewController = adViewController;
		this.adModel = adModel;
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		DefaultTableModel tModel = (DefaultTableModel) view.departmentTable.getModel();
		int i = view.departmentTable.getSelectedRow();
		if( i != -1) {
			String  departmentName 	= view.departmentNameField.getText();
//			String 	collegeName 	= view.departmentCollegeComboBox.getSelectedItem().toString();
//			int 	chairID			= (int)(view.departmentTable.getValueAt(i, 2));
//			
			// << Update DB >>	
			adModel.removeDepartmentByName(departmentName);
			
			// << Update UI >>
			tModel.removeRow(i);
			view.departmentTable.getSelectionModel().clearSelection();
			view.departmentRemoveDepartmentField.setText("");
			adViewController.updateMajorTab();
			adViewController.updateCourseTab();
			adViewController.updateSessionTab();
			
			// << Alert UI >>

		}
		else {
			JOptionPane.showMessageDialog (null, "Please select a row!", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
