package controller.admin.employee;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import model.AdminModel;
import view.AdminView;

public class AdminRemoveEmployeeSessionController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminRemoveEmployeeSessionController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adModel = adModel;
		this.adViewController = adViewController;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String empName = view.empAssignNameField.getText();
		if(empName.isEmpty()) {
			JOptionPane.showMessageDialog (null, "Please pick an Employee!", "Error", JOptionPane.ERROR_MESSAGE);
		}
		else {
			DefaultTableModel tModel = (DefaultTableModel) view.empUnassignSessionTable.getModel();
			int i = view.empUnassignSessionTable.getSelectedRow();
			int sessionID = Integer.parseInt( tModel.getValueAt(i, 0).toString());
			
			DefaultTableModel empModel 	= (DefaultTableModel) view.empListTable.getModel();
			int empIndex 			  	= view.empListTable.getSelectedRow();
			int employeeID 				= Integer.parseInt( empModel.getValueAt(empIndex, 0).toString());

			
			if( i != -1) {
				int id = Integer.parseInt(tModel.getValueAt(i, 0).toString());
		
				// << Update DB >>	
				adModel.unassignEmployeeFromSessionByID(employeeID, sessionID);
				// << Update UI >>
				tModel.removeRow(i);
				adViewController.updateEmployeeTab();
				adViewController.updateSessionTab();
				// << Alert UI >>
				JOptionPane.showMessageDialog (null, "Successfully Remove the Session from Employee Schedule!", "Success", JOptionPane.INFORMATION_MESSAGE);

			}
			else {
				JOptionPane.showMessageDialog (null, "Please select a session!", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
}
