package controller.admin.employee;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import model.AdminModel;
import model.SuperAdminModel;
import view.AdminView;

public class AdminRemoveEmployeeController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminRemoveEmployeeController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adModel = adModel;
		this.adViewController = adViewController;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		DefaultTableModel tModel = (DefaultTableModel) view.empListTable.getModel();
		int 				i    = view.empListTable.getSelectedRow();
		if( i != -1) {
			int id = Integer.parseInt(tModel.getValueAt(i, 0).toString());
	
			// << Update DB >>	
			adModel.removeEmployeeAccount(id);
			// << Update UI >>
			tModel.removeRow(i);
			view.adminIDField.setText("");
			view.adminFirstNameField.setText("");
			view.adminMiddleNameField.setText("");
			view.adminLastNamefield.setText("");
			view.adminPWField.setText("");
			adViewController.updateCollegeTab();	// collegeTab
			adViewController.updateDepartmentTab();
			adViewController.updateSessionTab();
			// << Alert UI >>

		}
		else {
			JOptionPane.showMessageDialog (null, "Please select a user!", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
