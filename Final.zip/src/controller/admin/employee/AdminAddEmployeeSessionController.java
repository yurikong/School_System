package controller.admin.employee;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import model.AdminModel;
import view.AdminView;

public class AdminAddEmployeeSessionController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminAddEmployeeSessionController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adModel = adModel;
		this.adViewController = adViewController;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String empName = view.empAssignNameField.getText();
		if(empName.isEmpty()) {
			JOptionPane.showMessageDialog (null, "Please pick an Employee!", "Error", JOptionPane.ERROR_MESSAGE);
		}
		else {
			DefaultTableModel tModel = (DefaultTableModel) view.empAssignSessionTable.getModel();
			int i 					 = view.empAssignSessionTable.getSelectedRow();
			if( i != -1) {
				int sessionID = Integer.parseInt(tModel.getValueAt(i, 0).toString());
				String instructor = tModel.getValueAt(i, 4).toString();
				System.out.print(instructor);
				if(!instructor.equals( "-1") ) {
					JOptionPane.showMessageDialog (null, "The session is already assigned to an employee!", "Error", JOptionPane.ERROR_MESSAGE);
				}
				else {
					//***** ASSIGN SESSION CONFLICT
//					for(int row = 0;row < ((DefaultTableModel) view.empUnassignSessionTable.getModel()).getRowCount(); row++) {
//
//					}
					
//					//***** VALIDATE SESSION CONFLICT
//					//boolean isSessionConflict = false;
//					for (int row = 0; row < view.sessionTable.getRowCount(); row++){ 
//						if( view.sessionTable.getModel().getValueAt(row, 7).toString().equals(term) ) {	// Term
//							if( view.sessionTable.getModel().getValueAt(row, 8).toString().equals(location) ) {	// Location
//								if( view.sessionTable.getModel().getValueAt(row, 6).toString().equals(time) ) {	// Time
//									JOptionPane.showMessageDialog(null, "Session Conflict!");
//									return;
//								}
//							}
//						}
//					}
					

					
					DefaultTableModel empModel 	= (DefaultTableModel) view.empListTable.getModel();
					int empIndex 			  	= view.empListTable.getSelectedRow();
					int selectedInstructor 		= Integer.parseInt( empModel.getValueAt(empIndex, 0).toString());
					
					// << Update DB >>
					adModel.assignEmployeeToTeachSession(selectedInstructor, sessionID);
					
					// << Update UI >>
					Vector selectedRow = (Vector) tModel.getDataVector().elementAt(view.empAssignSessionTable.getSelectedRow());
					selectedRow.set(4, selectedInstructor);
					((DefaultTableModel) view.empUnassignSessionTable.getModel()).addRow((Vector) selectedRow);
					//adViewController.updateEmployeeTab();
					adViewController.updateSessionTab();
					// << Alert UI >>
					JOptionPane.showMessageDialog (null, "The Session is assigned to "+ empName +" !", "Success", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		}
	}
	
	
}
