package controller.admin.employee;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;

import model.AdminModel;
import view.AdminView;

public class AdminSelectEmployeeController implements MouseListener  {
	private AdminView view;
	private AdminModel adModel;
	public AdminSelectEmployeeController(AdminView view, AdminModel adModel) {
		this.view = view;
		this.adModel = adModel;
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		TableModel tModel = view.empListTable.getModel();
		int i = view.empListTable.getSelectedRow();
		int employeeID = Integer.parseInt( tModel.getValueAt(i, 0).toString() );
		
		// Populate Un-assign Tab as selecting different employee:
		String[] header  = new String[] {"Session ID", "Course Name", "Time" ,"Location", "Instructor", "Term"};
		
		Object[][] curEmployeeSessionList = adModel.getSessionByInstructorID(employeeID);
		
		view.empUnassignSessionTable.setModel(new DefaultTableModel(curEmployeeSessionList, header));
		
		// Populate Profile:
		view.empEditRadioButton.setSelected(true);		
		view.empProfileIDField.setText			(tModel.getValueAt(i, 0).toString());
		view.empProfilePWField.setText			(tModel.getValueAt(i, 1).toString());
		view.empProfileFirstNameField.setText	(tModel.getValueAt(i, 2).toString());
		view.empProfileMiddleNameField.setText	(tModel.getValueAt(i, 3).toString());
		view.empProfielLastNameField.setText	(tModel.getValueAt(i, 4).toString());
		view.empProfileSalaryField.setText		(tModel.getValueAt(i, 6).toString());

		view.empProfileRmIDField.setText		(tModel.getValueAt(i, 0).toString());
		
		// current emp name for assign & unassign tab
		view.empAssignNameField.setText		(tModel.getValueAt(i, 2).toString() + " " + tModel.getValueAt(i, 4).toString());
		view.empUnassignNameField.setText	(tModel.getValueAt(i, 2).toString() + " " + tModel.getValueAt(i, 4).toString());
	}
	
	
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
