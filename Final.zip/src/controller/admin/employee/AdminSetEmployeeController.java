package controller.admin.employee;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import controller.admin.AdminViewController;
import datatypes.Admin;
import datatypes.Employee;
import model.AdminModel;
import util.ToolBox;
import view.AdminView;

public class AdminSetEmployeeController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminSetEmployeeController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adModel = adModel;
		this.adViewController = adViewController;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String pw = view.empProfilePWField.getText();
		String fn = view.empProfileFirstNameField.getText();
		String mn = view.empProfileMiddleNameField.getText();
		String ln = view.empProfielLastNameField.getText();
		String sr = view.empProfileSalaryField.getText();
		
		if(pw.isEmpty() || fn.isEmpty() || mn.isEmpty() || ln.isEmpty()|| sr.isEmpty() ) { JOptionPane.showMessageDialog(null,"Please fill in all in the infomation"); return;}
		
		if(!ToolBox.isNumeric(sr)){
			JOptionPane.showMessageDialog(null, "Salary Must be Numeric!");
			return;
		};
		boolean selected = !view.empListTable.getSelectionModel().isSelectionEmpty();
		
		//Get table model:
		DefaultTableModel 	tModel 	= (DefaultTableModel) view.empListTable.getModel();
		int 				i 		= view.empListTable.getSelectedRow();
		
		
		if(view.empAddRadioButton.isSelected()) {
			double srD = Double.parseDouble(sr);
			// << update DB >>
			int id = adModel.addEmployeeAccount(new Employee(fn,mn,ln,srD), pw);
			// << update UI >>
			tModel.addRow(new Object[]{ id , pw ,fn, mn, ln, "Professor", sr });
			adViewController.updateCollegeTab();	// collegeTab
			adViewController.updateDepartmentTab();
			adViewController.updateSessionTab();

			// << alert UI >>
			JOptionPane.showMessageDialog(null, "Added!");
		}
		if(view.empEditRadioButton.isSelected()) {
			if( selected == false ) JOptionPane.showMessageDialog(null,"Please Select A Row in the Table!");
			else {
				int id = Integer.parseInt(view.empProfileIDField.getText());
				String tt = tModel.getValueAt(i, 5).toString();
				double srD = Double.parseDouble(sr);

				// << update DB >>
				adModel.updateEmployeeAccount(id ,new Employee(fn,mn,ln,srD), pw);
				
				// << update UI >>
				tModel.setValueAt(pw, i, 1);
				tModel.setValueAt(fn, i, 2);
				tModel.setValueAt(mn, i, 3);
				tModel.setValueAt(ln, i, 4);
				tModel.setValueAt(tt, i, 5);
				tModel.setValueAt(sr, i, 6);
				adViewController.updateCollegeTab();	// collegeTab
				adViewController.updateDepartmentTab();
				adViewController.updateSessionTab();

				
				// << alert UI >>
				JOptionPane.showMessageDialog(null, "Saved!");
			}
		}
	}
}
