package controller.admin.college;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import datatypes.Admin;
import datatypes.College;
import model.AdminModel;
import view.AdminView;

public class AdminSetCollegeController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminSetCollegeController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adModel = adModel;
		this.adViewController = adViewController;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		//*****  VALIDATE IF PICKING EMPLOYEE
		if(view.collegeDeanComboBox.getSelectedIndex() == -1) {
			JOptionPane.showMessageDialog(null,"Please pick an employee"); return;
		}
		
		// Selecting Row in table
		DefaultTableModel 	tModel 	= (DefaultTableModel) view.collegeTable.getModel();
		int 				i 		= view.collegeTable.getSelectedRow();
		
		// Values in current fields
		String collegeName = view.collegeNameField.getText();
		String candidate	= view.collegeDeanComboBox.getSelectedItem().toString();
		String [] candidateInfo = candidate.split(", "); 
		int    candidateID 	  = Integer.parseInt( candidateInfo[0] );
		String candidateTitle = candidateInfo[1];
		String candidateName  = candidateInfo[2].toString();
		
		//***** VALIDATE CANDIDATE IF CANDIDATE IS A "PROFESSOR"
		if(!candidateTitle.equals("Professor")) { JOptionPane.showMessageDialog(null, "Please the selected employee MUST be a professor!");return;}
		
		if( view.collegeAddRadioButton.isSelected() ) {
			if( view.collegeTable.getRowCount() >= 10){JOptionPane.showMessageDialog(null, "Maximum Reach!"); return;} ;

			//Get table model:
			
			boolean isNameTaken = false;
			for (int row = 0; row < view.collegeTable.getRowCount(); row++){ 
				if( tModel.getValueAt(row, 0).toString().equals(collegeName)) {
					isNameTaken = true;
					break;
				}
			}
			//***** VALIDATE COLLEGE NAME TAKEN 
			if( isNameTaken == true  ) {JOptionPane.showMessageDialog(null, "College Name is taken please take another name!");return;}
			//***** VALIDATE FIELS
			if( collegeName.isEmpty()) {JOptionPane.showMessageDialog(null, "College Name Can't be empty"); return;}
			
			// << updateDB >>	
			adModel.addCollege(new College(collegeName, candidateID));
			
			// << Update UI >>
			tModel.addRow(new Object[]{ collegeName, candidateID });
			adViewController.updateCollegeTab();
			adViewController.updateEmployeeTab();
			adViewController.updateDepartmentTab();
			adViewController.updateMajorTab();
			adViewController.updateCourseTab();
			adViewController.updateSessionTab();
			
			
			// << alert UI >>
			JOptionPane.showMessageDialog(null, "Added!");
		}
		
		if( view.collegeEditRadioButton.isSelected() ) {	
			//***** VALIDATE IF SELECTING A ROW IN THE TABLE
			if( view.collegeTable.getSelectedRow() == -1 ) {JOptionPane.showMessageDialog(null,"Please Select A Row in the Table!"); return;}

			// << update DB >>
			
			adModel.setCollegeDean(collegeName, candidateID);
			
			// << update UI >>
			tModel.setValueAt(candidateID, i, 1);
			
			adViewController.updateCollegeTab();
			adViewController.updateEmployeeTab();
			adViewController.updateDepartmentTab();
			adViewController.updateMajorTab();
			adViewController.updateCourseTab();
			adViewController.updateSessionTab();
			// << alert UI >>
			JOptionPane.showMessageDialog(null, "Saved!");
		}
	}
}
