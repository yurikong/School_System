package controller.admin.college;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import model.AdminModel;
import view.AdminView;

public class AdminRemoveCollegeController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminRemoveCollegeController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adViewController = adViewController;
		this.adModel = adModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		DefaultTableModel tModel = (DefaultTableModel) view.collegeTable.getModel();
		int i = view.collegeTable.getSelectedRow();
		if( i != -1) {
			String 	CollegeName = view.collegeNameField.getText();
			int 	deanID		= (int)(view.collegeTable.getValueAt(i, 1));
	
			// << Update DB >>	
			adModel.removeCollege(CollegeName, deanID);
			
			// << Update UI >>
			tModel.removeRow(i);
			view.collegeTable.getSelectionModel().clearSelection();
			view.collegeNameField.setText	("");
			view.collegeDeanComboBox.setSelectedIndex(0);
			adViewController.updateDepartmentTab();
			adViewController.updateMajorTab();
			adViewController.updateCourseTab();
			adViewController.updateSessionTab();
			// << Alert UI >>

		}
		else {
			JOptionPane.showMessageDialog (null, "Please select a row!", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
