package controller.admin;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import datatypes.Admin;
import model.AdminModel;
import model.EmployeeModel;
import model.SchoolModel;
import model.StudentModel;
import model.SuperAdminModel;
import model.UserModel;
import view.AdminView;

public class AdminViewController {
	AdminView 		view;
	Admin 			admin;
	SchoolModel 	schlModel;
	StudentModel 	stdModel;
	AdminModel 		adModel;
	EmployeeModel 	empModel;
	SuperAdminModel sAdModel;
	UserModel 		userModel;
	public AdminViewController(AdminView view, SchoolModel schlModel, StudentModel stdModel, AdminModel adModel, EmployeeModel empModel, SuperAdminModel sAdModel, UserModel userModel, Admin admin){
		this.view 	= view;
		this.admin 	= admin;
		this.schlModel 	= schlModel;
		this.stdModel 	= stdModel;
		this.adModel 	= adModel;
		this.empModel 	= empModel;
		this.sAdModel 	= sAdModel;
		this.userModel 	= userModel;
	}
	public void init() {
		view.adName.setText(admin.firstname() + " " + admin.middlename() + " " + admin.lastname());
		if( admin.id() == 0 ) { view.adRole.setText("Super Admin");}
		else {
			view.adRole.setText("Admin");
			view.tabbedPane.remove(0);
			view.tabbedPane.remove(0);
		}
	
		updateSchoolTab();
		updateAdminTab();
		updateEmployeeTab();
		updateStudentTab();
		updateCollegeTab();
		updateDepartmentTab();
		updateMajorTab();
		updateBuildingTab();
		updateRoomTab();
		updateCourseTab();
		updateSessionTab();
	}
	public void updateSchoolTab() {
		view.schoolNameField.setText(adModel.getUniversityName());
		view.schoolCurrentTermField.setText(schlModel.getCurrentTerm());
	}
	public void updateAdminTab() {
		Object[][] tableData = sAdModel.getAllAdminsConverted();
		String[] header  = new String[] {"ID", "Password", "First Name", "Midle Name", "Last Name"};	 // init
		view.adListTable.setModel(new DefaultTableModel(tableData, header));
	}
	
	public void updateEmployeeTab() {
		// Profiles
		Object[][] data = adModel.getAllEmployeesConverted();

		String[] header  = new String[] {"ID", "Password" ,"First Name", "Midle Name", "Last Name", "Title", "Salary"};
		view.empListTable.setModel(new DefaultTableModel(data, header));
		
		// Assign Tab:
		Object[][] data2 = adModel.getAllSessionsConverted();
		String[] header2  = new String[] {"Session ID", "Course Name", "Time" ,"Location", "Instructor", "Term"};
		view.empAssignSessionTable.setModel(new DefaultTableModel(data2, header2));
		
	}
	public void updateStudentTab() {
		view.studentProfileTuitionComboBox.setModel(new DefaultComboBoxModel(new Object[] {"Paid","Unpaid"}));
		
		// Major:
		view.studentProfileMajorComboBox.setModel(new DefaultComboBoxModel(adModel.getMajorsComboBox()));
		
		String[] header  = new String[] {"ID", "PW", "FN", "MN", "LN", "Major", "Tuition"};	 // init
		Object[][] data = adModel.getAllStudentsConverted();
		
		view.studentProfileTable.setModel(new DefaultTableModel(data, header));
		
		// Init other field with empty!!! 
	}
	public void updateCollegeTab() {
		// Combobox mustbe String!!!
		Object[] comboBox = adModel.getAllEmployeeIDNameComboBox();
		view.collegeDeanComboBox.setModel(new DefaultComboBoxModel(comboBox));

		
		String[] header  = new String[] {"College Name", "Dean ID"};	 // init
		view.collegeTable.setModel(new DefaultTableModel(adModel.getAllCollegeTable(), header));
		
	}
	public void updateDepartmentTab() {
		Object[] comboBox = adModel.getAllEmployeeForDepartmentTabComboBox();
		view.departmentChairComboBox.setModel(new DefaultComboBoxModel(comboBox));
		
		Object[] comboBox2 = adModel.getAllCollegeNameComboBox();
		view.departmentCollegeComboBox.setModel(new DefaultComboBoxModel(comboBox2));
		
		String[] header  = new String[] {"Department Name", "College Name", "Chair ID"};	 // init
		Object[][] testData = adModel.getDepartmentsTable();
		view.departmentTable.setModel(new DefaultTableModel(testData, header));

	}
	public void updateMajorTab() {
		Object[] comboBox = adModel.getAllDepartmentNamesComboBox();
		view.majorDpCB.setModel(new DefaultComboBoxModel(comboBox));
		
		String[] header  = new String[] { "Major Name" , "Department Name", "College Name"};	 // init
		Object[][] data = adModel.getAllMajors();
		view.majorTable.setModel(new DefaultTableModel(data, header));
	}

	public void updateBuildingTab() {
		String[] header  = new String[] { "Building Name" , "Occupancy Limit"};	 // init
//		Object[][] testData = {
//			{"Engineer" ,200},
//			{"Engineer 2" ,900},
//		};
		Object[][] data = adModel.getAllBuildingsTable();
		view.buildingTable.setModel(new DefaultTableModel(data, header));
	}
	
	public void updateRoomTab() {
		Object [] comboBox = adModel.getAllBuildingsComboBox();
		view.roomBuildingComboBox.setModel(new DefaultComboBoxModel(comboBox));
		
		String[] header  = new String[] {"Room ID" ,"Room Number" , "Room Limit", "Building"};	 // init
		Object[][] data = adModel.getAllRoomsTable();
		view.roomTable.setModel(new DefaultTableModel(data, header));

	}
	
	public void updateCourseTab() {
		Object [] comboBox = adModel.getMajorsComboBox();
		view.courseMajorComboBox.setModel(new DefaultComboBoxModel(comboBox));
		String[] header  = new String[] { "ID", "Name", "Unit", "Major", "Department", "College"};	 // init
		Object[][] data = adModel.getAllCourses();
		
		view.courseTable.setModel(new DefaultTableModel(data, header));
		
		// Init the other tab
		view.prereqSelectCourseField.setText("");
		view.prereqdCourseCombox.setSelectedIndex(-1);
		view.prereqRemoveCourseField.setText("");
		((DefaultTableModel) view.prereqTable.getModel()).getDataVector().removeAllElements();
	}
	public void updateSessionTab() {
		view.sessionComboBox.setModel			( new DefaultComboBoxModel(adModel.getAllCourseIDNameComboBox()));
		view.sessionSemesterComboBox.setModel	(new DefaultComboBoxModel(schlModel.getSemesterSystem()));
		view.sessionDayComboBox.setModel		(new DefaultComboBoxModel(schlModel.getDaySystem()));
		view.sessionLocationComboBox.setModel	(new DefaultComboBoxModel(adModel.getAllLocationsComboBox()));
		
		String[] header  = new String[] { "sID", "cID", "rID" , "Course Name", "Unit", "Intructor", "Time", "Term", "Location", "Limit"};	 // init
		Object[][] testData = {
			{"123", "412", "Course Name", "Unit", "Intructor", "MW 09:00-11:00", "Engineer 404"},
			{"321", "321", "Course Name", "Unit", "Intructor", "MW 09:00-11:00", "Engineer 404"},
		};
		Object[][] data = adModel.getAllSessions();
		view.sessionTable.setModel(new DefaultTableModel(data, header));
		
		
	}
}
