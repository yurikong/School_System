package controller.admin.major;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import datatypes.Major;
import model.AdminModel;
import util.ToolBox;
import view.AdminView;

public class AdminAddMajorController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminAddMajorController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adViewController = adViewController;
		this.adModel = adModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if( view.majorTable.getRowCount() >= 50){JOptionPane.showMessageDialog(null, "Maximum Reach!"); return;} ;

		if(view.majorDpCB.getSelectedIndex() == -1 ) {return;}
		
		String majorName		= view.majorNameField.getText().toString();
		String departmentName 	= view.majorDpCB.getSelectedItem().toString();
		String collegeName  	= "";
		
		for (int row = 0; row < view.departmentTable.getRowCount(); row++){ 
			if( view.departmentTable.getModel().getValueAt(row, 0)	== departmentName) {
				collegeName = view.departmentTable.getModel().getValueAt(row, 1).toString();
			}
		}
		if( collegeName.isEmpty()) {JOptionPane.showMessageDialog(null,"College doesn't exist"); return;}
		if( view.majorDpCB.getSelectedIndex() == -1 ) {JOptionPane.showMessageDialog(null,"Please Select A Department!"); return;}
		
		//Get table model:
		DefaultTableModel 	tModel 	= (DefaultTableModel) view.majorTable.getModel();
		int 				i 		= view.majorTable.getSelectedRow();
		
		
		//***** VALIDATE MAJOR NAME TAKEN 
		boolean isNameTaken = false;
		for (int row = 0; row < view.majorTable.getRowCount(); row++){ 
			if( tModel.getValueAt(row, 0).toString().equals(majorName)) {
				if( tModel.getValueAt(row, 1).toString().equals(departmentName)) {	// compare dep
					isNameTaken = true;
					break;
				}
			}
		}
		
		if( isNameTaken ) {JOptionPane.showMessageDialog(null, "Major Name is taken please take another name!"); return;}
		if( majorName.isEmpty()) {JOptionPane.showMessageDialog(null, "Major name should not be empty!"); return;}
		// << updateDB >>	
		adModel.addMajor(new Major(majorName, departmentName, collegeName));
		// << update UI >>
		tModel.addRow(new Object[]{ majorName, departmentName, collegeName });
		adViewController.updateCourseTab();
		adViewController.updateSessionTab();
		// << alert UI >>
		JOptionPane.showMessageDialog(null, "Added!");
	}
}
