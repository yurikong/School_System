package controller.admin.major;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import model.AdminModel;
import view.AdminView;

public class AdminRemoveMajorController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminRemoveMajorController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adViewController = adViewController;
		this.adModel = adModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		DefaultTableModel tModel = (DefaultTableModel) view.majorTable.getModel();
		int i = view.majorTable.getSelectedRow();
		if( i != -1) {
			String majorName  		= view.sessionTable.getValueAt(i, 0).toString();
			String departmentName  	= view.majorTable.getValueAt(i, 1).toString();
			String collegeName 		= view.majorTable.getValueAt(i, 2).toString();
			
			// << Update DB >>	
			adModel.removeMajorByName(majorName);;
			
			// << Update UI >>
			tModel.removeRow(i);
			view.majorTable.getSelectionModel().clearSelection();
			view.majorRemoveField.setText("");
			adViewController.updateCourseTab();
			adViewController.updateSessionTab();
			
			// << Alert UI >>

		}
		else {
			JOptionPane.showMessageDialog (null, "Please select a row!", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
