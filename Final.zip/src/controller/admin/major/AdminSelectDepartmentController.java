package controller.admin.major;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;

import model.AdminModel;
import view.AdminView;

public class AdminSelectDepartmentController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	public AdminSelectDepartmentController(AdminView view, AdminModel adModel) {
		this.view = view;
		this.adModel = adModel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		System.out.println("xxx");
		
	}
}
