package controller.admin.building;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import datatypes.Building;
import model.AdminModel;
import util.ToolBox;
import view.AdminView;

public class AdminAddBuildingController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminAddBuildingController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adViewController = adViewController;
		this.adModel = adModel;
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String  buildingName	= view.buidlingNameField.getText().toString();
		String  occupancyLimit 	= view.buildingOccupationField.getText().toString();

		if( !ToolBox.isNumeric(occupancyLimit) ) {
			JOptionPane.showMessageDialog(null, "OccupancyLimit should be a number!");
			return;
		}

	
	
		
		//Get table model:
		DefaultTableModel 	tModel 	= (DefaultTableModel) view.buildingTable.getModel();
		int 				i 		= view.buildingTable.getSelectedRow();
		
		
		//***** VALIDATE MAJOR NAME TAKEN 
		boolean isNameTaken = false;
		for (int row = 0; row < view.buildingTable.getRowCount(); row++){ 
			if( tModel.getValueAt(row, 0).toString().equals(buildingName)) {
				isNameTaken = true;
				break;
			}
		}
			
		
		
		if( isNameTaken == false  ) {
			if(!buildingName.isEmpty() && !occupancyLimit.isEmpty()) {
				int occupancyLimitInt = Integer.parseInt(occupancyLimit);
				
				// << updateDB >>
				adModel.addBuilding(new Building(buildingName, occupancyLimitInt));
				// << update UI >>
				tModel.addRow(new Object[]{ buildingName, occupancyLimit});
				adViewController.updateRoomTab();
				
				// << alert UI >>
				JOptionPane.showMessageDialog(null, "Added!");
			}
			else JOptionPane.showMessageDialog(null, "Occupancy Limit or Building Name Can't be empty");
			
		}
		else JOptionPane.showMessageDialog(null, "Building Name is taken please take another name!");
		
	}
}
