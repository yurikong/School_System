package controller.admin.building;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import model.AdminModel;
import view.AdminView;

public class AdminRemoveBuildingController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminRemoveBuildingController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adViewController = adViewController;
		this.adModel = adModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		DefaultTableModel tModel = (DefaultTableModel) view.buildingTable.getModel();
		int i = view.buildingTable.getSelectedRow();
		
		if( i != -1) {
			String  buildingName	= view.buildingTable.getValueAt(i, 0).toString();
			
			//int  occupancyLimit 	= Integer.parseInt(view.buildingTable.getValueAt(i, 1).toString());
			
			// << Update DB >>	
			adModel.removeBuildingByName(buildingName);
			
			// << Update UI >>
			tModel.removeRow(i);
			view.buildingTable.getSelectionModel().clearSelection();
			view.buidlingRemoveField.setText("");
			adViewController.updateRoomTab();
			adViewController.updateSessionTab();
			adViewController.updateEmployeeTab();
			adViewController.updateStudentTab();
			// << Alert UI >>

		}
		else {
			JOptionPane.showMessageDialog (null, "Please select a row!", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
