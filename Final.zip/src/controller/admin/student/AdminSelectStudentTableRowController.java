package controller.admin.student;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import model.AdminModel;
import model.SchoolModel;
import view.AdminView;

public class AdminSelectStudentTableRowController implements MouseListener  {
	private AdminView view;
	private AdminModel adModel;
	private SchoolModel schlModel;
	public AdminSelectStudentTableRowController(AdminView view, AdminModel adModel, SchoolModel schlModel) {
		this.view = view;
		this.adModel = adModel;
		this.schlModel = schlModel;
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		view.studentProfileEditRadioButton.setSelected(true);
		
		TableModel tModel = view.studentProfileTable.getModel();
		int i = view.studentProfileTable.getSelectedRow();
		view.studentProfileIDField.setText			(tModel.getValueAt(i, 0).toString());
		view.studentProfilePWField.setText			(tModel.getValueAt(i, 1).toString());
		view.studentProfileFirstNameField.setText	(tModel.getValueAt(i, 2).toString());
		view.studentProfileMiddleNameField.setText	(tModel.getValueAt(i, 3).toString());
		view.studentProfileLastNameField.setText	(tModel.getValueAt(i, 4).toString());
		
		// Bind majob combo box selection
		view.studentProfileMajorComboBox.setSelectedItem	(tModel.getValueAt(i, 5).toString());
		// Bind tuition combo box selection
		view.studentProfileTuitionComboBox.setSelectedItem	(tModel.getValueAt(i, 6).toString());
		
		view.studentProfileRemoveIDField.setText			(tModel.getValueAt(i, 0).toString());
		
		view.studentGradeIDField.setText					(tModel.getValueAt(i, 2).toString() + " " + tModel.getValueAt(i, 4).toString());
		
				
		// Populate Grade Tab for Each student:
		gradeTabInit();
		
	}
	public void gradeTabInit() {
		view.studentGradeComboBox.setModel(new DefaultComboBoxModel(schlModel.getGradeSystem()));
		TableModel tModel = view.studentProfileTable.getModel();
		int i = view.studentProfileTable.getSelectedRow();
		int studentID = Integer.parseInt(tModel.getValueAt(i, 0).toString());
		
		
		String[] header  = new String[] {"Session ID", "Course Name", "Term", "Grade"};	 // init
		Object[][] data = adModel.getSessionGradesByID(studentID);
		//session ID, course name,  term, grade 
		view.studentGradeTable.setModel(new DefaultTableModel(data, header));
	}
	
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
