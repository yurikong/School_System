package controller.admin.student;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import datatypes.Admin;
import model.AdminModel;
import view.AdminView;

public class AdminSetStudentGradeController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	public AdminSetStudentGradeController(AdminView view, AdminModel adModel) {
		this.view = view;
		this.adModel = adModel;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(view.studentGradeComboBox.getSelectedIndex() == -1 ) {return;}

		boolean selected = !view.studentGradeTable.getSelectionModel().isSelectionEmpty();
		
		if( selected == false ) JOptionPane.showMessageDialog(null,"Please Select A Row in the Table!");
		else {
			int i 			= view.studentGradeTable.getSelectedRow();
			int stdID		= Integer.parseInt(view.studentProfileIDField.getText().toString());
			int sesID   	= Integer.parseInt(view.studentGradeTable.getModel().getValueAt(i,0).toString());
			String grade 	= view.studentGradeComboBox.getSelectedItem().toString();

			// update DB
			adModel.assignStudentGrade(stdID, sesID, grade);
			// update UI
		
			// alert UI
			JOptionPane.showMessageDialog(null, "Saved!");
		}

	}
}
