package controller.admin.student;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import datatypes.Admin;
import model.AdminModel;
import view.AdminView;

public class AdminRemoveStudentController implements ActionListener {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminRemoveStudentController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adModel = adModel;
		this.adViewController = adViewController;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		DefaultTableModel tModel = (DefaultTableModel) view.studentProfileTable.getModel();
		int i = view.studentProfileTable.getSelectedRow();
		if( i != -1) {
			int id = Integer.parseInt(tModel.getValueAt(i, 0).toString());
	
			// << Update DB >>	
				//adModel.removeAdminAccount(id);
			
			// << Update UI >>
			tModel.removeRow(i);
			view.studentProfileIDField.setText("");
			view.studentProfilePWField.setText("");
			view.studentProfileFirstNameField.setText("");
			view.studentProfileMiddleNameField.setText("");
			view.studentProfileLastNameField.setText("");
			view.studentProfileMajorComboBox.setSelectedIndex(0);
			view.studentProfileTuitionComboBox.setSelectedIndex(0);
			adViewController.updateSessionTab();
				// Clear old ID in the remove Field & Grade Tab:
			view.studentProfileRemoveIDField.setText("");
			view.studentGradeIDField.setText("");
			((DefaultTableModel)view.studentGradeTable.getModel()).getDataVector().removeAllElements();
			
			// << Alert UI >>

		}
		else {
			JOptionPane.showMessageDialog (null, "Please select a user!", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
