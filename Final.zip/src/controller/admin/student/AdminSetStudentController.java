package controller.admin.student;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import datatypes.Admin;
import datatypes.Student;
import model.AdminModel;
import view.AdminView;

public class AdminSetStudentController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminSetStudentController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adModel = adModel;
		this.adViewController = adViewController;
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		String pw = view.studentProfilePWField.getText();
		String fn = view.studentProfileFirstNameField.getText();
		String mn = view.studentProfileMiddleNameField.getText();
		String ln = view.studentProfileLastNameField.getText();

		if(pw.isEmpty() || fn.isEmpty() || mn.isEmpty() || ln.isEmpty()) {
			if( view.studentProfileMajorComboBox.getSelectedIndex() == -1 || view.studentProfileTuitionComboBox.getSelectedIndex() == -1) {
				JOptionPane.showMessageDialog(null,"Please fill in all in the infomation");
				return;
			}
		}
		
		String mj = (String) view.studentProfileMajorComboBox.getSelectedItem();
		String tt = (String) view.studentProfileTuitionComboBox.getSelectedItem();


		
		boolean selected = !view.studentProfileTable.getSelectionModel().isSelectionEmpty();
		
		//Get table model:
		DefaultTableModel 	tModel 	= (DefaultTableModel) view.studentProfileTable.getModel();
		int 				i 		= view.studentProfileTable.getSelectedRow();
		
		if( view.studentProfileAddRadioButton.isSelected() ) {
			// << updateDB >>
			int nID = adModel.addStudentAccount(new Student(fn,mn,ln,mj),pw);
			// << update UI >>
			tModel.addRow(new Object[]{ nID, pw ,fn, mn, ln, mj, tt });
			adViewController.updateSessionTab();
			// << alert UI >>
			JOptionPane.showMessageDialog(null, "Added!");
		}
		
		if( view.studentProfileEditRadioButton.isSelected() ) {
			if( selected == false ) JOptionPane.showMessageDialog(null,"Please Select A Row in the Table!");
			else {
				int id = Integer.parseInt(view.studentProfileIDField.getText());	// It's here CUZ we can't parse empty string!
				Student nStd = new Student(fn,mn,ln,mj);
				nStd.setID(id);
				// update DB
				adModel.updateStudentAccount(nStd,pw);
				
				// update UI
				tModel.setValueAt(pw, i, 1);
				tModel.setValueAt(fn, i, 2);
				tModel.setValueAt(mn, i, 3);
				tModel.setValueAt(ln, i, 4);
				tModel.setValueAt(mj, i, 5);
				tModel.setValueAt(tt, i, 6);
				adViewController.updateSessionTab();

				// alert UI
				JOptionPane.showMessageDialog(null, "Saved!");
			}
		}
		
	}	
}

