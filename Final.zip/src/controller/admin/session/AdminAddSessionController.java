package controller.admin.session;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.time.LocalTime;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import datatypes.Department;
import datatypes.Session;
import model.AdminModel;
import util.ToolBox;
import view.AdminView;

public class AdminAddSessionController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminAddSessionController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adViewController = adViewController;
		this.adModel = adModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {	
		// Time is already validate by the spinner!
		String    startTime 	= new SimpleDateFormat("HH:mm").format(view.startTimeSpinner.getValue());
		String 	  endTime  		= new SimpleDateFormat("HH:mm").format(view.endTimeSpinner.getValue());
		LocalTime startTimeLT 	= LocalTime.parse(startTime);
		LocalTime endTimeLT   	= LocalTime.parse(endTime);
		
		// Validate Empty 
		boolean isFieldEmpty = false;
		if(view.sessionComboBox.getSelectedIndex() == -1 ) { isFieldEmpty = true;}
		if(view.sessionSemesterComboBox.getSelectedIndex() == -1) { isFieldEmpty = true;}
		if(view.sessionDayComboBox.getSelectedIndex() == -1) {isFieldEmpty = true;}
		if(view.sessionLocationComboBox.getSelectedIndex() == -1) {isFieldEmpty = true;}
		if(view.sessionYearField.getText().isEmpty() ) {isFieldEmpty = true;}
		if(isFieldEmpty == true) {JOptionPane.showMessageDialog(null, "All Fields must not be empty!");return;};
			// Time is current time => can't be empty
	
		// Check Invalid Input:
		boolean isValidated = true;
		if(!ToolBox.isNumeric( view.sessionYearField.getText() )) 	{JOptionPane.showMessageDialog(null, "Year must be a digit!");return;}
		if(!ToolBox.isTimeValid(startTimeLT, endTimeLT)) 			{JOptionPane.showMessageDialog(null, "Invalid Time Schedule");return;}
			
		
		
		String courseInfo = view.sessionComboBox.getSelectedItem().toString();
		String courseID   = courseInfo.split(", ")[0];
		String courseName = courseInfo.split(", ")[1];
	
		int	      year = Integer.parseInt( view.sessionYearField.getText().toString());
		String    semester = view.sessionSemesterComboBox.getSelectedItem().toString();
		String    term = semester + " " + Integer.toString(year);
		String    day 	= view.sessionDayComboBox.getSelectedItem().toString();
		String 	  locationInfo = view.sessionLocationComboBox.getSelectedItem().toString();
		String    location	= locationInfo.split(", ")[0];

		String    buildingName	= location.split(" ")[0];
		int       roomNumber	= Integer.parseInt(location.split(" ")[1]);

		int       roomID    = Integer.parseInt( locationInfo.split(", ")[1] );
		int       roomLimit = Integer.parseInt( locationInfo.split(", ")[2] );
		String    time = day + " " + startTime + "-" + endTime;

		
		//***** VALIDATE SESSION CONFLICT
		//boolean isSessionConflict = false;
		for (int row = 0; row < view.sessionTable.getRowCount(); row++){ 
			if( view.sessionTable.getModel().getValueAt(row, 7).toString().equals(term) ) {	// Term
				if( view.sessionTable.getModel().getValueAt(row, 8).toString().equals(location) ) {	// Location
					LocalTime[] tableTime = ToolBox.timeRangeStringToLocalTime(view.sessionTable.getModel().getValueAt(row, 6).toString());
					LocalTime[] inputTime = new LocalTime[] {startTimeLT, endTimeLT};
					if(ToolBox.isTimeConflict(tableTime, inputTime)) {
						JOptionPane.showMessageDialog(null, "Session Conflict!");
						return;	
					}
				}
			}
		}
		
		DefaultTableModel 	tModel 	= (DefaultTableModel) view.sessionTable.getModel();
		int 				i 		= view.sessionTable.getSelectedRow();
		
		String col = "";
		String dep = "";
		String mj  = "";
		// Get DEP, COL, MJ
		for (int row = 0; row < view.courseTable.getRowCount(); row++){ 
			if( courseID.equals(view.courseTable.getValueAt(row, 0).toString())) {	// compare dep
				mj =  view.courseTable.getValueAt(row, 3).toString();
				dep = view.courseTable.getValueAt(row, 4).toString();
				col = view.courseTable.getValueAt(row, 5).toString();
				break;
			}
		}
		
		// << updateDB >>
		int sID = adModel.addSession(new Session(Integer.parseInt(courseID), 
				startTimeLT, endTimeLT, semester, year, day, buildingName,
				roomID, roomNumber, 
				col, dep, mj));
		
		
		// << update UI >>
		tModel.addRow(new Object[]{ 1, courseID, roomID, courseName, 4, "-1", time, term, location, roomLimit });
		adViewController.updateEmployeeTab();

		// << alert UI >>
		JOptionPane.showMessageDialog(null, "Added!");
		
	}
}
