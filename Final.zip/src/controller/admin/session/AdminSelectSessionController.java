package controller.admin.session;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;

import database.UsersTable;
import model.AdminModel;
import view.AdminView;



public class AdminSelectSessionController implements MouseListener  {
	private AdminView view;
	private AdminModel adModel;
	public AdminSelectSessionController(AdminView view, AdminModel adModel) {
		this.view = view;
		this.adModel = adModel;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		TableModel tModel = view.sessionTable.getModel();
		int i = view.sessionTable.getSelectedRow();
		view.sessionRemoveField.setText("");
		int sessionID  		= Integer.parseInt( view.sessionTable.getValueAt(i, 0).toString() );
		
		
		//Roster Init:
		// rosterTable
		view.sessionRemoveField.setText(tModel.getValueAt(i, 0).toString());
		String[] header  = new String[] { "Std ID", "PW","FirstName","MiddleName", "LastName", "Major","Tuition" };	 // init
		Object[][] data = adModel.getRosterOfSelectedSession(sessionID);
		view.rosterTable.setModel(new DefaultTableModel(data, header));
	}	
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
