package controller.admin.session;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import controller.admin.AdminViewController;
import model.AdminModel;
import view.AdminView;

public class AdminRemoveSessionController implements ActionListener  {
	private AdminView view;
	private AdminModel adModel;
	private AdminViewController adViewController;
	public AdminRemoveSessionController(AdminView view, AdminModel adModel, AdminViewController adViewController) {
		this.view = view;
		this.adViewController = adViewController;
		this.adModel = adModel;
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		DefaultTableModel tModel = (DefaultTableModel) view.sessionTable.getModel();
		int i = view.sessionTable.getSelectedRow();
		if( i != -1) {
			int sessionID  		= Integer.parseInt( view.sessionTable.getValueAt(i, 0).toString() );

			// << Update DB >>	
			adModel.removeSessionByID(sessionID);
			
			// << Update UI >>
			tModel.removeRow(i);
			view.sessionTable.getSelectionModel().clearSelection();
			view.sessionRemoveField.setText("");
			adViewController.updateEmployeeTab();
			// << Alert UI >>
		}
		else {
			JOptionPane.showMessageDialog (null, "Please select a row!", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
