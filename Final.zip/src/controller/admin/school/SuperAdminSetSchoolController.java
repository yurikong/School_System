package controller.admin.school;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import model.AdminModel;
import model.SchoolModel;
import view.AdminView;
import util.JTextFieldLimit;

public class SuperAdminSetSchoolController implements ActionListener  {
	private AdminView view;
	private SchoolModel schlModel;
	private AdminModel adModel;
	public SuperAdminSetSchoolController(AdminView view, AdminModel adModel, SchoolModel schlModel) {
		this.view = view;
		this.schlModel = schlModel;
		this.adModel = adModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String schoolName = view.schoolNameField.getText();
		
		System.out.println(schoolName);
		if(schoolName.isEmpty()) {
			JOptionPane.showMessageDialog(null, "School Name Can't Be Empty", "Error", JOptionPane.ERROR_MESSAGE);
		}
		else if(schoolName.length() > 60){
			JOptionPane.showMessageDialog(null, "School Name Can't Be More than 60 Character", "Error", JOptionPane.ERROR_MESSAGE);
		}	
		else {
			adModel.updateUniversityName(schoolName);
			JOptionPane.showMessageDialog(null, "Saved!", "Success", JOptionPane.INFORMATION_MESSAGE);
			// System.out.println(adModel.getUniversityName()); Check!
		}
	}
}
