package controller.admin.admin;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import datatypes.Admin;
import model.SuperAdminModel;
import view.AdminView;

public class SuperAdminSetAdminController implements ActionListener  {
	private AdminView view;
	private SuperAdminModel sAdModel;
	public SuperAdminSetAdminController(AdminView view, SuperAdminModel sAdModel) {
		this.view = view;
		this.sAdModel = sAdModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String pw = view.adminPWField.getText();
		String fn = view.adminFirstNameField.getText();
		String mn = view.adminMiddleNameField.getText();
		String ln = view.adminLastNamefield.getText();

		if(pw.isEmpty() || fn.isEmpty() || mn.isEmpty() || ln.isEmpty()) {
			JOptionPane.showMessageDialog(null, "Please fill all the fields! If you don't have middle name or last name, fill with space.");
			return;
		}
		
		boolean selected = !view.adListTable.getSelectionModel().isSelectionEmpty();
		
		//Get table model:
		DefaultTableModel 	tModel 	= (DefaultTableModel) view.adListTable.getModel();
		int 				i 		= view.adListTable.getSelectedRow();
		
		if( view.adminAddRadioButton.isSelected() ) {
			// << updateDB >>
			int nID = sAdModel.addAdminAccount(new Admin(fn, mn, ln), pw);	
			
			// << update UI >>
			tModel.addRow(new Object[]{ nID, pw ,fn, mn, ln });
			
			// << alert UI >>
			JOptionPane.showMessageDialog(null, "Added!");
		}
		
		if( view.adminEditRadioButton.isSelected() ) {
			if( selected == false ) JOptionPane.showMessageDialog(null,"Please Select A Row in the Table!");
			else {
				int id = Integer.parseInt(view.adminIDField.getText());	// It's here CUZ we can't parse empty string!
				// update DB

				sAdModel.updateAdminAccount(id, new Admin(fn, mn, ln), pw);
				
				// update UI
				tModel.setValueAt(pw, i, 1);
				tModel.setValueAt(fn, i, 2);
				tModel.setValueAt(mn, i, 3);
				tModel.setValueAt(ln, i, 4);
				

				// alert UI
				JOptionPane.showMessageDialog(null, "Saved!");
			}
		}
	}
}
