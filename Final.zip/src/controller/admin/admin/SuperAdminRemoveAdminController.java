package controller.admin.admin;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import model.AdminModel;
import model.SuperAdminModel;
import view.AdminView;

public class SuperAdminRemoveAdminController implements ActionListener  {
	private AdminView view;
	private SuperAdminModel sAdModel;
	public SuperAdminRemoveAdminController(AdminView view, SuperAdminModel sAdModel) {
		this.view = view;
		this.sAdModel = sAdModel;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		DefaultTableModel tModel = (DefaultTableModel) view.adListTable.getModel();
		int i = view.adListTable.getSelectedRow();
		if( i != -1) {
			int id = Integer.parseInt(tModel.getValueAt(i, 0).toString());
	
			// << Update DB >>	
			sAdModel.removeAdminAccount(id);
			// << Update UI >>
			tModel.removeRow(i);
			view.adminIDField.setText("");
			view.adminFirstNameField.setText("");
			view.adminMiddleNameField.setText("");
			view.adminLastNamefield.setText("");
			view.adminPWField.setText("");

			// << Alert UI >>
			
		}
		else {
			JOptionPane.showMessageDialog (null, "Please select a user!", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
}
