package controller.employee;

import java.awt.event.ActionListener;

import javax.swing.table.DefaultTableModel;

import datatypes.Employee;
import model.EmployeeModel;
import view.EmployeeView;

public class EmployeeTermController implements ActionListener {
	private EmployeeView  view;
	private EmployeeModel model;
	private Employee employee;
	
	public EmployeeTermController(EmployeeView view, EmployeeModel model, Employee employee){
		this.view = view;
		this.model = model;
		this.employee = employee;
	}
	public void actionPerformed(java.awt.event.ActionEvent e){
		String selectedTerm = view.empTermDropdown.getSelectedItem().toString();
		String[] header = new String[] {"SID", "Course", "Location", "Time"};
		Object[][] currentTable = model.getEmployeeScheduleByTerm(employee.id(), selectedTerm);
		view.empScheduleTable.setModel( new DefaultTableModel(currentTable, header) );	// construct tables
	}
}
