package controller.employee;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

import datatypes.Employee;
import model.EmployeeModel;
import model.SchoolModel;
import view.EmployeeView;

public class EmployeeViewController {
	private EmployeeView view;
	private EmployeeModel empModel;
	private SchoolModel schlModel;
	private Employee employee;
	
	public EmployeeViewController(EmployeeView view, EmployeeModel empModel, SchoolModel schlModel, Employee employee){
		this.view = view;
		this.empModel = empModel;
		this.employee = employee;
		this.schlModel = schlModel;
	}
	
	public void init() {
		updateEmployeeTab();
		updateScheduleTab();		
	}	
	public void updateEmployeeTab() {
		// ######################### JTable #########################	
		// Init fields with EMPLOYEE-TAB
		String empFullName 	= getEmployeeFullName();
		String empID		= Integer.toString( employee.id());
		String empTitle		= employee.title();
		String empSalary	= Double.toString( employee.salary() );
		
		view.idField.setText		( empID );
		view.fullnameField.setText	( empFullName );
		view.titleField.setText		( empTitle );
		view.salaryField.setText	( empSalary );

		
		Object[] terms = empModel.employeeTermsComboBox(employee.id());
		if(terms.length == 0) {return;}

		view.empTermDropdown.setModel(new DefaultComboBoxModel(terms));
		
		String defaultTerm = view.empTermDropdown.getSelectedItem().toString();
		
		//Init table
		String[] header = new String[] {"SID", "Course", "Location", "Time"};
		Object[][] data = empModel.getEmployeeScheduleByTerm(employee.id(), defaultTerm);
		view.empScheduleTable.setModel( new DefaultTableModel(data, header) );
	}
	public void updateScheduleTab() {
		String[] header = new String[] {"SID", "Course", "Location", "Time", "Term", "Intructor", "Prereq"};
		Object[][] data = empModel.getAllSessions();
		view.schlScheduleTable.setModel( new DefaultTableModel(data, header) );		// construct tables
	}
	
	public String getEmployeeFullName() {
		return employee.firstname() + " " + employee.middlename() +  " " + employee.lastname();
	}
	
	public String[] stdTermList(TreeMap<String, Object[][]> stdTermData) {
		Set<String> keys = stdTermData.keySet();
		return keys.toArray(new String[keys.size()]);
	}
	public String[] schlTermList(TreeMap<String, Object[][]> schlTermData) {
		Set<String> keys = schlTermData.keySet();
		return keys.toArray(new String[keys.size()]);
	}
}
