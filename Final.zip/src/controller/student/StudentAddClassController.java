package controller.student;

import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import datatypes.Student;
import model.StudentModel;
import view.StudentView;

public class StudentAddClassController implements ActionListener {
	private StudentView view;
	private StudentModel model;
	private StudentViewController stdViewController;
	private Student student;
	
	public StudentAddClassController(StudentView view, StudentModel model, Student student){
		this.view = view;
		this.model = model;
		this.student = student;
	}
	public void actionPerformed(java.awt.event.ActionEvent e){
		int opt = JOptionPane.showConfirmDialog(null, "Confirm!");
		if(opt == JOptionPane.YES_OPTION) {
			int i 					= view.schlScheduleTable.getSelectedRow();
//			int sessionID 			= (int) view.schlScheduleTable.getModel().getValueAt(i, 0);
			
			if(i != -1) {
				if( view.tuitionField.equals("Unpaid")) {
					JOptionPane.showMessageDialog(null, "You haven't paid your tuition yet!");
					return;
				};
				if(view.stdScheduleTable.getRowCount() >= 5) {
					JOptionPane.showMessageDialog(null, "You can't take more than 20 units");
					return;
				}
				

				// get each column values in row
				DefaultTableModel schlModel = (DefaultTableModel) view.schlScheduleTable.getModel();
				int row = view.schlScheduleTable.getSelectedRow();
				int stdID = student.id();
				
				int sessionID     	= Integer.parseInt( schlModel.getValueAt(row, 0).toString() );
				String courseName 	= schlModel.getValueAt(row, 1).toString() ;
				String location 	= schlModel.getValueAt(row, 2).toString() ;
				String time 		= schlModel.getValueAt(row, 3).toString();
				String term 		= schlModel.getValueAt(row, 4).toString();
				String instructor 	= schlModel.getValueAt(row, 5).toString();
				String prereq 		= schlModel.getValueAt(row, 6).toString();

				
				// Validate Prereq:
				if( !model.isPrereqFulfilled(student.id(), sessionID) ) { JOptionPane.showMessageDialog(null, "Prereq not fullfiled!"); return;}
				// stdID, sessionID
				String selectedTerm = view.stdTermDropdown.getSelectedItem().toString();
				
				if (!selectedTerm.equals(term)) { JOptionPane.showMessageDialog(null, "This not for the right term!"); return; }
				
				for(int stdRow = 0; stdRow <  view.stdScheduleTable.getRowCount(); stdRow++) {
					
				}
				
				
				
				// Add in DB:
				model.enrollSession(student.id(), sessionID);
				
				// Add in View:
//				((DefaultTableModel)view.stdScheduleTable.getModel()).addRow(selectedWholeRow);;
				
				// Update UI Data:
				this.stdViewController.update();
				
				
				int unit = view.stdScheduleTable.getRowCount() * 4;
				view.unitField.setText(Integer.toString(unit));
			}
			else JOptionPane.showMessageDialog(null, "You haven't selected a class to add");
		}
	}
	public void setStudentViewController(StudentViewController stdViewController) {
		this.stdViewController = stdViewController;
	}
}
