package controller.student;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;

import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

import datatypes.Session;
import datatypes.Student;
import model.SchoolModel;
import model.StudentModel;
import view.StudentView;

public class StudentViewController {
	private StudentView view;
	private StudentModel stdModel;
	private SchoolModel schlModel;
	private Student student;
	
	public StudentViewController(StudentView view, StudentModel stdModel, SchoolModel schlModel, Student student){
		this.view = view;
		this.stdModel = stdModel;
		this.student = student;
		this.schlModel = schlModel;
	}
	
	public void init() {
		studentTab();
		scheduleTab();

//		// Init std Schedule data
//		view.stdScheduleByTerm 	= stdTermData;			// Dont really nead it here but need for dropdown selection after init
//		
//		// Constructing Table with selected option:
//		Object [][] curTermData = view.stdScheduleByTerm.get( view.stdTermDropdown.getSelectedItem() ); 	// get selected term in ComboBox
//		view.stdScheduleTable.setModel( new DefaultTableModel(curTermData, view.stdScheduleTableHeader) );	// construct tables
		
	// (Schedule Tab)
		
//		// Init schl schedule ComboBox		
//		view.schlTermDropdown.setModel(schlComboBoxMoDel);
//		
//		// Init schl Schedule data
//		view.schlScheduleByTerm 	= schlTermData;		// Dont really nead it here but need for dropdown selection after init
//		
//		// Constructing Table with selected option:
//		Object [][] currentTable2 	= view.schlScheduleByTerm.get( view.schlTermDropdown.getSelectedItem() ); 			// get selected term in ComboBox
//
//		view.schlScheduleTable.setModel( new DefaultTableModel(currentTable2, view.schlScheduleTableHeader) );	// construct tables
	
	}
	public void studentTab() {
		//TreeMap<String, Object[][]> stdTermData  = stdModel.getStudentScheduleByTermConverted(student.id());
		TreeMap<String, Object[][]> stdTermData  = new TreeMap<String, Object[][]>();

		String stdFullName 	= getStudentFullName();
		String stdID		= Integer.toString( student.id());
		String stdMajor 	= student.major();
		String stdTuition	= student.tuitionStatus();
		
		// Init fields with STUDENT-TAB
		view.idField.setText		( stdID );
		view.fullnameField.setText	( stdFullName );
		view.tuitionField.setText	( stdTuition );
		view.majorField.setText	    ( stdMajor );
		
	
		// Init std ComboBox
		Object[] terms = stdModel.studentTermsComboBox();
		if(terms.length == 0) {return;}
		
		view.stdTermDropdown.setModel(new DefaultComboBoxModel(terms));
		String defaultTerm = view.stdTermDropdown.getSelectedItem().toString();
	
		//String selectedTerm = view.stdTermDropdown.getSelectedItem().toString();
		String[] header  = new String[] {"SID", "Course", "Localtion", "Time", "Instructor", "Grade"};	 // init
		Object[][] sessionForDefaultTerm = stdModel.getStudentScheduleByTerm(student.id(), defaultTerm);
		view.stdScheduleTable.setModel(new DefaultTableModel(sessionForDefaultTerm, header));
		int unit = view.stdScheduleTable.getRowCount() * 4;
		view.unitField.setText(Integer.toString(unit));
	}
	public void scheduleTab() {
		String[] header  = new String[] {"SID", "Course Name", "Localtion", "Time","Term", "Instructor", "Prereq"};	 // init
		
		
		Object[][] getAllSession = stdModel.getAllSessions();
		view.schlScheduleTable.setModel(new DefaultTableModel(getAllSession,header));
	}
	public void update() {
		init();
	}
	public String getStudentFullName() {
		return student.firstname() + " " + student.middlename() +  " " + student.lastname();
	}
		
	public String[] stdTermListForComboBox(TreeMap<String, Object[][]> stdTermData) {
		Set<String> keys = stdTermData.keySet();
		return keys.toArray(new String[keys.size()]);
	}
	public String[] schlTermList(TreeMap<String, Object[][]> schlTermData) {
		Set<String> keys = schlTermData.keySet();
		return keys.toArray(new String[keys.size()]);
	}
}
