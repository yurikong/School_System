package controller.student;

import java.awt.event.ActionListener;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.swing.table.DefaultTableModel;

import datatypes.Student;
import model.StudentModel;
import view.StudentView;

public class StudentTermController implements ActionListener {
	private StudentView view;
	private Student student;
	private StudentModel model;
	
	public StudentTermController(StudentView view, StudentModel model, Student student){
		this.view = view;
		this.model = model;
		this.student = student;
	}
	public void actionPerformed(java.awt.event.ActionEvent e){
		String selectedTerm = view.stdTermDropdown.getSelectedItem().toString();
		String[] header  = new String[] {"SID", "Course", "Localtion", "Time", "Instructor", "Grade"};	 // init
		view.stdScheduleTable.setModel( new DefaultTableModel(model.getStudentScheduleByTerm(student.id(), selectedTerm),header ) );	// construct tables
	}
}
