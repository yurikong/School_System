package controller;

import controller.admin.AdminViewController;
import controller.admin.admin.SuperAdminRemoveAdminController;
import controller.admin.admin.SuperAdminSetAdminController;
import controller.admin.building.AdminRemoveBuildingController;
import controller.admin.building.AdminAddBuildingController;
import controller.admin.college.AdminRemoveCollegeController;
import controller.admin.college.AdminSetCollegeController;
import controller.admin.course.AdminAddCoursePrereqControlller;
import controller.admin.course.AdminRemoveCourseController;
import controller.admin.course.AdminRemoveCoursePrereqController;
import controller.admin.course.AdminSelectPrereqCourseController;
import controller.admin.course.AdminAddCourseController;
import controller.admin.department.AdminRemoveDepartmentController;
import controller.admin.department.AdminSetDepartmentController;
import controller.admin.employee.AdminAddEmployeeSessionController;
import controller.admin.employee.AdminRemoveEmployeeController;
import controller.admin.employee.AdminRemoveEmployeeSessionController;
import controller.admin.employee.AdminSelectEmployeeController;
import controller.admin.employee.AdminSetEmployeeController;
import controller.admin.major.AdminRemoveMajorController;
import controller.admin.major.AdminAddMajorController;
import controller.admin.room.AdminRemoveRoomController;
import controller.admin.room.AdminSetRoomController;
import controller.admin.school.SuperAdminSetSchoolController;
import controller.admin.session.AdminRemoveSessionController;
import controller.admin.session.AdminSelectSessionController;
import controller.admin.session.AdminAddSessionController;
import controller.admin.student.AdminRemoveStudentController;
import controller.admin.student.AdminSelectStudentTableRowController;
import controller.admin.student.AdminSetStudentController;
import controller.admin.student.AdminSetStudentGradeController;
import datatypes.Admin;
import driver.Preload;
import model.AdminModel;
import model.EmployeeModel;
import model.SchoolModel;
import model.StudentModel;
import model.SuperAdminModel;
import model.UserModel;
import view.AdminView;
import view.StudentView;

public class AdminController {
	private AdminView 	view;
	private Admin 		admin;
	
	private SchoolModel 	schlModel;
	private StudentModel 	stdModel;
	private AdminModel 		adModel;
	private EmployeeModel 	empModel;
	private SuperAdminModel sAdModel;
	private UserModel 		userModel;

	
	public AdminController(Admin admin){
		this.admin  	= admin;

		this.view 		= new AdminView();
		this.schlModel  = new SchoolModel();
		this.stdModel 	= new StudentModel();
		this.adModel	= new AdminModel();
		this.empModel	= new EmployeeModel();
		this.stdModel	= new StudentModel();
		this.sAdModel	= new SuperAdminModel();
		this.userModel	= new UserModel();
	}
	public void init() {
// Controller:
		AdminViewController adViewController	= new AdminViewController(view, schlModel, stdModel, adModel,empModel, sAdModel, userModel, admin);
		adViewController.init();
 
	// School:
		SuperAdminSetSchoolController sAdSetSchoolController = new SuperAdminSetSchoolController(view, adModel ,schlModel);
		view.addSetSchoolInfoController(sAdSetSchoolController);
		
	// Super Admin:
		SuperAdminRemoveAdminController sAdRemoveAdminController = new SuperAdminRemoveAdminController(view, sAdModel);
		view.addRemoveAdminController(sAdRemoveAdminController);
		
		SuperAdminSetAdminController sAdSetAdminController = new SuperAdminSetAdminController(view, sAdModel);
		view.addSetAdminController(sAdSetAdminController);
		
    // Student:
		AdminSelectStudentTableRowController adminSelectStudentTableRowController = new AdminSelectStudentTableRowController(view, adModel, schlModel);
		view.addAdminSelectStudentTableRow(adminSelectStudentTableRowController);
		
		AdminSetStudentController adminSetStudentController = new AdminSetStudentController(view, adModel,adViewController);
		view.addSetStudentController(adminSetStudentController);
		
		AdminRemoveStudentController adminRemoveStudentController = new AdminRemoveStudentController(view, adModel,adViewController);
		view.addRemoveStudentController(adminRemoveStudentController);
		
		AdminSetStudentGradeController adminSetStudentGradeController = new AdminSetStudentGradeController(view, adModel);
		view.addSetStudentGradeController(adminSetStudentGradeController);
		
	// Employee:
		AdminSelectEmployeeController adminSelectEmployeeController = new AdminSelectEmployeeController(view, adModel);
		view.addSelectEmployeeController(adminSelectEmployeeController);
		
		AdminAddEmployeeSessionController adminAddEmployeeSessionController = new AdminAddEmployeeSessionController(view, adModel, adViewController);
		view.addAddEmployeeSessionController(adminAddEmployeeSessionController);
		
		AdminRemoveEmployeeSessionController adminRemoveEmployeeSessionController = new AdminRemoveEmployeeSessionController(view,adModel,adViewController);
		view.addRemoveEmployeeSessionController(adminRemoveEmployeeSessionController);
		
		AdminRemoveEmployeeController adminRemoveEmployeeController = new AdminRemoveEmployeeController(view,adModel,adViewController);
		view.addRemoveEmployeeController(adminRemoveEmployeeController);
		
		AdminSetEmployeeController adminSetEmployeeController = new AdminSetEmployeeController(view,adModel,adViewController);
		view.addSetEmployeeController(adminSetEmployeeController);
		
		
	//College
		AdminRemoveCollegeController adminRemoveCollegeController = new AdminRemoveCollegeController(view, adModel,adViewController);
		view.addRemoveCollegeController(adminRemoveCollegeController);
		
		AdminSetCollegeController adminSetCollegeController = new AdminSetCollegeController(view, adModel, adViewController);
		view.addSetCollegeController(adminSetCollegeController);

		
	//Department
		AdminRemoveDepartmentController adminRemoveDepartmentController = new AdminRemoveDepartmentController(view, adModel, adViewController);
		view.addRemoveDeparmentController(adminRemoveDepartmentController);
		
		AdminSetDepartmentController adminSetDepartmentController = new AdminSetDepartmentController(view, adModel, adViewController);
		view.addSetDepartmentController	(adminSetDepartmentController);
		
	//Major
		AdminRemoveMajorController adminRemoveMajorController = new AdminRemoveMajorController(view, adModel,adViewController);
		view.addRemoveMajorController(adminRemoveMajorController);
		
		AdminAddMajorController adminSetMajorController = new AdminAddMajorController(view, adModel, adViewController);
		view.addAddMajorController(adminSetMajorController);
		
	//Course
		AdminAddCoursePrereqControlller adminAddCoursePrereqControlller = new AdminAddCoursePrereqControlller(view,adModel);
		view.addAddCoursePrereqController(adminAddCoursePrereqControlller);
		
		AdminRemoveCourseController adminRemoveCourseController = new AdminRemoveCourseController(view, adModel, adViewController);
		view.addRemoveCourseController(adminRemoveCourseController);
		
		AdminRemoveCoursePrereqController adminRemoveCoursePrereqController = new AdminRemoveCoursePrereqController(view,adModel);
		view.addRemoveCoursePrereqController(adminRemoveCoursePrereqController);
		
		AdminAddCourseController adminSetCourseController = new AdminAddCourseController(view, adModel, adViewController);
		view.addAddCourseController(adminSetCourseController);
		
		AdminSelectPrereqCourseController adminSelectPrereqCourseController = new AdminSelectPrereqCourseController(view, adModel);
		view.addSelectPrereqCourseController(adminSelectPrereqCourseController);

	//Session
		AdminRemoveSessionController adminRemoveSessionController = new AdminRemoveSessionController(view,adModel, adViewController);
		view.addRemoveSessionController(adminRemoveSessionController);
		
		AdminAddSessionController adminSetSessionController = new AdminAddSessionController(view,adModel,adViewController);
		view.addAddSessionController(adminSetSessionController);
		
		AdminSelectSessionController adminSelectSessionController = new AdminSelectSessionController(view, adModel);
		view.addSelectCourseController(adminSelectSessionController);

	//Room
		AdminRemoveRoomController adminRemoveRoomController = new AdminRemoveRoomController(view, adModel, adViewController);
		view.addRemoveRoomController(adminRemoveRoomController);
		
		AdminSetRoomController adminSetRoomController = new AdminSetRoomController(view, adModel, adViewController);
		view.addSetRoomController(adminSetRoomController);

	//Building
		AdminAddBuildingController adminSetBuildingController = new AdminAddBuildingController(view, adModel, adViewController);
		view.addSetBuildingController(adminSetBuildingController);
		
		AdminRemoveBuildingController adminRemoveBuildingController = new AdminRemoveBuildingController(view, adModel, adViewController);
		view.addRemoveBuildingController(adminRemoveBuildingController);


	}
}
